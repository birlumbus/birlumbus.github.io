"""Resolve diffuse material contacts without conflating footprint and inventory."""
import numpy as np
from .randomness import stage_rng
from .history_transport import Material,coalesce,check_resource


def polarity_table(world):
    t=world.tectonics;p=world.config.plate_count
    result=np.full((p,p),-1,dtype='<i4')
    for a in range(p):
        for b in range(a+1,p):
            seeds=sorted((int(t.plate_seed_samples[a]),int(t.plate_seed_samples[b])))
            preferred=seeds[int(stage_rng(world.seed,f'history.polarity.{seeds[0]}.{seeds[1]}').integers(2))]
            result[a,b]=result[b,a]=a if int(t.plate_seed_samples[a])==preferred else b
    # Existing saved ocean/ocean decisions override the new-pair stream.
    for e in np.flatnonzero(t.boundary_subducting_plate>=0):
        a,b=t.boundary_plate_ids[e]
        if not t.crust_type[world.mesh.edges[e]].any():
            result[a,b]=result[b,a]=t.boundary_subducting_plate[e]
    return result



def contact_demands(material,neighbor,coeff,capacity,dt,plate_count):
    """Pairwise signed footprint demand independent of the transported result.

    For each cell i and neighbor j, incoming Euler flux q_p produces
      sum_p q_p (f_p[j]-f_p[i])
    because each plate's closed Euler flux has zero divergence. With sum(f)=1,
    this equals sum_(a<b) (q_a-q_b)*(f_a[j]*f_b[i]-f_a[i]*f_b[j]).
    Positive demand is convergent overlap; negative demand is opening. Thus
    rigid common motion cancels pairwise, and junctions can have both signs.
    """
    n=len(capacity);fractions=np.zeros((plate_count,n))
    np.add.at(fractions,(material.host,material.cell),material.values[:,0])
    if np.any(abs(fractions.sum(axis=0)/capacity-1)>1e-12):
        raise ValueError('M3 unexplained coverage damage before transport')
    fractions/=capacity
    reverse=(neighbor[neighbor]==np.arange(n)[:,None,None]).argmax(axis=2)
    incoming=coeff[:,neighbor,reverse]*capacity[neighbor]
    result={}
    threshold=capacity*1e-13/max(1,plate_count**2)
    present=fractions>0
    adjacent=present[:,neighbor].any(axis=2)
    for a in range(plate_count):
        for b in range(a+1,plate_count):
            # Either plate must occupy the cell and the other a neighbor for
            # either product to be nonzero. Diffuse junctions satisfy this same
            # condition; no contact magnitude or support threshold is introduced.
            ids=np.flatnonzero((present[b]&adjacent[a])|(present[a]&adjacent[b]))
            if not len(ids): continue
            product=fractions[a,neighbor[ids]]*fractions[b,ids,None]-fractions[a,ids,None]*fractions[b,neighbor[ids]]
            local=dt*np.sum((incoming[a,ids]-incoming[b,ids])*product,axis=1)
            local[abs(local)<=threshold[ids]]=0
            if local.any():
                change=np.zeros(n);change[ids]=local
                result[(a,b)]=change
    return result


def resolve(world,material,crust,birth,birth_step,origin,time,step,polarity,events,demands):
    n=len(world.mesh.positions);p=world.config.plate_count;capacity=world.mesh.sample_areas_km2
    coverage=material.sum(n);tolerance=capacity*4e-12
    expected=capacity+sum(demands.values(),np.zeros(n))
    if np.any(abs(coverage-expected)>tolerance):
        raise ValueError('M3 unexplained transport coverage change has no matching pair contact demand')
    values=material.values;cell=material.cell;host=material.host;types=crust[material.cohort]
    amounts=np.zeros((p,n));continents=np.zeros((p,n))
    np.add.at(amounts,(host,cell),values[:,0]);np.add.at(continents,(host,cell),values[:,0]*types)
    continental_fraction=np.zeros_like(amounts)
    np.divide(continents,amounts,out=continental_fraction,where=amounts>0)
    remove_request=np.zeros_like(amounts);compress_request=np.zeros_like(amounts);birth_request=np.zeros_like(amounts)
    collisions=[];pair_requests=[]
    seeds=world.tectonics.plate_seed_samples;order=np.argsort(seeds,kind='stable')
    # Each pair consumes only its own physically subducting side. Requests are
    # assembled from the same prior state before any material is changed.
    pairs=sorted(demands,key=lambda pair:tuple(sorted(map(int,seeds[list(pair)]))))
    for a,b in pairs:
        ids=np.flatnonzero(demands[a,b]);demand=demands[a,b][ids]
        opening=np.maximum(-demand,0);closing=np.maximum(demand,0)
        ca,cb=continental_fraction[a,ids],continental_fraction[b,ids]
        ra=closing*((1-ca)*cb+((1-ca)*(1-cb) if polarity[a,b]==a else 0))
        rb=closing*(ca*(1-cb)+((1-ca)*(1-cb) if polarity[a,b]==b else 0))
        cc=closing*ca*cb
        collision_ids=ids[cc>0]
        if len(collision_ids): collisions.append((a,b,collision_ids))
        # Equal geometric shares of retained continental compression, apportioned
        # by available continental footprint, do not erase either provenance.
        ctotal=continents[a,ids]+continents[b,ids]
        share=np.full(len(ids),.5);np.divide(continents[a,ids],ctotal,out=share,where=ctotal>0)
        compress_request[a,ids]+=cc*share;compress_request[b,ids]+=cc*(1-share)
        for x,y,r in ((a,b,ra),(b,a,rb)):
            remove_request[x,ids]+=r;birth_request[x,ids]+=opening*.5
        if events is not None: pair_requests.append((a,b,ids,opening,ra,rb))
    ocean=amounts-continents
    if np.any(remove_request>ocean+tolerance) or np.any(compress_request>continents+tolerance):
        raise ValueError('M3 contact demand exceeds available donor material; reduce history duration or motion speed')
    remove_ratio=np.zeros_like(amounts);compress_ratio=np.zeros_like(amounts)
    np.divide(remove_request,ocean,out=remove_ratio,where=ocean>0)
    np.divide(compress_request,continents,out=compress_ratio,where=continents>0)
    fraction=np.where(types==0,np.minimum(remove_ratio[host,cell],1),0)
    removal_inventory=values[:,1]*fraction
    # Attribute every donor/cohort share to its actual pair before mutation.
    # Numeric blocks avoid millions of Python tuples at standard resolution.
    if events is not None:
        ocean_entries=[np.flatnonzero((host==a)&(types==0)) for a in range(p)]
        new_start=len(crust)
        for a,b,ids,opening,ra,rb in pair_requests:
            opened=opening>0;opened_ids=ids[opened]
            for x,y,local in ((a,b,ra),(b,a,rb)):
                r=np.zeros(n);r[ids]=local
                idx=ocean_entries[x];idx=idx[r[cell[idx]]>0]
                if len(idx):
                    amount=values[idx,1]*r[cell[idx]]/ocean[x,cell[idx]]
                    events.add(step,cell[idx],material.cohort[idx],x,y,removed=amount)
                events.add(step,opened_ids,new_start+x,x,y,created=opening[opened]*.5)
    removed=np.bincount(cell,weights=removal_inventory,minlength=n)
    values*=1-fraction[:,None]
    squeeze=(types==1)&(compress_request[host,cell]>0)
    values[squeeze,0]*=1-np.minimum(compress_ratio[host[squeeze],cell[squeeze]],1)
    compressed=compress_request.sum(axis=0)
    # Propagate the strongest continental host only along actual CC contacts.
    # Disconnected collision components and uninvolved bystanders stay separate.
    winner=np.broadcast_to(np.arange(p,dtype='<i4')[:,None],(p,n)).copy()
    for _ in range(p-1):
        changed=False
        for a,b,ids in collisions:
            wa,wb=winner[a,ids],winner[b,ids]
            va,vb=continents[wa,ids],continents[wb,ids]
            best=np.where((vb>va)|((vb==va)&(seeds[wb]<seeds[wa])),wb,wa)
            changed |= bool(np.any(wa!=best) or np.any(wb!=best))
            winner[a,ids]=best;winner[b,ids]=best
        if not changed: break
    material.host[squeeze]=winner[host[squeeze],cell[squeeze]]
    created=birth_request.sum(axis=0)
    if created.any():
        new_start=len(crust);crust=np.r_[crust,np.zeros(p,dtype='u1')]
        birth=np.r_[birth,np.full(p,time)];birth_step=np.r_[birth_step,np.full(p,step,dtype='<i4')]
        origin=np.r_[origin,np.arange(p,dtype='<i4')]
        new_cells=[];new_hosts=[];new_values=[]
        for a in order:
            ids=np.flatnonzero(birth_request[a]>0)
            if not len(ids):continue
            f=birth_request[a,ids]
            new_cells.append(ids);new_hosts.append(np.full(len(ids),a,dtype='<i4'))
            new_values.append(np.column_stack((f,f,-4500*f,np.zeros(len(f)),np.zeros(len(f)))))
        c=np.concatenate(new_cells).astype('<i4');o=np.concatenate(new_hosts)
        material=Material(np.r_[cell,c],np.r_[material.cohort,new_start+o],np.r_[material.host,o],
                          np.vstack((values,np.concatenate(new_values))))
    material=coalesce(material,p);check_resource(len(material.cell),n)
    residual=capacity-material.sum(n)
    if np.any(abs(residual)>capacity*4e-12): raise ValueError('M3 unexplained coverage residual exceeds roundoff tolerance')
    order=np.lexsort((material.cohort,seeds[material.host],-material.values[:,0],material.cell))
    c=material.cell[order];first=np.r_[True,c[1:]!=c[:-1]];selected=order[first]
    material.values[selected,0]+=residual[material.cell[selected]]
    if (material.values[:,0]<=0).any():raise ValueError('M3 invalid nonpositive resolved footprint')
    return material,crust,birth,birth_step,origin,created,removed,compressed,residual
