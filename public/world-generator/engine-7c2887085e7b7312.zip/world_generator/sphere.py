"""Deterministic icosphere topology and metrics; see docs/m0-contract.md."""

import numpy as np

from .model import Mesh, WorldConfig

# Order and winding are part of icosphere-v1. Never reorder without a new version.
BASE_FACES = (
    (0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11),
    (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6), (7, 1, 8),
    (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9),
    (4, 9, 5), (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1),
)


def spherical_triangle_areas(triangles: np.ndarray) -> np.ndarray:
    """Positive solid angles in steradians, using the atan2 spherical excess formula."""
    a, b, c = triangles[:, 0], triangles[:, 1], triangles[:, 2]
    numerator = np.abs(np.einsum('ij,ij->i', a, np.cross(b, c)))
    denominator = 1 + np.einsum('ij,ij->i', a, b) + np.einsum('ij,ij->i', b, c) + np.einsum('ij,ij->i', c, a)
    return 2 * np.arctan2(numerator, denominator)


def connectivity(faces: np.ndarray, sample_count: int):
    pairs = np.concatenate((faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]))
    edges = np.unique(np.sort(pairs, axis=1), axis=0).astype('<i4')
    directed = np.concatenate((edges, edges[:, ::-1]))
    directed = directed[np.lexsort((directed[:, 1], directed[:, 0]))]
    offsets = np.zeros(sample_count + 1, dtype='<i4')
    offsets[1:] = np.cumsum(np.bincount(directed[:, 0], minlength=sample_count))
    return edges, offsets, np.ascontiguousarray(directed[:, 1], dtype='<i4')


def base_positions() -> np.ndarray:
    phi = (1 + np.sqrt(5.0)) / 2
    base = np.array([
        (-1, phi, 0), (1, phi, 0), (-1, -phi, 0), (1, -phi, 0),
        (0, -1, phi), (0, 1, phi), (0, -1, -phi), (0, 1, -phi),
        (phi, 0, -1), (phi, 0, 1), (-phi, 0, -1), (-phi, 0, 1),
    ], dtype='<f8')
    return base / np.linalg.norm(base, axis=1)[:, None]


def build_mesh(config: WorldConfig) -> Mesh:
    positions = list(base_positions())
    faces = list(BASE_FACES)
    for _ in range(config.subdivisions):
        midpoints = {}
        children = []

        def midpoint(a, b):
            key = (min(a, b), max(a, b))
            if key not in midpoints:
                position = positions[a] + positions[b]
                position = position / np.linalg.norm(position)
                midpoints[key] = len(positions)
                positions.append(position)
            return midpoints[key]

        for a, b, c in faces:
            ab, bc, ca = midpoint(a, b), midpoint(b, c), midpoint(c, a)
            children.extend(((a, ab, ca), (b, bc, ab), (c, ca, bc), (ab, bc, ca)))
        faces = children
    positions = np.asarray(positions, dtype='<f8')
    faces = np.asarray(faces, dtype='<i4')
    edges, offsets, neighbors = connectivity(faces, len(positions))
    a, b = positions[edges[:, 0]], positions[edges[:, 1]]
    lengths = np.arctan2(np.linalg.norm(np.cross(a, b), axis=1), np.einsum('ij,ij->i', a, b)) * config.radius_km
    face_areas = spherical_triangle_areas(positions[faces]) * config.radius_km**2
    areas = np.bincount(faces.ravel(), weights=np.repeat(face_areas / 3, 3), minlength=len(positions))
    return Mesh(positions, faces, edges, offsets, neighbors, lengths.astype('<f8'), areas.astype('<f8'))


def face_hierarchy(mesh: Mesh) -> list[np.ndarray]:
    """Recover parent faces from four-child order, using saved indices."""
    levels = [mesh.faces]
    while len(levels[-1]) > 20:
        children = levels[-1].reshape(-1, 4, 3)
        levels.append(np.ascontiguousarray(children[:, :3, 0]))
    return levels[::-1]


def _validate_hierarchy(mesh: Mesh) -> None:
    levels = face_hierarchy(mesh)
    if not np.array_equal(levels[0], BASE_FACES) or not np.allclose(mesh.positions[:12], base_positions(), rtol=0, atol=1e-12):
        raise ValueError('topology must preserve the v1 base face and sample ordering/positions')
    for level, child_faces in enumerate(levels[1:]):
        children = child_faces.reshape(-1, 4, 3)
        a, b, c = children[:, 0, 0], children[:, 1, 0], children[:, 2, 0]
        ab, bc, ca = children[:, 0, 1], children[:, 1, 1], children[:, 0, 2]
        expected = np.stack((np.stack((a, ab, ca), axis=1), np.stack((b, bc, ab), axis=1),
                             np.stack((c, ca, bc), axis=1), np.stack((ab, bc, ca), axis=1)), axis=1)
        if not np.array_equal(children, expected):
            raise ValueError('topology hierarchy must preserve the four-child face order')
        parent_count = 10 * 4**level + 2
        pairs = np.stack((np.stack((a, b), axis=1), np.stack((b, c), axis=1), np.stack((c, a), axis=1)), axis=1).reshape(-1, 2)
        unique, first, inverse = np.unique(np.sort(pairs, axis=1), axis=0, return_index=True, return_inverse=True)
        # Rank each edge by its first appearance: that rank fixes the new sample ID.
        ids = parent_count + np.argsort(np.argsort(first))
        if not np.array_equal(np.stack((ab, bc, ca), axis=1).ravel(), ids[inverse]):
            raise ValueError('topology must preserve midpoint sample IDs in first-encounter order')
        sums = mesh.positions[unique[:, 0]] + mesh.positions[unique[:, 1]]
        midpoints = sums / np.linalg.norm(sums, axis=1)[:, None]
        if not np.allclose(mesh.positions[ids], midpoints, rtol=0, atol=1e-12):
            raise ValueError('topology positions must be normalized parent-edge midpoints')


def validate_mesh(mesh: Mesh, config: WorldConfig) -> None:
    """Validate shape, geometry, manifold connectivity and derived metrics on load."""
    n, e, f = 10 * 4**config.subdivisions + 2, 30 * 4**config.subdivisions, 20 * 4**config.subdivisions
    shapes = {'positions': (n, 3), 'faces': (f, 3), 'edges': (e, 2), 'neighbor_offsets': (n + 1,), 'neighbors': (e * 2,), 'edge_lengths_km': (e,), 'sample_areas_km2': (n,)}
    for name, array in mesh.arrays().items():
        dtype = '<f8' if name in ('positions', 'edge_lengths_km', 'sample_areas_km2') else '<i4'
        if array.shape != shapes[name] or array.dtype.str != dtype or not np.isfinite(array).all():
            raise ValueError(f'invalid mesh array: {name}; expected {shapes[name]} {dtype} with finite values')
    for name in ('faces', 'edges', 'neighbors'):
        array = getattr(mesh, name)
        if array.min() < 0 or array.max() >= n:
            raise ValueError(f'invalid indices in {name}')
    if not np.allclose(np.linalg.norm(mesh.positions, axis=1), 1, rtol=0, atol=1e-12):
        raise ValueError('positions must be normalized to the unit sphere')
    _validate_hierarchy(mesh)
    triangles = mesh.positions[mesh.faces]
    a, b, c = triangles[:, 0], triangles[:, 1], triangles[:, 2]
    if not np.all(np.einsum('ij,ij->i', a, np.cross(b - a, c - a)) > 1e-14):
        raise ValueError('faces must be nondegenerate and outward-wound')
    directed = np.concatenate((mesh.faces[:, [0, 1]], mesh.faces[:, [1, 2]], mesh.faces[:, [2, 0]]))
    edges, counts = np.unique(np.sort(directed, axis=1), axis=0, return_counts=True)
    if len(edges) != e or not np.all(counts == 2) or len(np.unique(directed, axis=0)) != 2 * e:
        raise ValueError('mesh must be a closed consistently wound manifold')
    expected_edges, offsets, neighbors = connectivity(mesh.faces, n)
    if not all(np.array_equal(a, b) for a, b in ((mesh.edges, expected_edges), (mesh.neighbor_offsets, offsets), (mesh.neighbors, neighbors))):
        raise ValueError('mesh edges and sorted adjacency must agree with faces')
    seen, pending = {0}, [0]
    while pending:
        for neighbor in mesh.neighbors_of(pending.pop()):
            i = int(neighbor)
            if i not in seen:
                seen.add(i)
                pending.append(i)
    if len(seen) != n:
        raise ValueError('mesh must be connected')
    degrees = np.diff(offsets)
    if np.count_nonzero(degrees == 5) != 12 or np.count_nonzero(degrees == 6) != n - 12:
        raise ValueError('icosphere must have 12 degree-five samples and degree-six remaining samples')
    face_areas = spherical_triangle_areas(triangles) * config.radius_km**2
    expected_areas = np.bincount(mesh.faces.ravel(), weights=np.repeat(face_areas / 3, 3), minlength=n)
    a, b = mesh.positions[mesh.edges[:, 0]], mesh.positions[mesh.edges[:, 1]]
    expected_lengths = np.arctan2(np.linalg.norm(np.cross(a, b), axis=1), np.einsum('ij,ij->i', a, b)) * config.radius_km
    if not np.all(mesh.sample_areas_km2 > 0) or not np.allclose(mesh.sample_areas_km2, expected_areas, rtol=1e-12, atol=0):
        raise ValueError('sample area weights must equal one-third of incident spherical triangle areas')
    if not np.isclose(mesh.sample_areas_km2.sum(), 4 * np.pi * config.radius_km**2, rtol=1e-12, atol=0):
        raise ValueError('sample areas must sum to the spherical surface area')
    if not np.all(mesh.edge_lengths_km > 0) or not np.allclose(mesh.edge_lengths_km, expected_lengths, rtol=1e-12, atol=0):
        raise ValueError('edge lengths must match spherical arcs')
