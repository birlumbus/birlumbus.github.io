"""Oriented circumcentre dual segments and kinematic contact rules."""

import numpy as np
from .randomness import stage_rng


def _unit(vectors):
    return vectors / np.linalg.norm(vectors, axis=-1, keepdims=True)


def boundary_motion(omega_a, omega_b, midpoints, normals, radius_km):
    """Both velocities are evaluated at the same point, in km/Myr."""
    relative = radius_km * (np.cross(omega_b, midpoints) - np.cross(omega_a, midpoints))
    tangents = np.cross(midpoints, normals)
    return np.sum(relative * normals, axis=-1), np.sum(relative * tangents, axis=-1)


def classify_motion(opening, sliding, tolerance, obliquity_ratio):
    opening, sliding = np.asarray(opening), np.asarray(sliding)
    largest = np.maximum(np.abs(opening), np.abs(sliding))
    threshold = np.maximum(tolerance, obliquity_ratio * largest)
    normal = np.abs(opening) > threshold
    lateral = np.abs(sliding) > threshold
    result = np.zeros(opening.shape, dtype='i1')
    result[normal & (opening < 0)] = 1
    result[normal & (opening > 0)] = 2
    result[lateral] = 3
    result[normal & lateral] = 4
    return result


def boundary_geometry(mesh, mask, radius_km):
    """Dense arrays keyed by M0 edge ID; interior geometry is zero/-1."""
    e, n = len(mesh.edges), len(mesh.positions)
    out = {
        'boundary_mask': mask.astype('u1'),
        'boundary_face_ids': np.full((e, 2), -1, dtype='<i4'),
        'boundary_endpoints': np.zeros((e, 2, 3), dtype='<f8'),
        'boundary_midpoints': np.zeros((e, 3), dtype='<f8'),
        'boundary_normals': np.zeros((e, 3), dtype='<f8'),
        'boundary_tangents': np.zeros((e, 3), dtype='<f8'),
        'boundary_lengths_km': np.zeros(e, dtype='<f8'),
    }
    if not mask.any():
        return out
    triangle = mesh.positions[mesh.faces]
    centers = _unit(np.cross(triangle[:, 1] - triangle[:, 0], triangle[:, 2] - triangle[:, 0]))
    pairs = np.concatenate((mesh.faces[:, [0, 1]], mesh.faces[:, [1, 2]], mesh.faces[:, [2, 0]]))
    pairs = np.sort(pairs, axis=1).astype(np.int64)
    keys = pairs[:, 0] * n + pairs[:, 1]
    # Stable sort retains face ID ordering within each pair; mesh.edges uses this same key order.
    incident = np.tile(np.arange(len(mesh.faces), dtype='<i4'), 3)[np.argsort(keys, kind='stable')].reshape(e, 2)[mask]
    endpoints = centers[incident]
    midpoint = _unit(endpoints[:, 0] + endpoints[:, 1])
    a, b = np.moveaxis(mesh.positions[mesh.edges[mask]], 1, 0)
    normal = _unit(b - a)
    tangent = _unit(np.cross(midpoint, normal))
    reverse = np.sum((endpoints[:, 1] - endpoints[:, 0]) * tangent, axis=1) < 0
    endpoints[reverse] = endpoints[reverse, ::-1]
    incident[reverse] = incident[reverse, ::-1]
    out['boundary_face_ids'][mask] = incident
    out['boundary_endpoints'][mask] = endpoints
    out['boundary_midpoints'][mask] = midpoint
    out['boundary_normals'][mask] = normal
    out['boundary_tangents'][mask] = tangent
    out['boundary_lengths_km'][mask] = radius_km * np.arctan2(np.linalg.norm(np.cross(endpoints[:, 0], endpoints[:, 1]), axis=1),
                                               np.sum(endpoints[:, 0] * endpoints[:, 1], axis=1))
    return out


def _polarity(seed, mesh, crust, seeds, pair_ids, faces, opening, kinds):
    e = len(mesh.edges)
    subducting = np.full(e, -1, dtype='<i4')
    collision = np.zeros(e, dtype='u1')
    components = np.full(e, -1, dtype='<i4')
    eligible = np.flatnonzero(((kinds == 1) | (kinds == 4)) & (opening < 0))
    by_face, keys, preferences = {}, {}, {}
    for edge_id in eligible:
        a, b = map(int, pair_ids[edge_id])
        ca, cb = map(int, crust[mesh.edges[edge_id]])
        sa, sb = int(seeds[a]), int(seeds[b])
        key = (sa, sb, ca, cb) if sa < sb else (sb, sa, cb, ca)
        keys[int(edge_id)] = key
        for face in faces[edge_id]:
            by_face.setdefault(int(face), []).append(int(edge_id))
        if ca and cb:
            collision[edge_id] = 1
        elif ca != cb:
            subducting[edge_id] = b if ca else a
        else:
            pair = key[:2]
            if pair not in preferences:
                preferences[pair] = int(stage_rng(seed, f'polarity.{key[0]}.{key[1]}').integers(2))
            preference = preferences[pair]
            chosen_seed = key[preference]
            subducting[edge_id] = a if sa == chosen_seed else b
    # Each component is a connected run with the same physical plate/crust pairing.
    for first in eligible:
        if components[first] >= 0:
            continue
        components[first] = first
        pending = [int(first)]
        while pending:
            edge_id = pending.pop()
            for face in faces[edge_id]:
                for neighbor in by_face[int(face)]:
                    if components[neighbor] < 0 and keys[neighbor] == keys[int(first)]:
                        components[neighbor] = first
                        pending.append(neighbor)
    return subducting, collision, components


def generate_boundaries(seed, mesh, config, plate_ids, crust_type, plate_omega_rad_per_myr, plate_seed_samples):
    pair_ids = plate_ids[mesh.edges]
    mask = pair_ids[:, 0] != pair_ids[:, 1]
    result = boundary_geometry(mesh, mask, config.radius_km)
    e = len(mesh.edges)
    result['boundary_plate_ids'] = np.where(mask[:, None], pair_ids, -1).astype('<i4')
    opening, sliding = np.zeros(e, dtype='<f8'), np.zeros(e, dtype='<f8')
    opening[mask], sliding[mask] = boundary_motion(
        plate_omega_rad_per_myr[pair_ids[mask, 0]], plate_omega_rad_per_myr[pair_ids[mask, 1]],
        result['boundary_midpoints'][mask], result['boundary_normals'][mask], config.radius_km)
    kinds = np.full(e, -1, dtype='i1')
    kinds[mask] = classify_motion(opening[mask], sliding[mask], config.motion_tolerance_km_per_myr, config.obliquity_ratio)
    subducting, collision, components = _polarity(seed, mesh, crust_type, plate_seed_samples,
                                                pair_ids, result['boundary_face_ids'], opening, kinds)
    result.update(boundary_opening_km_per_myr=opening, boundary_sliding_km_per_myr=sliding,
                  boundary_class=kinds, boundary_subducting_plate=subducting,
                  boundary_collision=collision, boundary_component_ids=components)
    return result
