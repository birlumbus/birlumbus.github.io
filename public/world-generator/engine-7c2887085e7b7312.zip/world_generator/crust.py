"""Independent initial continental and oceanic crust assignment."""

import numpy as np

from .noise import spherical_noise
from .randomness import stage_rng


def generate_crust(seed: int, mesh, config) -> dict[str, np.ndarray]:
    """Generate a spatially correlated crust score and area-targeted type mask."""
    score = spherical_noise(mesh.positions, stage_rng(seed, "crust.field"))
    fraction = float(config.continental_fraction)
    if not 0.0 <= fraction <= 1.0:
        raise ValueError("continental_fraction must be between 0 and 1")

    sample_count = len(mesh.positions)
    crust_type = np.zeros(sample_count, dtype="u1")
    if fraction == 1.0:
        crust_type.fill(1)
    elif fraction != 0.0:
        # lexsort's last key is primary: score descending, then sample ID.
        order = np.lexsort((np.arange(sample_count, dtype="<i4"), -score))
        areas = np.asarray(mesh.sample_areas_km2, dtype="<f8")[order]
        cumulative = np.cumsum(areas, dtype="<f8")
        target = fraction * float(mesh.sample_areas_km2.sum())
        prefixes = np.concatenate((np.array([0.0], dtype="<f8"), cumulative))
        selected = int(np.argmin(np.abs(prefixes - target)))
        crust_type[order[:selected]] = 1

    return {
        "crust_score": np.ascontiguousarray(score, dtype="<f8"),
        "crust_type": np.ascontiguousarray(crust_type, dtype="u1"),
    }
