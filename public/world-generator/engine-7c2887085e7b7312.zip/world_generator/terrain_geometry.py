"""Finite spherical neighborhoods and arc integration, with linear working memory."""
from itertools import product
import numpy as np


def compact_kernel(value):
    """Wendland C2 on [-1,1]; integral = 2/3, value and first two derivatives vanish at edge."""
    r = np.minimum(np.abs(value), 1.)
    return (1-r)**4 * (1+4*r)


def smoothstep(value):
    t = np.clip(value, 0., 1.)
    return t*t*t*(10+t*(-15+6*t))


class SphericalIndex:
    """Unit-XYZ buckets; exact dot-product cap filter after conservative Cartesian lookup."""
    def __init__(self, positions, angular_scale):
        self.positions = positions
        self.step = max(.01, min(2., 2*np.sin(min(angular_scale, np.pi)/2)))
        coordinates = np.floor((positions+1)/self.step).astype(np.int32)
        bins = {}
        for i, xyz in enumerate(coordinates):
            bins.setdefault(tuple(xyz), []).append(i)
        self.bins = {key: np.asarray(ids, dtype='<i4') for key,ids in bins.items()}

    def query(self, center, angle):
        if angle >= np.pi:
            return np.arange(len(self.positions), dtype='<i4')
        chord = 2*np.sin(angle/2) + 1e-12
        lo = np.floor((np.maximum(-1, center-chord)+1)/self.step).astype(int)
        hi = np.floor((np.minimum(1, center+chord)+1)/self.step).astype(int)
        blocks = [self.bins[key] for key in product(*(range(a,b+1) for a,b in zip(lo,hi))) if key in self.bins]
        if not blocks:
            return np.empty(0,dtype='<i4')
        ids = np.sort(np.concatenate(blocks))
        dot = np.einsum('ij,j->i',self.positions[ids],center,optimize=False)
        return ids[dot >= np.cos(angle)-1e-14]


def arc_coordinates(points, midpoint, normal, radius):
    # Signed cross-track is positive toward boundary B. Along sign is immaterial to symmetric kernels.
    across = radius*np.arcsin(np.clip(np.einsum('ij,j->i',points,normal,optimize=False),-1,1))
    along = radius*np.arctan2(np.einsum('ij,j->i',points,np.cross(normal,midpoint),optimize=False),
                              np.einsum('ij,j->i',points,midpoint,optimize=False))
    return across, along


def arc_distance(points, endpoints, midpoint, normal, radius):
    across,along = arc_coordinates(points,midpoint,normal,radius)
    a,b = endpoints
    half = .5*radius*np.arctan2(np.linalg.norm(np.cross(a,b)),np.dot(a,b))
    inside = np.abs(along) <= half
    endpoint_distance = np.minimum(
        radius*np.arctan2(np.linalg.norm(np.cross(points,a),axis=1),np.einsum('ij,j->i',points,a,optimize=False)),
        radius*np.arctan2(np.linalg.norm(np.cross(points,b),axis=1),np.einsum('ij,j->i',points,b,optimize=False)))
    return np.where(inside,np.abs(across),endpoint_distance)


def line_weights(along, length_km, support_km):
    """Integral of the compact along-contact kernel over a physical arc.

    Composite four-point Gauss-Legendre, intervals <= support/4. Each temporary
    is one neighborhood; no global pair matrix. Normalization makes a long,
    straight contact's weight one regardless of its segmentation.
    """
    nodes = np.array([-.8611363115940526,-.3399810435848563,.3399810435848563,.8611363115940526])
    weights = np.array([.3478548451374538,.6521451548625461,.6521451548625461,.3478548451374538])
    count = max(1,int(np.ceil(length_km/(support_km*.25))))
    # Only intervals that could intersect these samples' kernel support are needed.
    step = length_km/count
    first = max(0,int(np.floor((along.min()-support_km+length_km/2)/step)))
    last = min(count,int(np.ceil((along.max()+support_km+length_km/2)/step)))
    result = np.zeros(len(along))
    for interval in range(first,last):
        center = -length_km/2+(interval+.5)*step
        for node,weight in zip(nodes,weights):
            result += weight*compact_kernel((along-center-node*step/2)/support_km)
    return result*(step/2)/(support_km*(2/3))
