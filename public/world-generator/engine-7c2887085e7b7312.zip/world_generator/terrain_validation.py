"""M2 semantic checks independent of archive checksums and diagnostic pixels."""
from dataclasses import replace
import numpy as np
from .terrain_model import Terrain, SPECS, PROFILE
from .water_model import Water, SPECS as WATER_SPECS
from .elevation import generate_elevation
from .oceans import validate_water, water_statistics


def validate_m2_layout(world):
    if world.config.stage == 'm3':
        baseline = replace(world, config=replace(world.config, stage='m2', history_duration_myr=4., history_max_steps=32,
                                                  history_memory_half_life_myr=20., history_late_motion_scale=1.,
                                                  history_terrain_version='regional-v2'), history=None)
        validate_m2_layout(baseline)
        return
    if world.config.stage != 'm2':
        if world.terrain is not None or world.water is not None or getattr(world, 'history', None) is not None:
            raise ValueError('M0/M1 worlds cannot contain terrain, water or history fields')
        return
    n = len(world.mesh.positions)
    for label,record,cls,specs in (('terrain',world.terrain,Terrain,SPECS),('water',world.water,Water,WATER_SPECS)):
        if not isinstance(record,cls):
            raise ValueError(f'M2 requires complete {label} fields')
        for name,(_,tail,dtype,_) in specs.items():
            value = getattr(record,name)
            if (not isinstance(value,np.ndarray) or value.shape != (n,)+tail or value.dtype.str != dtype
                    or not value.flags.c_contiguous or not np.isfinite(value).all()):
                raise ValueError(f'invalid {label} array: {name}; expected finite {(n,)+tail} {dtype} C-order data')
    if type(world.water.sea_level_m) not in (float,int) or not np.isfinite(world.water.sea_level_m):
        raise ValueError('water sea_level_m must be a finite number')


def validate_terrain(world):
    validate_m2_layout(world)
    if world.config.stage == 'm3':
        baseline = replace(world, config=replace(world.config, stage='m2', history_duration_myr=4., history_max_steps=32,
                                                  history_memory_half_life_myr=20., history_late_motion_scale=1.,
                                                  history_terrain_version='regional-v2'), history=None)
        validate_terrain(baseline)
        return
    if world.config.stage != 'm2':
        return
    t = world.terrain
    if not np.array_equal(t.elevation_m,t.baseline_m+t.uplift_m-t.subsidence_m+t.detail_m):
        raise ValueError('elevation_m must reconstruct from baseline + uplift - subsidence + detail')
    if np.any(t.raw_uplift_m < 0) or np.any(t.raw_subsidence_m < 0):
        raise ValueError('raw uplift/subsidence must be nonnegative')
    for raw,actual,limit in ((t.raw_uplift_m,t.uplift_m,PROFILE['uplift_cap_m']),
                             (t.raw_subsidence_m,t.subsidence_m,PROFILE['subsidence_cap_m'])):
        if not np.array_equal(actual,limit*np.tanh(raw/limit)):
            raise ValueError('terrain saturation is inconsistent with raw contributions')
    expected = generate_elevation(world.seed,world.mesh,world.config,world.tectonics)
    for name,value in expected.arrays().items():
        if not np.array_equal(getattr(t,name),value):
            raise ValueError(f'{name} is inconsistent with saved crust, geometry, motion and terrain settings')
    validate_water(world.mesh,t.elevation_m,world.water,sea_level_m=world.config.sea_level_m,
                   submerged_fraction=world.config.submerged_fraction)


def terrain_statistics(world):
    if world.terrain is None:
        return {}
    t,mesh = world.terrain,world.mesh
    weights = mesh.sample_areas_km2/mesh.sample_areas_km2.sum()
    return {
        'elevation_min_m':float(t.elevation_m.min()),'elevation_max_m':float(t.elevation_m.max()),
        'elevation_mean_m':float(np.sum(t.elevation_m*weights)),
        'uplift_max_m':float(t.uplift_m.max()),'subsidence_max_m':float(t.subsidence_m.max()),
        'detail_max_abs_m':float(np.max(np.abs(t.detail_m))),
        'mean_sample_spacing_km':float(np.sqrt(mesh.sample_areas_km2.mean())),
        **water_statistics(mesh,world.water,world.config.submerged_fraction,elevation_m=t.elevation_m),
    }
