"""Deterministic numerical entry point; measurements belong to callers."""

from time import perf_counter
from dataclasses import replace
from .model import World, WorldConfig
from .tectonic_model import Tectonics
from .plates import generate_plates, generate_motions
from .crust import generate_crust
from .boundaries import generate_boundaries
from .randomness import validate_seed
from .sphere import build_mesh
from .elevation import generate_elevation
from .oceans import generate_water


def generate_world(seed: int, config: WorldConfig, *, timings: dict | None = None) -> World:
    validate_seed(seed)
    if not isinstance(config, WorldConfig):
        raise ValueError('config must be a WorldConfig')
    measurements = timings if timings is not None else {}

    def stage(name, function, *args, **kwargs):
        started = perf_counter()
        value = function(*args, **kwargs)
        measurements[name + '_generation_seconds'] = perf_counter() - started
        return value

    is_m3 = config.stage == 'm3'
    upstream_config = (replace(config, stage='m2', history_duration_myr=4., history_max_steps=32,
                               history_memory_half_life_myr=20., history_late_motion_scale=1.,
                               history_terrain_version='regional-v2') if is_m3 else config)
    mesh = stage('mesh', build_mesh, upstream_config)
    if upstream_config.stage == 'm0':
        return World(seed, upstream_config, mesh)
    plates = stage('plates', generate_plates, seed, mesh, upstream_config)
    crust = stage('crust', generate_crust, seed, mesh, upstream_config)
    motion = stage('motion', generate_motions, seed, mesh, upstream_config, plates['plate_ids'], plates['plate_seed_samples'])
    boundaries = stage('boundaries', generate_boundaries, seed, mesh, upstream_config, plates['plate_ids'],
                       crust['crust_type'], motion['plate_omega_rad_per_myr'], plates['plate_seed_samples'])
    tectonics = Tectonics(**(plates | crust | motion | boundaries))
    if upstream_config.stage == 'm1':
        return World(seed,upstream_config,mesh,tectonics)
    terrain = stage('terrain',generate_elevation,seed,mesh,upstream_config,tectonics)
    water = stage('oceans',generate_water,mesh,terrain.elevation_m,
                  sea_level_m=upstream_config.sea_level_m,submerged_fraction=upstream_config.submerged_fraction)
    world = World(seed, config if is_m3 else upstream_config, mesh, tectonics, terrain, water)
    if not is_m3:
        return world
    from .history import generate_history
    return replace(world, history=stage('history', generate_history, world, timings=measurements))


def update_sea_level(world, *, sea_level_m=None, submerged_fraction=None):
    """Return an M2 world with unchanged tectonics/terrain and newly classified water.

    Saved inputs are validated by load_world; save_world validates the result.
    This pure operation never regenerates any random field or terrain.
    """
    if world.config.stage != 'm2' or world.terrain is None or world.water is None:
        raise ValueError('sea-level update requires a saved M2 world')
    config = replace(world.config,sea_level_m=sea_level_m,submerged_fraction=submerged_fraction)
    water = generate_water(world.mesh,world.terrain.elevation_m,sea_level_m=sea_level_m,submerged_fraction=submerged_fraction)
    return replace(world,config=config,water=water)
