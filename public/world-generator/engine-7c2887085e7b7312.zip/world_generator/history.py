"""Bounded deterministic forward replay; all M0/M1/M2 input buffers stay untouched."""
from time import perf_counter
import math
import numpy as np
from .history_model import History,SPECS,PROFILE
from .history_events import EventLog
from .history_transport import geometry,initial_material,advect,summarize,check_resource
from .history_contacts import polarity_table,resolve,contact_demands
from .history_relief import current_relief
from .history_regional import accommodation_field,add_compression_memory
from .oceans import generate_water


def _schedule(config,bound):
    duration=config.history_duration_myr
    if duration==0: return []
    result=[]
    for start,end,scale in ((0.,duration/2,1.),(duration/2,duration,config.history_late_motion_scale)):
        safe=bound/scale if scale else np.inf
        count=max(1,math.ceil((end-start)/safe)) if np.isfinite(safe) else 1
        if len(result)+count>config.history_max_steps:
            raise ValueError(f'M3 step budget exceeded: duration {duration:g} calibration Myr requires more than '
                f'{config.history_max_steps} safe steps; reduce duration or motion speed (safe step {safe:g} Myr)')
        previous=start
        for i in range(1,count+1):
            time=end if i==count else start+(end-start)*i/count
            result.append((time,time-previous,scale));previous=time
    return result


def generate_history(world,*,timings=None):
    config=world.config;mesh=world.mesh;t=world.tectonics;n=len(mesh.positions);p=config.plate_count
    if p>PROFILE['max_plate_count']: raise ValueError('M3 plate count exceeds material resource budget (64)')
    demand_bytes=p*(p-1)//2*n*8
    if demand_bytes>PROFILE['max_contact_demand_bytes']:
        raise ValueError('M3 contact resource budget exceeded (128 MiB); reduce resolution or plate count')
    clock=timings if timings is not None else {}
    for name in ('history_transport_seconds','history_contacts_seconds','history_relief_seconds'): clock[name]=0.
    started=perf_counter()
    g,neighbor,coeff,spacing,speed_bound,rate,bound=geometry(mesh,t.plate_omega_rad_per_myr,config.radius_km)
    schedule=_schedule(config,bound)
    clock['history_transport_seconds']+=perf_counter()-started
    material=initial_material(world)
    regional=getattr(config,'history_terrain_version','legacy-v1')=='regional-v2'
    accommodation=accommodation_field(world) if regional else None
    if regional: clock['history_deformation_seconds']=0.
    origin=np.repeat(np.arange(p,dtype='<i4'),2);crust=np.tile(np.array([0,1],dtype='u1'),p)
    birth=np.full(2*p,-1.);birth_step=np.full(2*p,-1,dtype='<i4')
    polarity=polarity_table(world);events=EventLog()
    times=[0.];scales=[1.];displacements=[0.];outflows=[0.]
    ledger={name:[] for name in ('coverage_km2','inventory_km2','created_km2','removed_km2','compressed_km2',
                                'correction_km2','memory_m','elevation_m','current_collision_m')}
    area,inventory,fields,continental,created_fraction,age,hosts,host_area=summarize(
        material,n,p,crust,birth,0.,t.plate_seed_samples)
    up,down,collision,closing=current_relief(world,g,hosts,continental,t.plate_omega_rad_per_myr,polarity,
        regional_width=accommodation)
    for name,array in (('coverage_km2',area),('inventory_km2',inventory),('memory_m',fields[:,2]),
                       ('elevation_m',world.terrain.elevation_m.copy()),('current_collision_m',collision)):
        ledger[name].append(array.copy())
    for name in ('created_km2','removed_km2','compressed_km2','correction_km2'): ledger[name].append(np.zeros(n))
    final_up=world.terrain.uplift_m.copy();final_down=world.terrain.subsidence_m.copy()
    initial_total=math.fsum(map(float,mesh.sample_areas_km2));created_total=0.;removed_total=0.
    for step,(time,dt,scale) in enumerate(schedule,1):
        previous_closing=closing.copy()
        started=perf_counter()
        demands=contact_demands(material,neighbor,coeff,mesh.sample_areas_km2,dt*scale,p)
        material.values[:,4]*=math.exp(-math.log(2)*dt/config.history_memory_half_life_myr)
        material=advect(material,neighbor,coeff,dt*scale,n,p)
        clock['history_transport_seconds']+=perf_counter()-started
        started=perf_counter()
        material,crust,birth,birth_step,origin,created,removed,compressed,correction=resolve(
            world,material,crust,birth,birth_step,origin,time,step,polarity,events,demands)
        clock['history_contacts_seconds']+=perf_counter()-started
        # Only continental material receives collision memory. The source uses
        # relative closing of the contact during this interval, never absolute speed.
        if regional:
            started=perf_counter()
            add_compression_memory(world,material,crust,compressed,accommodation,g['boundary_lengths_km'])
            clock['history_deformation_seconds']+=perf_counter()-started
        else:
            memory=material.values[:,4]/material.values[:,1]
            exposure=np.maximum(previous_closing[material.cell],0)*dt/PROFILE['shortening_response_km']
            memory+=(PROFILE['memory_cap_m']-memory)*(-np.expm1(-exposure))*crust[material.cohort]
            material.values[:,4]=material.values[:,1]*memory
        area,inventory,fields,continental,created_fraction,age,hosts,host_area=summarize(
            material,n,p,crust,birth,time,t.plate_seed_samples)
        created_total+=math.fsum(map(float,created));removed_total+=math.fsum(map(float,removed))
        actual=math.fsum(map(float,inventory));expected=initial_total+created_total-removed_total
        if abs(actual-expected)>initial_total*1e-12: raise ValueError('M3 retained inventory accounting failed')
        if np.max(abs(area/mesh.sample_areas_km2-1))>1e-12: raise ValueError('M3 incomplete surface coverage')
        next_scale=config.history_late_motion_scale if time>=config.history_duration_myr/2 else 1.
        started=perf_counter()
        up,down,collision,closing=current_relief(world,g,hosts,continental,t.plate_omega_rad_per_myr*next_scale,polarity,
            regional_width=accommodation)
        final_up=9000*np.tanh((up+np.maximum(collision,fields[:,2]))/9000)
        final_down=6000*np.tanh(down/6000)
        elevation=fields[:,0]+final_up-final_down+fields[:,1]
        clock['history_relief_seconds']+=perf_counter()-started
        times.append(time);scales.append(next_scale)
        displacements.append(dt*scale*speed_bound/float(spacing.min()))
        outflows.append(dt*scale*rate)
        for name,array in (('coverage_km2',area),('inventory_km2',inventory),('created_km2',created),
            ('removed_km2',removed),('compressed_km2',compressed),('correction_km2',correction),
            ('memory_m',fields[:,2]),('elevation_m',elevation),('current_collision_m',collision)):
            ledger[name].append(array.copy())
    data={'history_'+name:np.asarray(value) for name,value in ledger.items()}
    data.update(history_times_myr=np.array(times),history_motion_scale=np.array(scales),
        history_step_displacement_fraction=np.array(displacements),history_step_outflow_fraction=np.array(outflows),
        history_omega_rad_per_myr=np.array(scales)[:,None,None]*t.plate_omega_rad_per_myr,
        history_cell_ids=material.cell,history_cohort_ids=material.cohort,history_host_plate_ids=material.host,
        history_footprint_km2=material.values[:,0],history_material_inventory_km2=material.values[:,1],
        history_material_baseline_m=material.values[:,2]/material.values[:,1],
        history_material_detail_m=material.values[:,3]/material.values[:,1],
        history_material_memory_m=material.values[:,4]/material.values[:,1],
        history_cohort_origin_plate=origin,history_cohort_crust=crust,history_cohort_birth_myr=birth,
        history_cohort_birth_step=birth_step,history_polarity=polarity,
        history_final_baseline_m=fields[:,0],history_final_detail_m=fields[:,1],
        history_final_uplift_m=final_up,history_final_subsidence_m=final_down,
        history_final_continental_fraction=continental,history_final_created_fraction=created_fraction,
        history_final_known_age_myr=age,history_final_host_plate=hosts)
    origin_area=np.zeros((p,n));np.add.at(origin_area,(origin[material.cohort],material.cell),material.values[:,0])
    physical_order=np.argsort(t.plate_seed_samples,kind='stable')
    data['history_final_origin_plate']=physical_order[origin_area[physical_order].argmax(axis=0)]
    data.update(events.arrays())
    water=world.water if not schedule else generate_water(mesh,data['history_elevation_m'][-1],
        sea_level_m=config.sea_level_m,submerged_fraction=config.submerged_fraction)
    data['history_final_sea_level_m']=np.array([water.sea_level_m])
    for name,value in water.arrays().items(): data['history_final_'+name]=value
    if set(data)!=set(SPECS): raise RuntimeError(f'incomplete M3 fields: {set(data)^set(SPECS)}')
    return History({name:np.ascontiguousarray(value,dtype=SPECS[name][1]) for name,value in data.items()})
