"""Area-ranked sea selection and deterministic submerged-component labeling."""

import math

import numpy as np

from .water_model import SPECS, Water


def _finite_number(value, name, *, lower=None, upper=None) -> float:
    if isinstance(value, (bool, np.bool_, complex, np.complexfloating)) or not isinstance(value, (int, float, np.number)):
        raise ValueError(f'{name} must be a finite number')
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError(f'{name} must be a finite number') from error
    if not math.isfinite(result) or (lower is not None and result < lower) or (upper is not None and result > upper):
        bounds = '' if lower is None else f' between {lower} and {upper}'
        raise ValueError(f'{name} must be finite{bounds}')
    return result


def _mode(sea_level_m, submerged_fraction) -> tuple[str, float]:
    if (sea_level_m is None) == (submerged_fraction is None):
        raise ValueError('specify exactly one of sea_level_m or submerged_fraction')
    if sea_level_m is not None:
        return 'sea_level_m', _finite_number(sea_level_m, 'sea_level_m')
    return 'submerged_fraction', _finite_number(submerged_fraction, 'submerged_fraction', lower=0., upper=1.)


def _compensated_sum(values: np.ndarray) -> float:
    """Sum positive numerical areas without discarding small later samples."""
    total = 0.
    correction = 0.
    for value in values:
        adjusted = float(value) - correction
        next_total = total + adjusted
        if not math.isfinite(next_total):
            return next_total
        correction = (next_total - total) - adjusted
        total = next_total
    return total


def _compensated_prefix(values: np.ndarray) -> np.ndarray:
    prefixes = np.empty(len(values) + 1, dtype='<f8')
    prefixes[0] = 0.
    total = 0.
    correction = 0.
    for index, value in enumerate(values, start=1):
        adjusted = float(value) - correction
        next_total = total + adjusted
        if not math.isfinite(next_total):
            prefixes[index:] = np.inf
            return prefixes
        correction = (next_total - total) - adjusted
        total = next_total
        prefixes[index] = total
    return prefixes


def _group_areas(sorted_areas: np.ndarray, starts: np.ndarray) -> np.ndarray:
    start_ids = np.flatnonzero(starts)
    ends = np.r_[start_ids[1:], len(sorted_areas)]
    group_areas = sorted_areas[start_ids].copy()
    for group_id in np.flatnonzero(ends-start_ids > 1):
        group_areas[group_id] = _compensated_sum(sorted_areas[start_ids[group_id]:ends[group_id]])
    return group_areas


def _areas(mesh, n: int) -> np.ndarray:
    areas = getattr(mesh, 'sample_areas_km2', None)
    if not isinstance(areas, np.ndarray) or areas.shape != (n,) or areas.dtype.str != '<f8' or not np.isfinite(areas).all() or not np.all(areas > 0):
        raise ValueError('mesh sample_areas_km2 must be finite positive <f8 values')
    total = _compensated_sum(areas)
    if not math.isfinite(total) or total <= 0:
        raise ValueError('mesh sample_areas_km2 total must be finite and positive')
    return areas


def _elevation_and_areas(mesh, elevation_m) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(elevation_m, np.ndarray) or elevation_m.ndim != 1 or elevation_m.dtype.str != '<f8':
        raise ValueError('elevation_m must be a one-dimensional <f8 array')
    n = len(mesh.positions)
    if n == 0:
        raise ValueError('elevation_m must contain at least one sample')
    if elevation_m.shape != (n,) or not np.isfinite(elevation_m).all():
        raise ValueError('elevation_m must have one finite value per mesh sample')
    return elevation_m, _areas(mesh, n)


def _level_for_fraction(elevation_m: np.ndarray, areas: np.ndarray, fraction: float) -> float:
    """Choose a threshold among complete equal-elevation groups.

    A threshold at a group value excludes that group (submerged is strictly
    below sea level); the final candidate is just above the maximum value.
    """
    if fraction == 0.:
        return float(elevation_m.min())
    if fraction == 1.:
        with np.errstate(over='ignore', invalid='ignore'):
            sea_level = float(np.nextafter(elevation_m.max(), np.inf))
        if not math.isfinite(sea_level):
            raise ValueError('selected sea level must be finite')
        return sea_level
    ids = np.arange(len(elevation_m), dtype='<i4')
    order = np.lexsort((ids, elevation_m))
    sorted_elevation = elevation_m[order]
    starts = np.r_[True, sorted_elevation[1:] != sorted_elevation[:-1]]
    start_ids = np.flatnonzero(starts)
    group_areas = _group_areas(areas[order], starts)
    with np.errstate(over='ignore', invalid='ignore'):
        prefixes = _compensated_prefix(group_areas)
        candidates = np.r_[sorted_elevation[start_ids], np.nextafter(sorted_elevation[-1], np.inf)]
    total = _compensated_sum(areas)
    if not np.isfinite(prefixes).all() or not math.isfinite(total):
        raise ValueError('selected sea level must be finite')
    achieved = prefixes / total
    # Candidates are ascending by area, so argmin keeps the lower prefix on a tie.
    sea_level = float(candidates[int(np.argmin(np.abs(achieved - fraction)))])
    if not math.isfinite(sea_level):
        raise ValueError('selected sea level must be finite')
    return sea_level


def _components(mesh, submerged: np.ndarray, areas: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = len(submerged)
    component_ids = np.full(n, -1, dtype='<i4')
    for root in np.flatnonzero(submerged):
        root = int(root)
        if component_ids[root] != -1:
            continue
        component_ids[root] = root
        pending = [root]
        while pending:
            sample_id = pending.pop()
            neighbors = mesh.neighbors_of(sample_id)
            for neighbor in neighbors:
                neighbor = int(neighbor)
                if submerged[neighbor] and component_ids[neighbor] == -1:
                    component_ids[neighbor] = root
                    pending.append(neighbor)
    wet = component_ids >= 0
    if not wet.any():
        empty = np.zeros(n, dtype='u1')
        return component_ids, empty, empty.copy()
    # Stable grouping retains sample-ID order within each component. Sorting once
    # avoids a whole-world Boolean scan per basin when many components are present.
    samples = np.flatnonzero(wet)
    order = np.argsort(component_ids[samples],kind='stable')
    roots = component_ids[samples[order]]
    starts = np.r_[True,roots[1:] != roots[:-1]]
    sums = _group_areas(areas[samples[order]],starts)
    component_areas = dict(zip(map(int,roots[starts]),sums,strict=True))
    ocean_id = min(component_areas, key=lambda component_id: (-component_areas[component_id], component_id))
    ocean = ((component_ids == ocean_id) & submerged).astype('u1')
    basins = ((component_ids != -1) & (component_ids != ocean_id)).astype('u1')
    return component_ids, ocean, basins


def generate_water(mesh, elevation_m: np.ndarray, *, sea_level_m=None, submerged_fraction=None) -> Water:
    """Build an immutable water record using either a level or a target area."""
    mode, requested = _mode(sea_level_m, submerged_fraction)
    elevation_m, areas = _elevation_and_areas(mesh, elevation_m)
    sea_level = requested if mode == 'sea_level_m' else _level_for_fraction(elevation_m, areas, requested)
    if not math.isfinite(sea_level):
        raise ValueError('selected sea level must be finite')
    with np.errstate(over='ignore', invalid='ignore'):
        height = np.ascontiguousarray(elevation_m - sea_level, dtype='<f8')
    if not np.isfinite(height).all():
        raise ValueError('height_above_sea_m must be finite')
    submerged = (elevation_m < sea_level)
    submerged_mask = np.ascontiguousarray(submerged, dtype='u1')
    land_mask = np.ascontiguousarray(~submerged, dtype='u1')
    component_ids, ocean_mask, basin_candidate_mask = _components(mesh, submerged, areas)
    return Water(
        sea_level_m=float(sea_level),
        height_above_sea_m=height,
        submerged_mask=submerged_mask,
        land_mask=land_mask,
        ocean_mask=np.ascontiguousarray(ocean_mask, dtype='u1'),
        basin_candidate_mask=np.ascontiguousarray(basin_candidate_mask, dtype='u1'),
        water_component_ids=np.ascontiguousarray(component_ids, dtype='<i4'),
    )


def _target_error_bound(elevation_m: np.ndarray, areas: np.ndarray) -> float:
    order = np.lexsort((np.arange(len(elevation_m), dtype='<i4'), elevation_m))
    sorted_elevation = elevation_m[order]
    starts = np.r_[True, sorted_elevation[1:] != sorted_elevation[:-1]]
    group_areas = _group_areas(areas[order], starts)
    largest_group_fraction = float(group_areas.max() / _compensated_sum(areas))
    return .5 * largest_group_fraction + 8 * np.finfo('<f8').eps


def water_statistics(mesh, water: Water, submerged_fraction=None, *, elevation_m=None) -> dict:
    """Return numerical-area water metrics; no image-pixel measurements occur here."""
    n = len(mesh.positions)
    areas = _areas(mesh, n)
    total = _compensated_sum(areas)
    submerged_fraction_achieved = float(_compensated_sum(areas[water.submerged_mask.astype(bool)]) / total)
    ocean_fraction = float(_compensated_sum(areas[water.ocean_mask.astype(bool)]) / total)
    basin_candidate_fraction = float(_compensated_sum(areas[water.basin_candidate_mask.astype(bool)]) / total)
    component_ids = np.unique(water.water_component_ids[water.water_component_ids >= 0])
    target_error = None
    target_error_bound = None
    if submerged_fraction is not None:
        requested = _finite_number(submerged_fraction, 'submerged_fraction', lower=0., upper=1.)
        if elevation_m is None:
            raise ValueError('elevation_m is required to calculate a submerged-fraction error bound')
        elevation_m, _ = _elevation_and_areas(mesh, elevation_m)
        target_error = abs(submerged_fraction_achieved - requested)
        target_error_bound = _target_error_bound(elevation_m, areas)
    return {
        'sea_level_m': float(water.sea_level_m),
        'submerged_fraction_achieved': submerged_fraction_achieved,
        'ocean_fraction': ocean_fraction,
        'basin_candidate_fraction': basin_candidate_fraction,
        'land_fraction': float(_compensated_sum(areas[water.land_mask.astype(bool)]) / total),
        'ocean_component_id': -1 if not water.ocean_mask.any() else int(water.water_component_ids[water.ocean_mask.astype(bool)][0]),
        'water_component_count': int(len(component_ids)),
        'target_error': target_error,
        'target_error_bound': target_error_bound,
    }


def validate_water(mesh, elevation_m: np.ndarray, water: Water, *, sea_level_m=None, submerged_fraction=None) -> None:
    """Check record layout and recompute every water semantic from its inputs."""
    _mode(sea_level_m, submerged_fraction)
    elevation_m, _ = _elevation_and_areas(mesh, elevation_m)
    if not isinstance(water, Water):
        raise ValueError('water must be a Water record')
    if not isinstance(water.sea_level_m, (int, float, np.number)) or isinstance(water.sea_level_m, (bool, np.bool_)) or not math.isfinite(float(water.sea_level_m)):
        raise ValueError('sea_level_m must be finite')
    n = len(elevation_m)
    for name, (_, tail, dtype, _) in SPECS.items():
        array = getattr(water, name, None)
        if not isinstance(array, np.ndarray) or array.shape != (n,) + tail or array.dtype.str != dtype:
            raise ValueError(f'invalid water array: {name}; expected {(n,) + tail} {dtype}')
        if array.flags.writeable:
            raise ValueError(f'water array must be read-only: {name}')
        if not array.flags.c_contiguous:
            raise ValueError(f'water array must be C contiguous: {name}')
        if array.dtype.kind == 'f' and not np.isfinite(array).all():
            raise ValueError(f'water array must be finite: {name}')
    for name in ('submerged_mask', 'land_mask', 'ocean_mask', 'basin_candidate_mask'):
        if not np.isin(getattr(water, name), (0, 1)).all():
            raise ValueError(f'water {name} must contain only 0 or 1')
    expected = generate_water(mesh, elevation_m, sea_level_m=sea_level_m, submerged_fraction=submerged_fraction)
    if float(water.sea_level_m) != expected.sea_level_m:
        raise ValueError('water sea_level_m does not match selected level')
    for name in SPECS:
        if not np.array_equal(getattr(water, name), getattr(expected, name)):
            raise ValueError(f'water {name} does not match elevation and connectivity semantics')
    if submerged_fraction is not None:
        stats = water_statistics(mesh, water, submerged_fraction=submerged_fraction, elevation_m=elevation_m)
        if stats['target_error'] > stats['target_error_bound']:
            raise ValueError('water submerged fraction exceeds tied-group error bound')
