"""Small, area-conservative regional response to resolved continental compression.

Spreading redistributes a deformation exposure, never material or the accounting
ledger. There is no source when the material solver reports no compression.
"""
import math
import numpy as np

from .noise import spherical_noise
from .randomness import stage_rng


REGIONAL_VERSION = 'compression-regional-history-v2'
REGIONAL_PROFILE = {
    'accommodation_stream': 'history.regional.accommodation.v2',
    'accommodation_fraction': .30,
    'spreading_sigma_km': 350.,
    'compression_strain_response': .12,
    'spreading_outflow_limit': .45,
    'max_spreading_passes': 128,
    'instantaneous_continental_collision': False,
    'continental_arc_width_rule': 'multiply width and offset by accommodation; divide amplitude by accommodation',
}


def accommodation_field(world):
    """One coherent spherical field controls spatial accommodation, not forcing.

    It is a static procedural response coefficient, not advected crust strength
    or an inference about lithology. Wider response lowers local concentration
    because spreading preserves the integrated exposure.
    """
    noise = spherical_noise(world.mesh.positions,
        stage_rng(world.seed, REGIONAL_PROFILE['accommodation_stream']))
    return 1 + REGIONAL_PROFILE['accommodation_fraction'] * np.tanh(noise)


def spread_compression(mesh, compressed_km2, continental, sigma_km, *, dual_lengths_km=None):
    """Diffuse nonnegative exposure for one dimensionless time, in bounded passes.

    Edge conductance is (dual length / sample distance) times mean sigma²/2
    times harmonic continental footprint fraction. Pair transfers cancel exactly
    in real arithmetic; a .45 outgoing bound ensures positivity. Coefficients
    and the pass count are fixed before iteration; there is no convergence loop.
    """
    area = mesh.sample_areas_km2
    source = np.asarray(compressed_km2, dtype=float)
    continental = np.asarray(continental, dtype=float)
    sigma = np.asarray(sigma_km, dtype=float)
    if any(value.shape != area.shape for value in (source, continental, sigma)):
        raise ValueError('regional response fields must match mesh samples')
    if not all(np.isfinite(v).all() for v in (source, continental, sigma)):
        raise ValueError('regional response fields must be finite')
    if (source < 0).any() or (sigma <= 0).any() or ((continental < 0) | (continental > 1+1e-12)).any():
        raise ValueError('regional response needs nonnegative compression, positive width and valid crust fractions')
    if np.any((source > 0) & (continental <= 0)):
        raise ValueError('continental compression source has no continental material')
    result = source.copy()
    if not source.any():
        return result
    if dual_lengths_km is None:
        from .boundaries import boundary_geometry
        radius = math.sqrt(float(area.sum()) / (4 * math.pi))
        dual_lengths_km = boundary_geometry(mesh, np.ones(len(mesh.edges), dtype=bool), radius)['boundary_lengths_km']
    a, b = mesh.edges.T
    ca, cb = continental[a], continental[b]
    support = np.zeros(len(a))
    np.divide(2*ca*cb, ca+cb, out=support, where=ca+cb > 0)
    conductance = (dual_lengths_km / mesh.edge_lengths_km) * .25*(sigma[a]**2+sigma[b]**2)*support
    outgoing = (np.bincount(a, weights=conductance, minlength=len(area)) +
                np.bincount(b, weights=conductance, minlength=len(area))) / area
    count = max(1, math.ceil(float(outgoing.max()) / REGIONAL_PROFILE['spreading_outflow_limit']))
    if count > REGIONAL_PROFILE['max_spreading_passes']:
        raise ValueError(f'M3 regional spreading budget exceeded: {count} passes; reduce terrain width or resolution')
    transfer = conductance / count
    for _ in range(count):
        density = result / area
        flux = transfer * (density[b] - density[a])
        result += (np.bincount(a, weights=flux, minlength=len(area)) -
                   np.bincount(b, weights=flux, minlength=len(area)))
    return result


def add_compression_memory(world, material, crust, compressed_km2, accommodation, dual_lengths_km):
    """Apply this interval's integrated compression after decay and transport."""
    n = len(world.mesh.positions)
    types = crust[material.cohort]
    continental_area = np.bincount(material.cell, weights=material.values[:,0]*types, minlength=n)
    continental = continental_area / world.mesh.sample_areas_km2
    spread = spread_compression(world.mesh, compressed_km2, continental,
        REGIONAL_PROFILE['spreading_sigma_km']*world.config.terrain_width_scale*accommodation,
        dual_lengths_km=dual_lengths_km)
    # Compression is already integrated over the accepted interval: no second dt.
    dose = spread / world.mesh.sample_areas_km2 * world.config.relief_scale / REGIONAL_PROFILE['compression_strain_response']
    memory = material.values[:,4] / material.values[:,1]
    memory += (6000.-memory) * (-np.expm1(-dose[material.cell])) * types
    material.values[:,4] = material.values[:,1] * memory
