"""Named streams: adding or consuming one stage cannot advance another."""

import hashlib

import numpy as np


def validate_seed(seed: int) -> None:
    if type(seed) is not int or not 0 <= seed < 2**64:
        raise ValueError('seed must be an unsigned 64-bit integer (0 through 18446744073709551615)')


def stage_rng(seed: int, name: str) -> np.random.Generator:
    validate_seed(seed)
    if not isinstance(name, str) or not name:
        raise ValueError('stage name must be a nonempty string')
    material = b'world-generator/sha256-pcg64-v1\0' + seed.to_bytes(8, 'little') + name.encode('utf-8')
    entropy = int.from_bytes(hashlib.sha256(material).digest(), 'little')
    return np.random.Generator(np.random.PCG64(entropy))
