"""Deterministic M3 history diagnostic views from persisted replay arrays only."""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from .oceans import generate_water
from .terrain_export import (
    _BG,
    _BASIN,
    _LAND,
    _OCEAN,
    _font,
    _hatch_basins,
    _map_canvas,
    _pole_directions,
    _project_pole,
    _save_map,
    _stops_colour,
    _validate_inputs,
)


DIAGNOSTICS = (
    "m3_elevation.png",
    "m3_water.png",
    "m3_difference.png",
    "m3_age.png",
    "m3_material.png",
    "m3_removal.png",
    "m3_memory.png",
    "m3_motion_change.png",
    "m3_poles.png",
    "m3_fixed_sea_water.png",
)

_ELEVATION_STOPS = (
    (-9000.0, (8, 29, 105)),
    (-4500.0, (29, 111, 195)),
    (0.0, (52, 147, 74)),
    (1800.0, (177, 126, 64)),
    (9000.0, (104, 55, 36)),
)
_RELIEF_OCEAN_STOPS = ((0.0, (124, 202, 236)), (1500.0, (35, 130, 211)), (9000.0, (7, 26, 100)))
_RELIEF_LAND_STOPS = ((0.0, (55, 151, 77)), (1000.0, (153, 183, 65)), (3500.0, (177, 126, 64)), (9000.0, (104, 55, 36)))
_DIFFERENCE_STOPS = ((-6000.0, (39, 73, 143)), (0.0, (222, 224, 211)), (6000.0, (181, 53, 45)))
_AGE_STOPS = ((0.0, (232, 196, 79)), (10.0, (192, 103, 56)), (20.0, (90, 45, 96)))
_FRACTION_STOPS = ((0.0, (32, 52, 91)), (0.5, (71, 151, 177)), (1.0, (232, 196, 79)))
_MEMORY_STOPS = ((0.0, (42, 46, 63)), (1500.0, (82, 137, 176)), (6000.0, (238, 181, 71)))
_UNKNOWN = np.array((118, 122, 128), dtype=np.uint8)


def _history(world, ids: np.ndarray) -> tuple[dict, np.ndarray]:
    """Validate the saved M3-only data needed to make display-only maps."""
    ids = _validate_inputs(world, ids)
    history = getattr(world, "history", None)
    if history is None:
        raise ValueError("M3 history diagnostics require a world with saved history")
    data = history.data
    n = len(world.mesh.positions)
    required = (
        "history_times_myr", "history_elevation_m", "history_memory_m", "history_current_collision_m",
        "history_coverage_km2", "history_created_km2", "history_removed_km2", "history_compressed_km2",
        "history_final_baseline_m", "history_final_detail_m", "history_final_uplift_m", "history_final_subsidence_m",
        "history_final_continental_fraction", "history_final_created_fraction", "history_final_known_age_myr",
        "history_final_origin_plate", "history_final_host_plate", "history_final_sea_level_m",
        "history_final_height_above_sea_m", "history_final_submerged_mask", "history_final_land_mask",
        "history_final_ocean_mask", "history_final_basin_candidate_mask", "history_final_water_component_ids",
    )
    missing = [name for name in required if name not in data]
    if missing:
        raise ValueError(f"history is missing diagnostic field: {missing[0]}")
    times = np.asarray(data["history_times_myr"], dtype="<f8")
    if times.ndim != 1 or len(times) < 1 or not np.all(np.isfinite(times)) or times[0] != 0.0:
        raise ValueError("history_times_myr must be a finite history beginning at zero")
    h = len(times)
    for name in ("history_elevation_m", "history_memory_m", "history_current_collision_m", "history_coverage_km2",
                 "history_created_km2", "history_removed_km2", "history_compressed_km2"):
        value = np.asarray(data[name])
        if value.shape != (h, n) or not np.all(np.isfinite(value)):
            raise ValueError(f"{name} must be a finite HxN history array")
    for name in ("history_final_baseline_m", "history_final_detail_m", "history_final_uplift_m", "history_final_subsidence_m",
                 "history_final_continental_fraction", "history_final_created_fraction", "history_final_known_age_myr",
                 "history_final_height_above_sea_m"):
        value = np.asarray(data[name])
        if value.shape != (n,) or not np.all(np.isfinite(value)):
            raise ValueError(f"{name} must be a finite final sample array")
    for name in ("history_final_submerged_mask", "history_final_land_mask", "history_final_ocean_mask",
                 "history_final_basin_candidate_mask", "history_final_water_component_ids", "history_final_origin_plate",
                 "history_final_host_plate"):
        if np.asarray(data[name]).shape != (n,):
            raise ValueError(f"{name} must be a final sample array")
    sea = np.asarray(data["history_final_sea_level_m"], dtype="<f8")
    if sea.shape != (1,) or not math.isfinite(float(sea[0])):
        raise ValueError("history_final_sea_level_m must be one finite value")
    if np.any(np.abs(np.asarray(data["history_coverage_km2"], dtype="<f8") / world.mesh.sample_areas_km2 - 1.0) > 1e-9):
        raise ValueError("history coverage must retain every sample capacity")
    return data, ids


def _map(values: np.ndarray, stops, ids: np.ndarray) -> np.ndarray:
    return _stops_colour(np.asarray(values, dtype="<f8"), stops)[ids]


def _water_rgb(submerged, land, basin, ids: np.ndarray) -> np.ndarray:
    rgb = np.empty(ids.shape + (3,), dtype=np.uint8)
    rgb[...] = (105, 105, 112)
    rgb[np.asarray(land, dtype=bool)[ids]] = _LAND
    rgb[np.asarray(submerged, dtype=bool)[ids]] = _OCEAN
    basin_map = np.asarray(basin, dtype=bool)[ids]
    rgb[basin_map] = _BASIN
    return _hatch_basins(rgb, basin_map)


def _terrain_rgb(data: dict, ids: np.ndarray) -> np.ndarray:
    """Use M2's fixed sea-relative terrain scales against saved final M3 water."""
    height = np.asarray(data["history_final_height_above_sea_m"], dtype="<f8")
    submerged = np.asarray(data["history_final_submerged_mask"], dtype=bool)
    basin = np.asarray(data["history_final_basin_candidate_mask"], dtype=bool)
    sample_rgb = _stops_colour(np.maximum(height, 0.0), _RELIEF_LAND_STOPS)
    sample_rgb[submerged] = _stops_colour(np.maximum(-height[submerged], 0.0), _RELIEF_OCEAN_STOPS)
    sample_rgb[basin] = _BASIN
    return _hatch_basins(sample_rgb[ids], basin[ids])


def _numeric_legend(stops, name: str, unit: str = "m") -> list:
    return [(tuple(int(channel) for channel in colour), f"{name}: {value:g} {unit}") for value, colour in stops]


def _fraction_legend(stops, name: str) -> list:
    return [(tuple(int(channel) for channel in colour), f"{name}: {value:g}") for value, colour in stops]


def _plate_colours(plates: np.ndarray) -> np.ndarray:
    """Stable display colours for saved original plate IDs, including arbitrary IDs."""
    value = np.asarray(plates, dtype=np.uint32) + np.uint32(1)
    value ^= value >> np.uint32(16)
    value *= np.uint32(0x45D9F3B)
    value ^= value >> np.uint32(16)
    return (55 + np.stack((value & 127, (value >> 8) & 127, (value >> 16) & 127), axis=1)).astype(np.uint8)


def _draw_wrapped(draw, text: str, xy: tuple[int, int], width: int, *, font, fill, line_height: int) -> int:
    """Draw a deterministic word-wrapped caption and return its final baseline."""
    words, line, y = text.split(), "", xy[1]
    for word in words:
        trial = f"{line} {word}".strip()
        if line and draw.textlength(trial, font=font) > width:
            draw.text((xy[0], y), line, fill=fill, font=font)
            y += line_height
            line = word
        else:
            line = trial
    if line:
        draw.text((xy[0], y), line, fill=fill, font=font)
        y += line_height
    return y


def _material_map(origins: np.ndarray, created_fraction: np.ndarray, ids: np.ndarray) -> Image.Image:
    provenance = _plate_colours(origins)[ids]
    fraction = _map(created_fraction, _FRACTION_STOPS, ids)
    width, height = ids.shape[1], ids.shape[0]
    panel = Image.new("RGB", (width * 2 + 64, height + 136), _BG)
    panel.paste(Image.fromarray(provenance), (16, 68))
    panel.paste(Image.fromarray(fraction), (width + 48, 68))
    draw = ImageDraw.Draw(panel)
    _draw_wrapped(draw, "M3 / MATERIAL PROVENANCE + CREATED FOOTPRINT", (16, 14), width * 2 + 32, font=_font(14), fill=(241, 245, 249), line_height=14)
    draw.text((16, 51), "ORIGINAL PLATE", fill=(220, 230, 235), font=_font(10))
    draw.text((width + 48, 51), "CREATED FRACTION", fill=(220, 230, 235), font=_font(10))
    bottom = _draw_wrapped(draw, "Left: deterministic colours identify the saved original material plate, not the current host plate.", (16, height + 80), width * 2 + 32, font=_font(9), fill=(200, 215, 227), line_height=11)
    _draw_wrapped(draw, "Right: footprint fraction created during this replay, fixed 0…1; values are not a geological age scale.", (16, bottom + 2), width * 2 + 32, font=_font(9), fill=(200, 215, 227), line_height=11)
    return panel


def _motion_change_map(data: dict, ids: np.ndarray) -> Image.Image:
    times = np.asarray(data["history_times_myr"], dtype="<f8")
    halfway = float(times[-1]) / 2.0
    middle = int(np.flatnonzero(np.isclose(times, halfway, rtol=0.0, atol=1e-12))[0])
    selections = ((0, "INITIAL"), (middle, "HALFTIME"), (len(times) - 1, "FINAL"))
    fields = (
        ("history_elevation_m", "ELEVATION", _ELEVATION_STOPS, "m"),
        ("history_memory_m", "MEMORY", _MEMORY_STOPS, "m"),
        ("history_current_collision_m", "CURRENT COLLISION", _MEMORY_STOPS, "m"),
    )
    height, width = ids.shape
    canvas = Image.new("RGB", (width * 3 + 80, height * 3 + 166), _BG)
    draw = ImageDraw.Draw(canvas)
    draw.text((16, 13), "M3 / MOTION CHANGE / INITIAL, EXACT HALFTIME, FINAL", fill=(241, 245, 249), font=_font(14))
    for row, (field, label, stops, unit) in enumerate(fields):
        for column, (step, phase) in enumerate(selections):
            left, top = 16 + column * (width + 24), 48 + row * (height + 24)
            canvas.paste(Image.fromarray(_map(data[field][step], stops, ids)), (left, top))
            draw.text((left, top - 11), f"{phase} / {label}", fill=(220, 230, 235), font=_font(8))
    _draw_wrapped(draw, "Elevation uses fixed -9000…+9000 m; memory and current collision use fixed 0…6000 m. Values clip at the labelled limits.", (16, height * 3 + 122), width * 3 + 48, font=_font(9), fill=(200, 215, 227), line_height=11)
    return canvas


def _poles(world, data: dict) -> Image.Image:
    size = max(512, min(560, int(getattr(world.config, "image_width", 1024) // 2)))
    radius = (size - 1) / 2.0
    canvas = Image.new("RGB", (size * 2 + 40, size + 112), _BG)
    draw = ImageDraw.Draw(canvas)
    draw.text((18, 14), "M3 / FINAL HISTORY POLES", fill=(241, 245, 249), font=_font(15))
    height = np.asarray(data["history_final_height_above_sea_m"], dtype="<f8")
    submerged = np.asarray(data["history_final_submerged_mask"], dtype=bool)
    basin = np.asarray(data["history_final_basin_candidate_mask"], dtype=bool)
    sample_colours = _stops_colour(np.maximum(height, 0.0), _RELIEF_LAND_STOPS)
    sample_colours[submerged] = _stops_colour(np.maximum(-height[submerged], 0.0), _RELIEF_OCEAN_STOPS)
    sample_colours[basin] = _BASIN
    from .export import locate_samples
    for pole_sign, left, label in ((1, 20, "NORTH (+z)"), (-1, size + 20, "SOUTH (-z)")):
        directions, visible = _pole_directions(size, pole_sign)
        sampled = locate_samples(world.mesh, directions[visible])
        rgb = np.zeros((size * size, 3), dtype=np.uint8)
        rgb[visible] = sample_colours[sampled]
        canvas.paste(Image.fromarray(rgb.reshape(size, size, 3)), (left, 52))
        centre = (left + radius, 52 + radius)
        draw.ellipse((centre[0] - radius, centre[1] - radius, centre[0] + radius, centre[1] + radius), outline=(220, 230, 235), width=2)
        draw.text((centre[0], centre[1] - radius - 16), label, fill=(238, 245, 250), font=_font(12), anchor="mb")
        draw.text((centre[0] + radius + 5, centre[1]), "E", fill=(240, 240, 240), font=_font(10), anchor="lm")
        draw.text((centre[0], centre[1] + radius - 3), "0° lon" if pole_sign > 0 else "180° lon", fill=(200, 215, 227), font=_font(9), anchor="mb")
    draw.text((18, size + 70), "Final history elevation is sampled by spherical triangle lookup. North screen-up is -x; south screen-up is +x.", fill=(200, 215, 227), font=_font(10))
    draw.text((18, size + 87), "Terrain colours use the M2 fixed 0…9000 m ocean-depth and land-relief scales; values clip at the endpoints.", fill=(200, 215, 227), font=_font(9))
    return canvas


def export_history_diagnostics(world, directory: str | Path, ids: np.ndarray) -> Path:
    """Write all deterministic M3 views without changing M0/M1/M2 records or images."""
    data, ids = _history(world, ids)
    path = Path(directory)
    collisions = [path / name for name in DIAGNOSTICS if (path / name).exists()]
    if collisions:
        raise FileExistsError(f"diagnostic already exists: {collisions[0]}; choose a new directory")
    path.mkdir(parents=True, exist_ok=True)
    final_elevation = np.asarray(data["history_elevation_m"][-1], dtype="<f8")
    final_sea = float(np.asarray(data["history_final_sea_level_m"])[0])

    elevation = _terrain_rgb(data, ids)
    _save_map(elevation, f"M3 / FINAL ELEVATION / sea level {final_sea:g} m", _numeric_legend(_RELIEF_OCEAN_STOPS, "Ocean depth") + _numeric_legend(_RELIEF_LAND_STOPS, "Land relief") + ["Final replay elevation uses M2's fixed 0…9000 m ocean-depth and land-relief scales; values clip at the endpoints.", "Purple diagonal hatch is a final submerged basin candidate."], path / "m3_elevation.png")

    final_water = _water_rgb(data["history_final_submerged_mask"], data["history_final_land_mask"], data["history_final_basin_candidate_mask"], ids)
    _save_map(final_water, f"M3 / FINAL WATER CATEGORIES / sea level {final_sea:g} m", [(_OCEAN, "Ocean: final connected numerical ocean"), (_LAND, "Land: final elevation at or above final sea level"), (_BASIN, "Basin candidate: final submerged non-ocean component"), "Masks are persisted final M3 water fields; purple diagonal hatch denotes a basin candidate."], path / "m3_water.png")

    difference = _map(final_elevation - np.asarray(world.terrain.elevation_m, dtype="<f8"), _DIFFERENCE_STOPS, ids)
    _save_map(difference, "M3 / FINAL MINUS M2 ELEVATION", _numeric_legend(_DIFFERENCE_STOPS, "M3 - M2") + ["Signed radial-elevation difference against unchanged M2 terrain; fixed -6000…+6000 m, clipped."], path / "m3_difference.png")

    created = np.clip(np.asarray(data["history_final_created_fraction"], dtype="<f8"), 0.0, 1.0)
    age = np.asarray(data["history_final_known_age_myr"], dtype="<f8")
    age_colours = _stops_colour(np.clip(age, 0.0, 20.0), _AGE_STOPS)
    age_colours[age < 0.0] = _UNKNOWN
    mixed = (created > 0.0) & (created < 1.0) & (age >= 0.0)
    age_colours[mixed] = np.rint(age_colours[mixed] * created[mixed, None] + _UNKNOWN * (1.0 - created[mixed, None])).astype(np.uint8)
    _save_map(age_colours[ids], "M3 / CREATED-MATERIAL AGE / CALIBRATION MYR", _numeric_legend(_AGE_STOPS, "Known created age", "Myr") + [(tuple(_UNKNOWN), "Gray: pre-existing material, age unknown"), "Mixed pixels blend known created material with gray by saved created-footprint fraction.", "Age is replay calibration time, fixed 0…20 Myr; it is not the planet age and values clip."], path / "m3_age.png")

    _material_map(np.asarray(data["history_final_origin_plate"]), created, ids).save(path / "m3_material.png")

    removal = np.asarray(data["history_removed_km2"], dtype="<f8").sum(axis=0) / np.asarray(world.mesh.sample_areas_km2, dtype="<f8")
    _save_map(_map(removal, _FRACTION_STOPS, ids), "M3 / CUMULATIVE REMOVED INVENTORY / SAMPLE-AREA EQUIVALENT", _fraction_legend(_FRACTION_STOPS, "Removed inventory / sample area") + ["Fixed 0…1 scale, clipped. Turnover may exceed one; this map reports cumulative inventory-equivalent removal, not remaining footprint."], path / "m3_removal.png")

    _save_map(_map(data["history_memory_m"][-1], _MEMORY_STOPS, ids), "M3 / FINAL COLLISION MEMORY", _numeric_legend(_MEMORY_STOPS, "Memory") + ["Saved deformation memory only; fixed 0…6000 m, clipped. Decay does not remove material inventory."], path / "m3_memory.png")

    _motion_change_map(data, ids).save(path / "m3_motion_change.png")
    _poles(world, data).save(path / "m3_poles.png")

    fixed = generate_water(world.mesh, final_elevation, sea_level_m=float(world.water.sea_level_m))
    fixed_water = _water_rgb(fixed.submerged_mask, fixed.land_mask, fixed.basin_candidate_mask, ids)
    _save_map(fixed_water, f"M3 / FINAL ELEVATION AT M2 SEA LEVEL {world.water.sea_level_m:g} m", [(_OCEAN, "Ocean at unchanged M2 sea level"), (_LAND, "Land at unchanged M2 sea level"), (_BASIN, "Basin candidate at unchanged M2 sea level"), "Observational reclassification of final elevation at the baseline M2 sea level; authoritative M2 and M3 water fields are unchanged."], path / "m3_fixed_sea_water.png")
    return path
