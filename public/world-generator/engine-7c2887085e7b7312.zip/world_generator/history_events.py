"""Compact numeric event blocks; no per-event Python object ledger."""
import numpy as np
from .history_model import PROFILE

NAMES=('step_ids','cell_ids','cohort_ids','host_plate_ids','other_plate_ids','edge_ids','created_km2','removed_km2')

class EventLog:
    def __init__(self):
        self.blocks={name:[] for name in NAMES}
        self.count=0

    def add(self,step,cell,cohort,host,other,*,created=None,removed=None):
        size=len(cell)
        if not size:return
        self.count+=size
        if self.count>PROFILE['max_events']:
            raise ValueError('M3 event resource budget exceeded (8000000); reduce history duration or plate count')
        values=(step,cell,cohort,host,other,-1,0. if created is None else created,0. if removed is None else removed)
        for j,(name,value) in enumerate(zip(NAMES,values)):
            dtype='<i4' if j<6 else '<f8'
            self.blocks[name].append(np.array(np.broadcast_to(value,(size,)),dtype=dtype,order='C',copy=True))

    def arrays(self):
        result={}
        for j,name in enumerate(NAMES):
            blocks=self.blocks.pop(name)
            result['history_event_'+name]=np.concatenate(blocks) if blocks else np.empty(0,dtype='<i4' if j<6 else '<f8')
        return result
