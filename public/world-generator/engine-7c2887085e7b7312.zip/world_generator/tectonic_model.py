"""The explicit M1 numerical contract; no terrain or history state."""

from dataclasses import dataclass, fields
import numpy as np

TECTONICS_VERSION = 'tectonic-snapshot-v1'
CLASS_NAMES = {-1: 'interior', 0: 'inactive', 1: 'convergent', 2: 'divergent', 3: 'transform', 4: 'mixed'}
ALGORITHMS = {
    'plates': 'competitive-positive-graph-growth-v1',
    'noise': 'spherical-radial-noise-v1',
    'crust': 'area-ranked-independent-noise-v1',
    'motion': 'euler-cross-product-v1',
    'boundary_geometry': 'oriented-circumcentre-dual-v1',
    'polarity': 'crust-pair-seeded-preference-v1',
}

# name: association, trailing shape, dtype, units. N/K/E are resolved by consumers.
SPECS = {
    'plate_ids': ('sample', (), '<i4', 'plate ID'),
    'plate_seed_samples': ('plate', (), '<i4', 'sample ID'),
    'plate_growth_rates': ('plate', (), '<f8', 'relative growth rate'),
    'plate_areas_km2': ('plate', (), '<f8', 'km^2'),
    'plate_axes': ('plate', (3,), '<f8', 'unit vector'),
    'plate_angular_speeds_rad_per_myr': ('plate', (), '<f8', 'rad/Myr'),
    'plate_omega_rad_per_myr': ('plate', (3,), '<f8', 'rad/Myr'),
    'sample_velocity_km_per_myr': ('sample', (3,), '<f8', 'km/Myr'),
    'crust_score': ('sample', (), '<f8', 'dimensionless'),
    'crust_type': ('sample', (), '|u1', '0 oceanic; 1 continental'),
    'boundary_mask': ('edge', (), '|u1', '0 interior; 1 boundary'),
    'boundary_plate_ids': ('edge', (2,), '<i4', 'plate ID; -1 interior'),
    'boundary_face_ids': ('edge', (2,), '<i4', 'face ID; -1 interior'),
    'boundary_endpoints': ('edge', (2, 3), '<f8', 'unit vector; 0 interior'),
    'boundary_midpoints': ('edge', (3,), '<f8', 'unit vector; 0 interior'),
    'boundary_normals': ('edge', (3,), '<f8', 'unit tangent vector A toward B; 0 interior'),
    'boundary_tangents': ('edge', (3,), '<f8', 'unit vector midpoint cross normal; 0 interior'),
    'boundary_lengths_km': ('edge', (), '<f8', 'km; 0 interior'),
    'boundary_opening_km_per_myr': ('edge', (), '<f8', 'km/Myr; positive separation; 0 interior'),
    'boundary_sliding_km_per_myr': ('edge', (), '<f8', 'km/Myr; signed along tangent; 0 interior'),
    'boundary_class': ('edge', (), '|i1', '-1 interior; 0 inactive; 1 convergent; 2 divergent; 3 transform; 4 mixed'),
    'boundary_subducting_plate': ('edge', (), '<i4', 'plate ID; -1 none'),
    'boundary_collision': ('edge', (), '|u1', '1 continental collision; 0 otherwise'),
    'boundary_component_ids': ('edge', (), '<i4', 'minimum edge ID in coherent convergent component; -1 otherwise'),
}


@dataclass(frozen=True)
class Tectonics:
    plate_ids: np.ndarray
    plate_seed_samples: np.ndarray
    plate_growth_rates: np.ndarray
    plate_areas_km2: np.ndarray
    plate_axes: np.ndarray
    plate_angular_speeds_rad_per_myr: np.ndarray
    plate_omega_rad_per_myr: np.ndarray
    sample_velocity_km_per_myr: np.ndarray
    crust_score: np.ndarray
    crust_type: np.ndarray
    boundary_mask: np.ndarray
    boundary_plate_ids: np.ndarray
    boundary_face_ids: np.ndarray
    boundary_endpoints: np.ndarray
    boundary_midpoints: np.ndarray
    boundary_normals: np.ndarray
    boundary_tangents: np.ndarray
    boundary_lengths_km: np.ndarray
    boundary_opening_km_per_myr: np.ndarray
    boundary_sliding_km_per_myr: np.ndarray
    boundary_class: np.ndarray
    boundary_subducting_plate: np.ndarray
    boundary_collision: np.ndarray
    boundary_component_ids: np.ndarray

    def __post_init__(self):
        for array in self.arrays().values():
            array.setflags(write=False)

    def arrays(self) -> dict[str, np.ndarray]:
        return {f.name: getattr(self, f.name) for f in fields(self)}
