"""Versioned numeric storage and an archive-independent canonical SHA-256."""

from dataclasses import fields
import hashlib
import json
from pathlib import Path
import struct
import zipfile
import zlib

import numpy as np

from .model import CONFIG_VERSION, GENERATOR_VERSION, RANDOMNESS_VERSION, SCHEMA_VERSION, TOPOLOGY_VERSION, Mesh, World, WorldConfig
from .randomness import validate_seed
from .sphere import validate_mesh
from .tectonic_model import Tectonics, SPECS, ALGORITHMS, TECTONICS_VERSION
from .validation import validate_tectonics, tectonic_statistics
from .terrain_model import Terrain, SPECS as TERRAIN_SPECS, TERRAIN_VERSION, ALGORITHMS as TERRAIN_ALGORITHMS, PROFILE
from .water_model import Water, SPECS as WATER_SPECS
from .terrain_validation import validate_terrain, validate_m2_layout, terrain_statistics
from .history_model import History, SPECS as HISTORY_SPECS, history_metadata
from .history_validation import validate_history, validate_history_layout

VERSIONS = {
    'schema_version': SCHEMA_VERSION,
    'generator_version': GENERATOR_VERSION,
    'config_version': CONFIG_VERSION,
    'topology_version': TOPOLOGY_VERSION,
    'randomness_version': RANDOMNESS_VERSION,
}
# Immutable historic versions: changing current constants never changes an old artifact's identity.
M0_VERSIONS = {'schema_version':1,'config_version':1,'generator_version':'0.1.0',
               'topology_version':'icosphere-v1','randomness_version':'sha256-pcg64-v1'}
M1_VERSIONS = M0_VERSIONS | {'schema_version':2,'config_version':2,'generator_version':'0.2.0'}
M2_VERSIONS = M1_VERSIONS | {'schema_version':3,'config_version':3,'generator_version':'0.3.0'}
M3_LEGACY_VERSIONS = M2_VERSIONS | {'schema_version':4,'config_version':4,'generator_version':'0.4.0'}
M3_REGIONAL_VERSIONS = VERSIONS
STAGE_VERSIONS = {'m0':M0_VERSIONS,'m1':M1_VERSIONS,'m2':M2_VERSIONS}
UNITS = {
    'positions': 'unit vector', 'faces': 'sample ID', 'edges': 'sample ID',
    'neighbor_offsets': 'offset into neighbors', 'neighbors': 'sample ID',
    'edge_lengths_km': 'km', 'sample_areas_km2': 'km^2',
}


def metadata(world: World) -> dict:
    result = {
        **_versions_for_config(world.config),
        'seed': world.seed,
        'config': world.config.resolved(),
        'coordinates': {
            'handedness': 'right', 'north_axis': '+z',
            'zero_longitude_axis': '+x', 'east_at_zero_longitude': '+y',
            'longitude': 'atan2(y, x), radians in [-pi, pi]',
            'latitude': 'asin(z), radians in [-pi/2, pi/2]',
        },
        'mesh': {
            'sample_count': len(world.mesh.positions),
            'edge_count': len(world.mesh.edges),
            'face_count': len(world.mesh.faces),
            'index_base': 0,
            'face_winding': 'counterclockwise viewed from outside',
            'sample_area_rule': 'one-third of each incident spherical triangle area',
        },
        'arrays': {
            name: {'dtype': array.dtype.str, 'shape': list(array.shape), 'units': UNITS[name]}
            for name, array in sorted(world.mesh.arrays().items())
        },
    }
    if world.config.stage != 'm0':
        result['tectonics'] = {
            'version': TECTONICS_VERSION, 'algorithms': ALGORITHMS,
            'statistics': tectonic_statistics(world),
            'assumptions': 'Kinematic snapshot; independent initial crust; no age, thickness, terrain or force balance.',
            'polarity': 'Oceanic under continental; continental collision; seeded ocean-ocean preference by unordered seed-sample pair.',
            'config_units': {'continental_fraction': 'area fraction', 'angular_speed_scale_rad_per_myr': 'rad/Myr',
                             'motion_tolerance_km_per_myr': 'km/Myr', 'obliquity_ratio': 'dimensionless'},
            'random_streams': ['plates.seeds', 'plates.cost', 'plates.growth', 'crust.field', 'motion.<seed_sample>',
                               'polarity.<lower_seed_sample>.<higher_seed_sample>'],
        }
        if world.tectonics is not None:
            result['arrays'].update({
                name: {'dtype': array.dtype.str, 'shape': list(array.shape), 'units': SPECS[name][3], 'association': SPECS[name][0]}
                for name, array in sorted(world.tectonics.arrays().items())
            })
    if world.config.stage in ('m2', 'm3'):
        result['terrain'] = {
            'version':TERRAIN_VERSION,'algorithms':TERRAIN_ALGORITHMS,'profile':PROFILE,
            'reference':'Metres of radial offset from the unchanged reference sphere; not sea-relative or a geoid.',
            'reconstruction':'elevation_m = baseline_m + uplift_m - subsidence_m + detail_m; uplift/subsidence separately tanh-saturated.',
            'random_streams':['terrain.baseline','terrain.detail','terrain.shear'],
            'assumptions':'Procedural kinematic snapshot; calibrated relief, no effective history, age, density, thickness or erosion.',
            'config_units':{'relief_scale':'dimensionless','detail_scale':'dimensionless','terrain_width_scale':'dimensionless',
                            'response_speed_km_per_myr':'km/Myr','sea_level_m':'m','submerged_fraction':'area fraction'},
        }
        if world.water is not None:
            result['water'] = {
                'version':'area-target-connected-ocean-v1','sea_level_m':world.water.sea_level_m,
                'mode':'area_target' if world.config.submerged_fraction is not None else 'explicit_elevation',
                'submerged_rule':'elevation_m < sea_level_m; equality is land',
                'components':'minimum sample ID; -1 dry; greatest numerical area is ocean, lower ID breaks ties',
                'basins':'Other submerged components are basin candidates with unresolved water status, not filled lakes.',
                'statistics':terrain_statistics(world),
            }
        for record,specs in ((world.terrain,TERRAIN_SPECS),(world.water,WATER_SPECS)):
            if record is not None:
                result['arrays'].update({name:{'dtype':array.dtype.str,'shape':list(array.shape),
                    'units':specs[name][3],'association':specs[name][0]} for name,array in sorted(record.arrays().items())})
    if world.config.stage == 'm3':
        result['history'] = history_metadata(world)
        result['arrays'].update({
            name: {'dtype': array.dtype.str, 'shape': list(array.shape), 'units': HISTORY_SPECS[name][2],
                   'dimensions': list(HISTORY_SPECS[name][0])}
            for name, array in sorted(world.history.arrays().items())
        })
    return result


def _versions_for_config(config: WorldConfig) -> dict:
    if config.stage != 'm3':
        return STAGE_VERSIONS[config.stage]
    return M3_LEGACY_VERSIONS if config.history_terrain_version == 'legacy-v1' else M3_REGIONAL_VERSIONS


def json_bytes(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')


def canonical_hash(world: World) -> str:
    """Hash framed canonical JSON followed by framed array headers and C-order bytes."""
    digest = hashlib.sha256(b'world-generator/canonical-v1\0')

    def add(payload):
        digest.update(struct.pack('<Q', len(payload)))
        digest.update(payload)

    add(json_bytes(metadata(world)))
    for name, array in sorted(world.arrays().items()):
        canonical = np.ascontiguousarray(array, dtype=array.dtype.newbyteorder('<'))
        add(json_bytes({'name': name, 'dtype': canonical.dtype.str, 'shape': list(canonical.shape)}))
        add(canonical.tobytes(order='C'))
    return digest.hexdigest()


def save_world(world: World, directory: str | Path) -> Path:
    """Create a fresh artifact directory. Existing directories are never modified."""
    path = Path(directory)
    if path.exists():
        raise FileExistsError(f'output already exists: {path}; choose a new directory')
    validate_seed(world.seed)
    validate_mesh(world.mesh, world.config)
    validate_tectonics(world)
    validate_terrain(world)
    validate_history(world)
    manifest = metadata(world) | {'canonical_sha256': canonical_hash(world)}
    path.mkdir(parents=True, exist_ok=False)
    # Uncompressed numerical data is quick to inspect and avoids compression dependencies.
    np.savez(path / 'world.npz', **world.arrays())
    (path / 'manifest.json').write_bytes(json_bytes(manifest) + b'\n')
    return path


def load_world(directory: str | Path) -> World:
    """Load v1-v5 without upgrading or rewriting; reject incompatible contracts."""
    path = Path(directory)
    try:
        manifest = json.loads((path / 'manifest.json').read_text())
        if not isinstance(manifest, dict):
            raise ValueError('manifest must be a JSON object')
        schema = manifest.get('schema_version')
        if type(schema) is not int or schema not in (1, 2, 3, 4, 5):
            raise ValueError(f'unsupported schema_version: {schema!r}; supported versions are 1, 2, 3, 4 and 5')
        expected_stage = {1:'m0',2:'m1',3:'m2',4:'m3',5:'m3'}[schema]
        versions = ({4:M3_LEGACY_VERSIONS,5:M3_REGIONAL_VERSIONS}.get(schema)
                    or STAGE_VERSIONS[expected_stage])
        for name, expected in versions.items():
            value = manifest.get(name)
            if type(value) is not type(expected) or value != expected:
                raise ValueError(f'unsupported {name}: {value!r}; supported version is {expected!r}')
        validate_seed(manifest['seed'])
        config_data = manifest['config']
        if schema == 4:
            config = WorldConfig(**config_data, history_terrain_version='legacy-v1')
        else:
            if schema == 5 and config_data.get('history_terrain_version') != 'regional-v2':
                raise ValueError('schema 5 requires config.history_terrain_version to be regional-v2')
            config = WorldConfig(**config_data, **({'stage': 'm0'} if schema == 1 else {}))
        if config.stage != expected_stage:
            raise ValueError('configuration stage does not match artifact schema')
        with np.load(path / 'world.npz', allow_pickle=False) as archive:
            mesh_names = {field.name for field in fields(Mesh)}
            names = (mesh_names | (set(SPECS) if schema >= 2 else set())
                     | (set(TERRAIN_SPECS) | set(WATER_SPECS) if schema >= 3 else set())
                     | (set(HISTORY_SPECS) if schema >= 4 else set()))
            if set(archive.files) != names or len(archive.files) != len(names):
                raise ValueError(f'world.npz arrays do not match the v{schema} contract')
            arrays = {name: archive[name] for name in sorted(names)}
            for name, array in arrays.items():
                if not isinstance(array, np.ndarray) or array.dtype.kind not in 'fiub':
                    raise ValueError(f'invalid world archive array {name}: expected a numeric NumPy array')
            mesh = Mesh(**{name: arrays[name] for name in sorted(mesh_names)})
            tectonics = Tectonics(**{name: arrays[name] for name in sorted(SPECS)}) if schema >= 2 else None
            terrain = Terrain(**{name:arrays[name] for name in TERRAIN_SPECS}) if schema >= 3 else None
            water = Water(sea_level_m=manifest['water']['sea_level_m'],**{name:arrays[name] for name in WATER_SPECS}) if schema >= 3 else None
            history = History({name: arrays[name] for name in HISTORY_SPECS}) if schema >= 4 else None
        world = World(manifest['seed'], config, mesh, tectonics, terrain, water, history)
        validate_m2_layout(world)
        validate_history_layout(world)
        expected_metadata = metadata(world)
        stored_metadata = {key: value for key, value in manifest.items() if key != 'canonical_sha256'}
        if json_bytes(stored_metadata) != json_bytes(expected_metadata):
            raise ValueError(f'manifest metadata or array declarations do not match the v{schema} contract')
        if manifest.get('canonical_sha256') != canonical_hash(world):
            raise ValueError('canonical hash mismatch: world data or metadata has changed')
        validate_mesh(mesh, config)
        validate_tectonics(world)
        validate_terrain(world)
        validate_history(world)
        return world
    except (zipfile.BadZipFile, EOFError, zlib.error) as exc:
        raise ValueError(f'invalid world archive in {path}: {exc}; regenerate or restore world.npz') from exc
    except (KeyError, TypeError, IndexError, OverflowError, json.JSONDecodeError) as exc:
        raise ValueError(f'invalid world manifest in {path}: {exc}') from exc
