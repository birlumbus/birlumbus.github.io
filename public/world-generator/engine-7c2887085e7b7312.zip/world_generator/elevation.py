"""M2 calibrated snapshot terrain, independent of sea level and earlier random streams."""
import numpy as np
from .boundaries import boundary_geometry
from .noise import spherical_noise
from .randomness import stage_rng
from .terrain_model import Terrain, PROFILE as P
from .terrain_geometry import SphericalIndex, compact_kernel, smoothstep, arc_coordinates, arc_distance, line_weights


def crust_margin_distances(mesh, crust_type, radius, width_scale):
    """Exact nearest crust-transition dual arc within capped finite margin distances."""
    continental = crust_type.astype(bool)
    distance = np.where(continental,600.,500.)*width_scale
    mask = crust_type[mesh.edges[:,0]] != crust_type[mesh.edges[:,1]]
    if mask.any():
        geometry = boundary_geometry(mesh,mask,radius)
        index = SphericalIndex(mesh.positions,600*width_scale/radius)
        for edge in np.flatnonzero(mask):
            mid = geometry['boundary_midpoints'][edge]
            extent = 600*width_scale + geometry['boundary_lengths_km'][edge]/2
            ids = index.query(mid,extent/radius)
            if not len(ids):
                continue
            d = arc_distance(mesh.positions[ids],geometry['boundary_endpoints'][edge],mid,
                             geometry['boundary_normals'][edge],radius)
            distance[ids] = np.minimum(distance[ids],d)
    return np.ascontiguousarray(np.where(continental,distance,-distance),dtype='<f8')


def tectonic_relief(positions, radius_km, tectonics, crust_type, edges, config, *, shear_field=None):
    """Return nonnegative raw metre contributions, integrated over physical arc length."""
    up,down = np.zeros(len(positions)),np.zeros(len(positions))
    if config.relief_scale == 0:
        return up,down
    t = tectonics
    scale = config.terrain_width_scale
    along_support = P['along_support_km']*scale
    support = (P['plateau_support_km']+P['along_support_km'])*scale
    index = SphericalIndex(positions,support/radius_km)
    if shear_field is None:
        # Deterministic spatial fallback for controlled geometry callers; production uses a named random field.
        shear_field = np.sin(11*positions[:,0]+7*positions[:,1]-5*positions[:,2])
    for edge in np.flatnonzero(t.boundary_mask):
        opening,sliding = t.boundary_opening_km_per_myr[edge],t.boundary_sliding_km_per_myr[edge]
        threshold = max(config.motion_tolerance_km_per_myr,config.obliquity_ratio*max(abs(opening),abs(sliding)))
        normal_strength = -np.expm1(-(max(abs(opening)-threshold,0)/config.response_speed_km_per_myr)**2)
        shear_strength = -np.expm1(-(max(abs(sliding)-threshold,0)/config.response_speed_km_per_myr)**2)
        if normal_strength == 0 and shear_strength == 0:
            continue
        mid = t.boundary_midpoints[edge]
        length = t.boundary_lengths_km[edge]
        ids = index.query(mid,(support+length/2)/radius_km)
        if not len(ids):
            continue
        across,along = arc_coordinates(positions[ids],mid,t.boundary_normals[edge],radius_km)
        selected = (np.abs(across) < 900*scale) & (np.abs(along) < along_support+length/2)
        ids,across,along = ids[selected],across[selected]/scale,along[selected]
        if not len(ids):
            continue
        weight = line_weights(along,length,along_support)*config.relief_scale
        ca,cb = crust_type[edges[edge]]
        # Original mesh endpoints A/B are independent of display label order.
        # Match crust to physical normal sides even when a fixture reverses boundary orientation.
        first_owner = t.plate_ids[edges[edge,0]]
        if first_owner != t.boundary_plate_ids[edge,0]:
            ca,cb = cb,ca
        u,d = np.zeros(len(ids)),np.zeros(len(ids))
        if normal_strength:
            if opening > 0:
                fraction = float(ca)+(float(cb)-float(ca))*smoothstep((across+200)/400)
                u += normal_strength*(1-fraction)*P['ridge_m']*compact_kernel(across/P['ridge_support_km'])
                d += normal_strength*fraction*P['rift_m']*compact_kernel(across/P['rift_support_km'])
            elif t.boundary_collision[edge]:
                u += normal_strength*(P['collision_core_m']*compact_kernel(across/P['collision_core_support_km'])
                                      +P['plateau_m']*compact_kernel(across/P['plateau_support_km']))
            elif t.boundary_subducting_plate[edge] >= 0:
                # q > 0 is physically overriding, independent of plate IDs / normal orientation.
                sub_a = t.boundary_subducting_plate[edge] == t.boundary_plate_ids[edge,0]
                q = across if sub_a else -across
                d += normal_strength*P['trench_m']*compact_kernel((q+P['trench_offset_km'])/P['trench_support_km'])
                override_continental = cb if sub_a else ca
                prefix = 'continental_arc' if override_continental else 'oceanic_arc'
                u += normal_strength*P[prefix+'_m']*compact_kernel((q-P[prefix+'_offset_km'])/P[prefix+'_support_km'])
        shear = shear_strength*P['shear_m']*compact_kernel(across/P['shear_support_km'])*shear_field[ids]
        up[ids] += weight*(u+np.maximum(shear,0))
        down[ids] += weight*(d+np.maximum(-shear,0))
    return up,down


def _detail(seed,mesh):
    field = stage_rng(seed,'terrain.detail').normal(size=len(mesh.positions))
    steps = int(np.clip(np.ceil((P['detail_correlation_km']/np.median(mesh.edge_lengths_km))**2),1,64))
    degrees = np.diff(mesh.neighbor_offsets)
    for _ in range(steps):
        field = (field+np.add.reduceat(field[mesh.neighbors],mesh.neighbor_offsets[:-1]))/(degrees+1)
    weights = mesh.sample_areas_km2/mesh.sample_areas_km2.sum()
    field -= np.sum(field*weights)
    std = np.sqrt(np.sum(field*field*weights))
    return field/std if std > 1e-15 else np.zeros_like(field)


def generate_elevation(seed,mesh,config,tectonics):
    margin = crust_margin_distances(mesh,tectonics.crust_type,config.radius_km,config.terrain_width_scale)
    x = margin/config.terrain_width_scale
    baseline = np.full(len(x),P['oceanic_baseline_m'])
    knots,heights = P['margin_knots_km'],P['margin_elevations_m']
    for a,b,lo,hi in zip(knots[:-1],knots[1:],heights[:-1],heights[1:]):
        baseline += (hi-lo)*smoothstep((x-a)/(b-a))
    broad = np.tanh(spherical_noise(mesh.positions,stage_rng(seed,'terrain.baseline')))
    amplitude = P['oceanic_variation_m']*smoothstep(-x/500)+P['continental_variation_m']*smoothstep((x-200)/400)
    baseline += amplitude*broad
    shear = np.tanh(spherical_noise(mesh.positions,stage_rng(seed,'terrain.shear')))
    raw_up,raw_down = tectonic_relief(mesh.positions,config.radius_km,tectonics,tectonics.crust_type,mesh.edges,config,shear_field=shear)
    uplift = P['uplift_cap_m']*np.tanh(raw_up/P['uplift_cap_m'])
    subsidence = P['subsidence_cap_m']*np.tanh(raw_down/P['subsidence_cap_m'])
    detail = config.detail_scale*P['detail_bound_m']*np.tanh(_detail(seed,mesh))
    elevation = baseline+uplift-subsidence+detail
    return Terrain(*(np.ascontiguousarray(a,dtype='<f8') for a in (margin,baseline,raw_up,raw_down,uplift,subsidence,detail,elevation)))
