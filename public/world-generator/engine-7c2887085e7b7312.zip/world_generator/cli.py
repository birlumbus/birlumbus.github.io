"""Thin command line over generation, persistence, diagnostics and measurements."""

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys
from time import perf_counter

from .benchmark import benchmark, generate_and_export, environment, peak_rss_mib
from .export import export_diagnostics
from .model import WorldConfig
from .randomness import validate_seed
from .storage import canonical_hash, load_world, save_world
from .generate import update_sea_level
from .validation import tectonic_statistics
from .terrain_validation import terrain_statistics
from .history_model import history_statistics
from .viewer_export import export_viewer


def _configuration(args) -> WorldConfig:
    if args.config:
        data = json.loads(args.config.read_text())
        if not isinstance(data, dict):
            raise ValueError('configuration must be a JSON object')
    else:
        data = asdict(WorldConfig.preset(args.preset or 'preview'))
    for key in ('stage', 'plate_count', 'continental_fraction', 'angular_speed_scale_rad_per_myr',
                'motion_tolerance_km_per_myr', 'obliquity_ratio','relief_scale','detail_scale','terrain_width_scale',
                'response_speed_km_per_myr','history_duration_myr','history_max_steps',
                'history_memory_half_life_myr','history_late_motion_scale','history_terrain_version'):
        value = getattr(args, key, None)
        if value is not None:
            data[key] = value
    if getattr(args,'sea_level_m',None) is not None:
        data.update(sea_level_m=args.sea_level_m,submerged_fraction=None)
    elif getattr(args,'submerged_fraction',None) is not None:
        data.update(submerged_fraction=args.submerged_fraction,sea_level_m=None)
    return WorldConfig(**data)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='M2: deterministic spherical terrain, oceans and diagnostic exports')
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ('generate', 'benchmark'):
        command = commands.add_parser(name)
        command.add_argument('--seed', type=int, required=True, help='unsigned 64-bit world seed')
        settings = command.add_mutually_exclusive_group()
        settings.add_argument('--preset', choices=('preview', 'standard'))
        settings.add_argument('--config', type=Path, help='JSON WorldConfig (unspecified fields use preview defaults)')
        command.add_argument('--out', type=Path, help='fresh output directory')
        command.add_argument('--stage', choices=('m0', 'm1','m2','m3'), help='default m2; m0/m1 retain their original formats')
        command.add_argument('--plate-count', type=int)
        command.add_argument('--continental-fraction', type=float, help='continental crust area fraction, not exposed land')
        command.add_argument('--angular-speed-scale-rad-per-myr', type=float)
        command.add_argument('--motion-tolerance-km-per-myr', type=float)
        command.add_argument('--obliquity-ratio', type=float)
        command.add_argument('--relief-scale',type=float)
        command.add_argument('--detail-scale',type=float)
        command.add_argument('--terrain-width-scale',type=float)
        command.add_argument('--response-speed-km-per-myr',type=float)
        command.add_argument('--history-duration-myr',type=float)
        command.add_argument('--history-max-steps',type=int)
        command.add_argument('--history-memory-half-life-myr',type=float)
        command.add_argument('--history-late-motion-scale',type=float)
        command.add_argument('--history-terrain-version', choices=('legacy-v1', 'regional-v2'))
        sea = command.add_mutually_exclusive_group()
        sea.add_argument('--sea-level-m',type=float,help='sea elevation in fixed-reference metres')
        sea.add_argument('--submerged-fraction',type=float,help='total below-sea-level area target, not guaranteed ocean coverage')
        if name == 'benchmark':
            command.add_argument('--runs', type=int, default=3, help='number of warm exports (1-20); also runs one cold export')
    inspect = commands.add_parser('inspect', help='load, validate and summarize a saved world')
    inspect.add_argument('directory', type=Path)
    export = commands.add_parser('export', help='regenerate diagnostics from saved mesh data')
    export.add_argument('directory', type=Path)
    export.add_argument('--out', required=True, type=Path, help='fresh diagnostic output directory')
    viewer = commands.add_parser('viewer', help='write a self-contained interactive WebGL globe for a saved M2 world')
    viewer.add_argument('directory', type=Path)
    viewer.add_argument('--out', required=True, type=Path, help='fresh directory containing index.html')
    sea_update = commands.add_parser('sea-level-update',help='reclassify water in a saved M2 world and write a fresh complete package')
    sea_update.add_argument('directory',type=Path)
    sea_update.add_argument('--out',required=True,type=Path)
    sea = sea_update.add_mutually_exclusive_group(required=True)
    sea.add_argument('--sea-level-m',type=float)
    sea.add_argument('--submerged-fraction',type=float)
    args = parser.parse_args(argv)
    try:
        if args.command in ('generate', 'benchmark'):
            validate_seed(args.seed)
            config = _configuration(args)
            label = 'custom' if args.config else (args.preset or 'preview')
            prefix = 'benchmark-' if args.command == 'benchmark' else ''
            prefix += config.stage+'-' if config.stage != 'm0' else ''
            destination = args.out or Path('outputs') / f'{prefix}seed-{args.seed}-{label}'
            if args.command == 'benchmark':
                report = benchmark(args.seed, config, destination, args.runs)
            else:
                report = generate_and_export(args.seed, config, destination)
        else:
            if args.command == 'sea-level-update' and args.out.exists():
                raise FileExistsError(f'output already exists: {args.out}; choose a new directory')
            started = perf_counter()
            world = load_world(args.directory)
            if args.command == 'sea-level-update':
                previous_hash = canonical_hash(world)
                loaded = perf_counter()
                world = update_sea_level(world,sea_level_m=args.sea_level_m,submerged_fraction=args.submerged_fraction)
                updated = perf_counter()
                save_world(world,args.out)
                saved = perf_counter()
                export_diagnostics(world,args.out)
                exported = perf_counter()
            report = {
                'seed': world.seed, 'canonical_sha256': canonical_hash(world),
                'sample_count': len(world.mesh.positions), 'edge_count': len(world.mesh.edges),
                'face_count': len(world.mesh.faces), 'valid': True,
                'stage': world.config.stage, 'config': world.config.resolved(),
            }
            report.update(tectonic_statistics(world))
            report.update(terrain_statistics(world))
            report.update(history_statistics(world))
            if args.command == 'sea-level-update':
                report.update(output=str(args.out.resolve()),previous_canonical_sha256=previous_hash,
                    environment=environment(),peak_rss_mib=peak_rss_mib(),
                    timings={'load_validation_seconds':loaded-started,'oceans_generation_seconds':updated-loaded,
                             'data_export_seconds':saved-updated,'diagnostic_export_seconds':exported-saved,
                             'full_update_export_seconds':exported-started})
                (args.out/'run.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
            if args.command == 'export':
                if args.out.exists():
                    raise FileExistsError(f'output already exists: {args.out}; choose a new directory')
                export_diagnostics(world, args.out)
                report.update(output=str(args.out.resolve()), diagnostics=sorted(p.name for p in args.out.iterdir()))
            if args.command == 'viewer':
                export_viewer(world, args.out)
                report.update(output=str(args.out.resolve()), viewer='index.html',
                              source_canonical_sha256=canonical_hash(world))
        print(json.dumps(report, sort_keys=True, indent=2))
        return 0
    except (ValueError, TypeError, OSError) as exc:
        print(f'world-generator: {exc}', file=sys.stderr)
        return 2
