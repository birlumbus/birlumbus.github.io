"""Current M2-calibrated profiles and a separate collision-shortening source."""
import numpy as np
from .terrain_geometry import SphericalIndex,compact_kernel,smoothstep,arc_coordinates,line_weights
from .terrain_model import PROFILE as P
from .boundaries import boundary_motion


def current_relief(world,geometry,hosts,continental,omega,polarity,*,regional_width=None):
    mesh=world.mesh;config=world.config;n=len(mesh.positions);radius=config.radius_km
    up=np.zeros(n);down=np.zeros(n);collision=np.zeros(n);shortening=np.zeros(n)
    if config.relief_scale==0: return up,down,collision,shortening
    pair=hosts[mesh.edges];mask=pair[:,0]!=pair[:,1]
    ids=np.flatnonzero(mask)
    if not len(ids): return up,down,collision,shortening
    opening,sliding=boundary_motion(omega[pair[ids,0]],omega[pair[ids,1]],geometry['boundary_midpoints'][ids],
                                  geometry['boundary_normals'][ids],radius)
    scale=config.terrain_width_scale;along_support=400*scale;support=1300*scale
    index=SphericalIndex(mesh.positions,support/radius)
    for e,o,s in zip(ids,opening,sliding):
        threshold=max(config.motion_tolerance_km_per_myr,config.obliquity_ratio*max(abs(o),abs(s)))
        strength=-np.expm1(-(max(abs(o)-threshold,0)/config.response_speed_km_per_myr)**2)
        if strength==0: continue
        length=geometry['boundary_lengths_km'][e];mid=geometry['boundary_midpoints'][e]
        sample=index.query(mid,(support+length/2)/radius)
        cross,along=arc_coordinates(mesh.positions[sample],mid,geometry['boundary_normals'][e],radius)
        selected=(abs(cross)<900*scale)&(abs(along)<along_support+length/2)
        sample,cross,along=sample[selected],cross[selected]/scale,along[selected]
        if not len(sample): continue
        weight=line_weights(along,length,along_support)*config.relief_scale
        ca,cb=continental[mesh.edges[e]];a,b=pair[e]
        if o>0:
            fraction=ca+(cb-ca)*smoothstep((cross+200)/400)
            up[sample]+=weight*strength*(1-fraction)*2200*compact_kernel(cross/450)
            down[sample]+=weight*strength*fraction*1800*compact_kernel(cross/350)
        else:
            if regional_width is None:
                belt=4000*compact_kernel(cross/350)+2000*compact_kernel(cross/900)
                collision[sample]+=weight*strength*ca*cb*belt
                shortening[sample]+=weight*max(-o-threshold,0)*ca*cb*belt/6000
            for sub_a,mix,override in ((True,(1-ca)*cb,True),(False,ca*(1-cb),True),
                                      (polarity[a,b]==a,(1-ca)*(1-cb),False)):
                if mix<=0: continue
                q=cross if sub_a else -cross
                down[sample]+=weight*strength*mix*3500*compact_kernel((q+200)/200)
                offset,width,height=(300,300,4000) if override else (250,250,7000)
                if regional_width is not None and override:
                    # One coherent accommodation coefficient changes response width;
                    # inverse amplitude preserves the cross-profile area integral.
                    factor=float(regional_width[mesh.edges[e]].mean())
                    offset*=factor;width*=factor;height/=factor
                up[sample]+=weight*strength*mix*height*compact_kernel((q-offset)/width)
    return up,down,collision,shortening
