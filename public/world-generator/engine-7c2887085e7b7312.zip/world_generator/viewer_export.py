"""Deterministic, dependency-free WebGL export for persisted M2 terrain worlds."""

import base64
import json
from pathlib import Path
from textwrap import dedent

import numpy as np

from .model import World
from .storage import canonical_hash


def _encoded(array: np.ndarray, dtype: str) -> str:
    """Return a stable little-endian base64 representation for browser typed arrays."""
    values = np.ascontiguousarray(array, dtype=np.dtype(dtype).newbyteorder("<"))
    return base64.b64encode(values.tobytes(order="C")).decode("ascii")


def _viewer_arrays(world: World) -> dict[str, str]:
    mesh, tectonics, terrain, water = world.mesh, world.tectonics, world.terrain, world.water
    boundary = np.asarray(tectonics.boundary_mask, dtype=bool)
    boundary_edges = np.asarray(mesh.edges[boundary], dtype="<u4")
    boundary_class = np.repeat(np.asarray(tectonics.boundary_class[boundary], dtype="i1"), 2)
    return {
        "positions": _encoded(mesh.positions, "<f4"),
        "faces": _encoded(mesh.faces, "<u4"),
        "edges": _encoded(mesh.edges, "<u4"),
        "elevation": _encoded(terrain.elevation_m, "<f4"),
        "heightAboveSea": _encoded(water.height_above_sea_m, "<f4"),
        "ocean": _encoded(water.ocean_mask, "u1"),
        "basinCandidates": _encoded(water.basin_candidate_mask, "u1"),
        "plateIds": _encoded(tectonics.plate_ids, "<f4"),
        "crustType": _encoded(tectonics.crust_type, "u1"),
        "boundaryEdges": _encoded(boundary_edges, "<u4"),
        "boundaryClass": _encoded(boundary_class, "i1"),
    }


def _html(world: World, *, display_world: World | None = None, seed_as_text: bool = False) -> str:
    """Render display fields while retaining the original world's identity.

    A display-only projection may supply final history terrain and water; it is
    never hashed or persisted as a new authoritative world.
    """
    display = world if display_world is None else display_world
    metadata = {
        "seed": str(world.seed) if seed_as_text else world.seed,
        "sourceCanonicalSha256": canonical_hash(world),
        "sampleCount": len(world.mesh.positions),
        "edgeCount": len(world.mesh.edges),
        "faceCount": len(world.mesh.faces),
        "boundaryCount": int(np.count_nonzero(world.tectonics.boundary_mask)),
        "radiusKm": world.config.radius_km,
        "seaLevelM": display.water.sea_level_m,
        "elevationMinM": float(np.min(display.terrain.elevation_m)),
        "elevationMaxM": float(np.max(display.terrain.elevation_m)),
    }
    data_json = json.dumps(_viewer_arrays(display), sort_keys=True, separators=(",", ":"))
    metadata_json = json.dumps(metadata, sort_keys=True, separators=(",", ":"))
    return dedent(
        """\
        <!doctype html>
        <html lang="en">
        <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>M2 World Globe Viewer</title>
        <style>
        :root { color-scheme: dark; font-family: ui-sans-serif, system-ui, sans-serif; background: #07111f; color: #eef6ff; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; overflow: hidden; background: radial-gradient(circle at 46% 35%, #172d48 0, #0b1728 39%, #040914 100%); }
        #layout { position: fixed; inset: 0; min-width: 0; min-height: 0; }
        #stage { position: absolute; inset: 0 330px 0 0; min-width: 0; min-height: 0; overflow: hidden; }
        canvas { position: absolute; inset: 0; width: 100%; height: 100%; display: block; touch-action: none; cursor: grab; }
        canvas:active { cursor: grabbing; }
        #badge { position: absolute; left: 22px; top: 20px; max-width: calc(100% - 44px); background: #0a1829d9; border: 1px solid #9cc8e144; border-radius: 10px; padding: 12px 14px; box-shadow: 0 9px 30px #0008; }
        #badge h1 { font-size: 15px; letter-spacing: .08em; margin: 0 0 6px; color: #bfe6ff; }
        #badge div { font-size: 12px; color: #cbd9e7; margin-top: 3px; overflow-wrap: anywhere; }
        #panel { position: absolute; inset: 0 0 0 auto; width: 330px; min-width: 0; background: #091625ed; border-left: 1px solid #83b6d033; padding: 21px 18px; overflow: auto; }
        h2 { font-size: 15px; margin: 0 0 16px; letter-spacing: .06em; color: #d5edff; }
        h3 { font-size: 12px; text-transform: uppercase; letter-spacing: .09em; color: #8bb8d8; margin: 19px 0 8px; }
        label { display: block; font-size: 13px; color: #dbe8f4; margin: 10px 0 5px; }
        select, button { width: 100%; background: #142b42; color: #f3f9ff; border: 1px solid #6fa6c966; border-radius: 6px; padding: 8px; font: inherit; }
        button { cursor: pointer; margin-top: 8px; } button:hover { background: #1d405e; }
        input[type=range] { width: 100%; accent-color: #5bd0e8; }
        .check { display: flex; align-items: center; gap: 8px; margin: 9px 0; font-size: 13px; }
        .check input { accent-color: #5bd0e8; }
        #scale-readout, #facts, #legend { font-size: 12px; line-height: 1.45; color: #c4d8e8; }
        #legend { border-left: 3px solid #64cae2; padding: 8px 10px; background: #102236; }
        #legend strong { display: block; color: #f2fbff; margin-bottom: 3px; }
        #help { font-size: 12px; line-height: 1.48; color: #b5c9d9; }
        .swatch { display: inline-block; width: 10px; height: 10px; border-radius: 2px; margin-right: 5px; border: 1px solid #ffffff55; }
        #error { display: none; position: absolute; inset: 0; place-items: center; padding: 30px; text-align: center; color: #ffe0d9; background: #160c12; font-size: 16px; }
        @media (max-width: 820px) { body { overflow: auto; } #layout { position: relative; inset: auto; } #stage { position: relative; inset: auto; width: 100%; height: 66vh; } #panel { position: relative; inset: auto; width: 100%; border-left: 0; border-top: 1px solid #83b6d033; } }
        </style>
        </head>
        <body>
        <main id="layout">
          <section id="stage">
            <canvas id="globe" aria-label="Interactive M2 triangular terrain globe"></canvas>
            <div id="badge"><h1>M2 / INTERACTIVE TERRAIN GLOBE</h1><div id="identity"></div><div id="mesh"></div></div>
            <div id="error"></div>
          </section>
          <aside id="panel">
            <h2>World display</h2>
            <label for="mode">Display mode</label>
            <select id="mode">
              <option value="0">Sea-relative terrain</option>
              <option value="1">Water categories</option>
              <option value="2">Fixed-reference elevation</option>
              <option value="3">M1 plate ownership</option>
              <option value="4">M1 crust type</option>
            </select>
            <label for="exaggeration">Vertical exaggeration</label>
            <input id="exaggeration" type="range" min="1" max="60" value="32" step="1">
            <div id="scale-readout"></div>
            <button id="physical" type="button">Use 1× physical scale</button>
            <label class="check"><input id="wireframe" type="checkbox" checked> Triangle wireframe</label>
            <label class="check"><input id="boundaries" type="checkbox" checked> M1 boundary overlay</label>
            <label class="check"><input id="auto" type="checkbox"> Auto-rotate</label>
            <button id="reset" type="button">Reset view</button>
            <h3>Legend</h3><div id="legend"></div>
            <h3>Reference</h3><div id="facts"></div>
            <h3>Controls</h3><div id="help">Drag to rotate. Scroll or trackpad-pinch to zoom. On touch screens, drag with one finger and pinch with two. The wireframe shows saved icosphere triangle edges. Boundary colours use saved M1 classes.</div>
          </aside>
        </main>
        <script>
        "use strict";
        const metadata=__METADATA__;
        const encoded=__DATA__;
        const text=id=>document.getElementById(id);
        const decode=(value, Type)=>{const raw=atob(value), bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);return new Type(bytes.buffer);};
        const data={positions:decode(encoded.positions,Float32Array),faces:decode(encoded.faces,Uint32Array),edges:decode(encoded.edges,Uint32Array),elevation:decode(encoded.elevation,Float32Array),heightAboveSea:decode(encoded.heightAboveSea,Float32Array),ocean:decode(encoded.ocean,Uint8Array),basinCandidates:decode(encoded.basinCandidates,Uint8Array),plateIds:decode(encoded.plateIds,Float32Array),crustType:decode(encoded.crustType,Uint8Array),boundaryEdges:decode(encoded.boundaryEdges,Uint32Array),boundaryClass:decode(encoded.boundaryClass,Int8Array)};
        text("identity").textContent=`Seed ${metadata.seed} · canonical SHA-256 ${metadata.sourceCanonicalSha256}`;
        text("mesh").textContent=`${metadata.sampleCount.toLocaleString()} samples · ${metadata.faceCount.toLocaleString()} faces · ${metadata.edgeCount.toLocaleString()} edges`;
        text("facts").innerHTML=`Reference sphere radius: <b>${metadata.radiusKm.toLocaleString()} km</b><br>Fixed-reference elevation: ${Math.round(metadata.elevationMinM).toLocaleString()} to ${Math.round(metadata.elevationMaxM).toLocaleString()} m<br>Selected sea level: ${metadata.seaLevelM.toFixed(2)} m<br><br>Elevation is radial offset from the unchanged reference sphere. Sea-relative height is elevation minus selected sea level; equality is exposed land.`;
        const canvas=text("globe"), error=text("error"), gl=canvas.getContext("webgl",{antialias:true,alpha:false});
        if(!gl){error.style.display="grid";error.textContent="This viewer needs a browser with WebGL enabled. The saved world has not been changed.";throw new Error("WebGL unavailable");}
        canvas.addEventListener("webglcontextlost",()=>{error.style.display="grid";error.textContent="The browser lost its WebGL graphics context. Reload this file to restore the globe. The saved world has not been changed.";});
        const useUint=gl.getExtension("OES_element_index_uint");
        if(!useUint){error.style.display="grid";error.textContent="This browser does not support the 32-bit mesh indices required by this viewer.";throw new Error("32-bit index extension unavailable");}
        const terrainVS=`attribute vec3 a_position;attribute float a_elevation;attribute float a_height;attribute float a_ocean;attribute float a_basin;attribute float a_plate;attribute float a_crust;uniform mat4 u_mvp;uniform mat4 u_modelView;uniform float u_exag;uniform float u_radius;varying float v_elevation;varying float v_height;varying float v_ocean;varying float v_basin;varying float v_plate;varying float v_crust;varying float v_light;void main(){float radial=1.0+a_elevation*u_exag/(u_radius*1000.0);vec3 p=a_position*radial;gl_Position=u_mvp*vec4(p,1.0);v_elevation=a_elevation;v_height=a_height;v_ocean=a_ocean;v_basin=a_basin;v_plate=a_plate;v_crust=a_crust;v_light=.62+.38*max(0.0,dot(normalize(mat3(u_modelView)*a_position),normalize(vec3(.35,.45,1.0))));}`;
        const terrainFS=`precision mediump float;uniform int u_mode;uniform float u_elevationMin;uniform float u_elevationMax;varying float v_elevation;varying float v_height;varying float v_ocean;varying float v_basin;varying float v_plate;varying float v_crust;varying float v_light;vec3 mix3(vec3 a,vec3 b,float t){return mix(a,b,clamp(t,0.,1.));}vec3 plate(float n){return .42+.58*vec3(fract(sin(n*12.9898)*43758.5453),fract(sin(n*78.233+2.)*43758.5453),fract(sin(n*39.425+4.)*43758.5453));}void main(){vec3 c;if(u_mode==0){if(v_basin>.5)c=vec3(.47,.18,.68);else if(v_ocean>.5)c=mix3(vec3(.10,.51,.67),vec3(.015,.07,.22),-v_height/6500.);else c=mix3(vec3(.48,.42,.19),mix3(vec3(.26,.52,.20),vec3(.92,.93,.87),v_height/5500.),v_height/1600.);}else if(u_mode==1){c=v_basin>.5?vec3(.55,.22,.76):(v_ocean>.5?vec3(.05,.42,.72):vec3(.67,.59,.28));}else if(u_mode==2){float t=(v_elevation-u_elevationMin)/max(1.,u_elevationMax-u_elevationMin);c=t<.5?mix3(vec3(.025,.08,.24),vec3(.18,.67,.75),t*2.):mix3(vec3(.58,.48,.19),vec3(.96,.96,.91),(t-.5)*2.);}else if(u_mode==3){c=plate(v_plate);}else{c=v_crust>.5?vec3(.74,.55,.25):vec3(.08,.39,.67);}gl_FragColor=vec4(c*v_light,1.);}`;
        const lineVS=`attribute vec3 a_position;attribute float a_elevation;attribute float a_class;uniform mat4 u_mvp;uniform float u_exag;uniform float u_radius;uniform float u_offset;varying float v_class;void main(){float radial=1.0+a_elevation*u_exag/(u_radius*1000.0)+u_offset;gl_Position=u_mvp*vec4(a_position*radial,1.0);v_class=a_class;}`;
        const lineFS=`precision mediump float;uniform int u_boundary;varying float v_class;void main(){vec3 c;if(u_boundary==0)c=vec3(.72,.89,.95);else if(v_class<.5)c=vec3(.58,.63,.67);else if(v_class<1.5)c=vec3(.96,.32,.24);else if(v_class<2.5)c=vec3(.18,.78,.91);else if(v_class<3.5)c=vec3(.98,.78,.22);else c=vec3(.87,.40,.95);gl_FragColor=vec4(c,u_boundary==0?.47:.98);}`;
        const shader=(type,source)=>{const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;};
        const program=(vs,fs)=>{const p=gl.createProgram();gl.attachShader(p,shader(gl.VERTEX_SHADER,vs));gl.attachShader(p,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(p));return p;};
        const terrainProgram=program(terrainVS,terrainFS), lineProgram=program(lineVS,lineFS);
        const buffer=(target,values,usage=gl.STATIC_DRAW)=>{const b=gl.createBuffer();gl.bindBuffer(target,b);gl.bufferData(target,values,usage);return b;};
        const buffers={position:buffer(gl.ARRAY_BUFFER,data.positions),elevation:buffer(gl.ARRAY_BUFFER,data.elevation),height:buffer(gl.ARRAY_BUFFER,data.heightAboveSea),ocean:buffer(gl.ARRAY_BUFFER,data.ocean),basin:buffer(gl.ARRAY_BUFFER,data.basinCandidates),plate:buffer(gl.ARRAY_BUFFER,data.plateIds),crust:buffer(gl.ARRAY_BUFFER,data.crustType),faces:buffer(gl.ELEMENT_ARRAY_BUFFER,data.faces),edges:buffer(gl.ELEMENT_ARRAY_BUFFER,data.edges)};
        const bPositions=new Float32Array(data.boundaryEdges.length*3), bElevation=new Float32Array(data.boundaryEdges.length);for(let i=0;i<data.boundaryEdges.length;i++){const id=data.boundaryEdges[i];bPositions.set(data.positions.subarray(id*3,id*3+3),i*3);bElevation[i]=data.elevation[id];}
        const boundaryBuffers={position:buffer(gl.ARRAY_BUFFER,bPositions),elevation:buffer(gl.ARRAY_BUFFER,bElevation),class:buffer(gl.ARRAY_BUFFER,data.boundaryClass)};
        const attribute=(p,name,b,size,type=gl.FLOAT)=>{const l=gl.getAttribLocation(p,name);if(l<0)return;gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,size,type,false,0,0);};
        const uniform=(p,name)=>gl.getUniformLocation(p,name);
        const mul=(a,b)=>{const r=new Float32Array(16);for(let c=0;c<4;c++)for(let row=0;row<4;row++)r[c*4+row]=a[row]*b[c*4]+a[4+row]*b[c*4+1]+a[8+row]*b[c*4+2]+a[12+row]*b[c*4+3];return r;};
        const perspective=(fovy,aspect,near,far)=>{const f=1/Math.tan(fovy/2),nf=1/(near-far);return new Float32Array([f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*nf,-1,0,0,2*far*near*nf,0]);};
        const translate=z=>new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,z,1]);
        const rotateX=a=>{const c=Math.cos(a),s=Math.sin(a);return new Float32Array([1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1]);};
        const rotateY=a=>{const c=Math.cos(a),s=Math.sin(a);return new Float32Array([c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1]);};
        let yaw=.72,pitch=-.28,distance=3.05,lastFrame=0,framePending=false;const pointers=new Map();let pinchStart=null;
        const schedule=()=>{if(!framePending){framePending=true;requestAnimationFrame(draw);}};
        const reset=()=>{yaw=.72;pitch=-.28;distance=3.05;schedule();};text("reset").onclick=reset;text("physical").onclick=()=>{text("exaggeration").value=1;updatePanel();schedule();};
        const legends=[`<strong>Sea-relative terrain</strong><span class="swatch" style="background:#126f9a"></span>connected ocean, depth shaded<br><span class="swatch" style="background:#657d35"></span>exposed land relief<br><span class="swatch" style="background:#782eae"></span>Basin candidates (unresolved; not confirmed lakes)`, `<strong>Water categories</strong><span class="swatch" style="background:#0d6bb8"></span>ocean<br><span class="swatch" style="background:#ab9748"></span>exposed land<br><span class="swatch" style="background:#8c38c2"></span>Basin candidates (unresolved; not confirmed lakes)`, `<strong>Fixed-reference elevation</strong>Radial metres from the unchanged reference sphere, not sea-relative and not a geoid.`, `<strong>M1 plate ownership</strong>Deterministic display colours identify saved plate IDs.`, `<strong>M1 crust type</strong><span class="swatch" style="background:#1463aa"></span>oceanic crust<br><span class="swatch" style="background:#bd8c40"></span>continental crust`];
        const updatePanel=()=>{const x=Number(text("exaggeration").value);text("scale-readout").textContent=`${x}× vertical exaggeration (${x===1?"physical scale":"1× = physical radial elevation"})`;text("legend").innerHTML=legends[Number(text("mode").value)];};const refresh=()=>{updatePanel();schedule();};text("exaggeration").oninput=refresh;text("mode").onchange=refresh;text("auto").onchange=schedule;text("wireframe").onchange=schedule;text("boundaries").onchange=schedule;updatePanel();
        canvas.addEventListener("wheel",e=>{e.preventDefault();distance=Math.max(1.45,Math.min(8,distance*Math.exp(e.deltaY*.001)));schedule();},{passive:false});
        canvas.addEventListener("pointerdown",e=>{canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size===2){const q=[...pointers.values()];pinchStart={distance:Math.hypot(q[0].x-q[1].x,q[0].y-q[1].y),camera:distance};}});
        canvas.addEventListener("pointermove",e=>{const old=pointers.get(e.pointerId);if(!old)return;const now={x:e.clientX,y:e.clientY};pointers.set(e.pointerId,now);if(pointers.size===1){yaw+=(now.x-old.x)*.008;pitch=Math.max(-1.45,Math.min(1.45,pitch+(now.y-old.y)*.008));}else if(pinchStart){const q=[...pointers.values()],d=Math.hypot(q[0].x-q[1].x,q[0].y-q[1].y);if(d>5)distance=Math.max(1.45,Math.min(8,pinchStart.camera*pinchStart.distance/d));}schedule();});
        const endPointer=e=>{pointers.delete(e.pointerId);if(pointers.size<2)pinchStart=null;};canvas.addEventListener("pointerup",endPointer);canvas.addEventListener("pointercancel",endPointer);
        const lineDraw=(indexBuffer,count,boundary)=>{gl.useProgram(lineProgram);attribute(lineProgram,"a_position",boundary?boundaryBuffers.position:buffers.position,3);attribute(lineProgram,"a_elevation",boundary?boundaryBuffers.elevation:buffers.elevation,1);if(boundary)attribute(lineProgram,"a_class",boundaryBuffers.class,1,gl.BYTE);else{const none=gl.getAttribLocation(lineProgram,"a_class");if(none>=0){gl.disableVertexAttribArray(none);gl.vertexAttrib1f(none,0);}}gl.uniformMatrix4fv(uniform(lineProgram,"u_mvp"),false,currentMvp);gl.uniform1f(uniform(lineProgram,"u_exag"),Number(text("exaggeration").value));gl.uniform1f(uniform(lineProgram,"u_radius"),metadata.radiusKm);gl.uniform1f(uniform(lineProgram,"u_offset"),boundary?.001:.00045);gl.uniform1i(uniform(lineProgram,"u_boundary"),boundary?1:0);if(boundary)gl.drawArrays(gl.LINES,0,count);else{gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,indexBuffer);gl.drawElements(gl.LINES,count,gl.UNSIGNED_INT,0);}};
        let currentMvp=new Float32Array(16);
        const draw=now=>{framePending=false;if(gl.isContextLost())return;const rect=canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1),w=Math.max(1,Math.round(rect.width*dpr)),h=Math.max(1,Math.round(rect.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h);}if(text("auto").checked&&lastFrame)yaw+=(now-lastFrame)*.00018;lastFrame=now;const modelView=mul(translate(-distance),mul(rotateY(yaw),rotateX(pitch))),projection=perspective(.82,w/h,.05,20);currentMvp=mul(projection,modelView);gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);gl.clearColor(.018,.045,.083,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(terrainProgram);attribute(terrainProgram,"a_position",buffers.position,3);attribute(terrainProgram,"a_elevation",buffers.elevation,1);attribute(terrainProgram,"a_height",buffers.height,1);attribute(terrainProgram,"a_ocean",buffers.ocean,1,gl.UNSIGNED_BYTE);attribute(terrainProgram,"a_basin",buffers.basin,1,gl.UNSIGNED_BYTE);attribute(terrainProgram,"a_plate",buffers.plate,1);attribute(terrainProgram,"a_crust",buffers.crust,1,gl.UNSIGNED_BYTE);gl.uniformMatrix4fv(uniform(terrainProgram,"u_mvp"),false,currentMvp);gl.uniformMatrix4fv(uniform(terrainProgram,"u_modelView"),false,modelView);gl.uniform1f(uniform(terrainProgram,"u_exag"),Number(text("exaggeration").value));gl.uniform1f(uniform(terrainProgram,"u_radius"),metadata.radiusKm);gl.uniform1i(uniform(terrainProgram,"u_mode"),Number(text("mode").value));gl.uniform1f(uniform(terrainProgram,"u_elevationMin"),metadata.elevationMinM);gl.uniform1f(uniform(terrainProgram,"u_elevationMax"),metadata.elevationMaxM);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,buffers.faces);gl.drawElements(gl.TRIANGLES,data.faces.length,gl.UNSIGNED_INT,0);gl.depthFunc(gl.LEQUAL);if(text("wireframe").checked)lineDraw(buffers.edges,data.edges.length,false);if(text("boundaries").checked)lineDraw(null,data.boundaryClass.length,true);gl.depthFunc(gl.LESS);if(text("auto").checked)schedule();};schedule();
        new ResizeObserver(schedule).observe(canvas);
        </script>
        </body>
        </html>
        """
    ).replace("__METADATA__", metadata_json).replace("__DATA__", data_json)


def export_viewer(world: World, directory: str | Path) -> Path:
    """Write one fresh self-contained HTML viewer for a validated saved M2 world."""
    if world.config.stage != "m2" or world.terrain is None or world.water is None or world.tectonics is None:
        raise ValueError("viewer requires a saved M2 terrain world; M0/M1 worlds have no persisted terrain to display")
    path = Path(directory)
    if path.exists():
        raise FileExistsError(f"output already exists: {path}; choose a new directory")
    path.mkdir(parents=True, exist_ok=False)
    target = path / "index.html"
    target.write_text(_html(world), encoding="utf-8", newline="\n")
    return target
