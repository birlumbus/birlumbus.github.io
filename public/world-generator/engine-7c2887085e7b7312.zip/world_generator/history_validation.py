"""Structural and replay validation for persisted M3 history records."""

from dataclasses import replace

import numpy as np

from .history_model import History, PROFILE, SPECS


def _fail(message):
    raise ValueError(f'invalid M3 history: {message}')


def _dimensions(world, data):
    return {
        'M': len(data['history_cell_ids']),
        'C': len(data['history_cohort_origin_plate']),
        'H': len(data['history_times_myr']),
        'E': len(data['history_event_step_ids']),
        'P': world.config.plate_count,
        'N': len(world.mesh.positions),
        1: 1,
        3: 3,
    }


def validate_history_layout(world):
    """Validate the complete on-disk history shape before trusting its metadata."""
    history = getattr(world, 'history', None)
    if world.config.stage != 'm3':
        if history is not None:
            _fail('only M3 worlds may contain history fields')
        return
    if not isinstance(history, History):
        _fail('M3 requires a complete History record')
    data = history.data
    if set(data) != set(SPECS):
        _fail('array fields do not match the M3 history contract')
    sizes = _dimensions(world, data)
    for name, (dims, dtype, _) in SPECS.items():
        array = data[name]
        expected_shape = tuple(sizes[dim] for dim in dims)
        if (not isinstance(array, np.ndarray) or array.dtype.str != dtype or array.shape != expected_shape
                or not array.flags.c_contiguous or not np.isfinite(array).all()):
            _fail(f'{name} must be finite {expected_shape} {dtype} C-order data')
    n, p, c, h, e = sizes['N'], sizes['P'], sizes['C'], sizes['H'], sizes['E']
    if not 1 <= h <= world.config.history_max_steps + 1:
        _fail('snapshot count is outside the configured step budget')
    if not c or not sizes['M']:
        _fail('material and cohort ledgers cannot be empty')
    _range(data['history_cell_ids'], 0, n, 'material cell IDs')
    _range(data['history_cohort_ids'], 0, c, 'material cohort IDs')
    _range(data['history_host_plate_ids'], 0, p, 'material host plate IDs')
    _range(data['history_cohort_origin_plate'], 0, p, 'cohort origin plate IDs')
    if np.any(data['history_cohort_crust'] > 1):
        _fail('cohort crust values must be zero or one')
    _range_or_minus_one(data['history_cohort_birth_step'], h, 'cohort birth steps')
    births = data['history_cohort_birth_myr']
    if np.any((births != -1.) & ((births < 0.) | (births > world.config.history_duration_myr))):
        _fail('cohort birth times are outside the configured duration')
    times = data['history_times_myr']
    if times[0] != 0. or times[-1] != world.config.history_duration_myr or np.any(np.diff(times) < 0.):
        _fail('history schedule must start at zero, end at configured duration and be ordered')
    if np.any(data['history_step_displacement_fraction'] > PROFILE['displacement_fraction'] + 1e-12):
        _fail('step displacement exceeds the resource profile')
    if np.any(data['history_step_outflow_fraction'] > PROFILE['outflow_fraction'] + 1e-12):
        _fail('step outflow exceeds the resource profile')
    for name in ('history_footprint_km2', 'history_material_inventory_km2', 'history_coverage_km2',
                 'history_inventory_km2', 'history_created_km2', 'history_removed_km2', 'history_compressed_km2'):
        if np.any(data[name] < 0.):
            _fail(f'{name} cannot be negative')
    _range(data['history_event_step_ids'], 0, h, 'event step IDs')
    _range(data['history_event_cell_ids'], 0, n, 'event cell IDs')
    _range(data['history_event_cohort_ids'], 0, c, 'event cohort IDs')
    _range(data['history_event_host_plate_ids'], 0, p, 'event host plate IDs')
    _range_or_minus_one(data['history_event_other_plate_ids'], p, 'event other plate IDs')
    _range_or_minus_one(data['history_event_edge_ids'], len(world.mesh.edges), 'event edge IDs')
    polarity = data['history_polarity']
    if np.any((polarity < -1) | (polarity >= p)) or not np.array_equal(np.diag(polarity), np.full(p, -1, dtype='<i4')):
        _fail('polarity table contains invalid plate IDs')
    for name in ('history_final_continental_fraction', 'history_final_created_fraction'):
        if np.any((data[name] < 0.) | (data[name] > 1.)):
            _fail(f'{name} must be a footprint fraction')
    ages = data['history_final_known_age_myr']
    if np.any((ages != -1.) & ((ages < 0.) | (ages > world.config.history_duration_myr))):
        _fail('final known ages are outside the configured duration')
    _range(data['history_final_origin_plate'], 0, p, 'final origin plate IDs')
    _range(data['history_final_host_plate'], 0, p, 'final host plate IDs')
    _range_or_minus_one(data['history_final_water_component_ids'], n, 'final water component IDs')
    for name in ('history_final_submerged_mask', 'history_final_land_mask', 'history_final_ocean_mask',
                 'history_final_basin_candidate_mask'):
        if np.any(data[name] > 1):
            _fail(f'{name} must be a Boolean category')
    _validate_accounting(world, data)


def _range(array, lower, upper, label):
    if np.any((array < lower) | (array >= upper)):
        _fail(f'{label} are out of range')


def _range_or_minus_one(array, upper, label):
    if np.any((array < -1) | (array >= upper)):
        _fail(f'{label} are out of range')


def _validate_accounting(world, data):
    capacity = world.mesh.sample_areas_km2
    coverage = data['history_coverage_km2']
    if not np.allclose(coverage, capacity[None, :], rtol=PROFILE['roundoff_relative_tolerance'], atol=0.):
        _fail('coverage must equal every sample capacity at every accepted step')
    total_inventory = data['history_inventory_km2'].sum(axis=1)
    expected = capacity.sum() + np.cumsum(data['history_created_km2'].sum(axis=1) - data['history_removed_km2'].sum(axis=1))
    if not np.allclose(total_inventory, expected, rtol=PROFILE['roundoff_relative_tolerance'], atol=0.):
        _fail('inventory accounting does not reconcile creation and removal')
    ages = data['history_final_known_age_myr']
    if np.any((data['history_final_created_fraction'] == 0.) & (ages != -1.)):
        _fail('samples without created material must retain unknown age')


def validate_history(world):
    """Reject structurally valid but semantically altered M3 replay output."""
    validate_history_layout(world)
    if world.config.stage != 'm3':
        return
    from .history import generate_history

    expected = generate_history(replace(world, history=None)).data
    for name in SPECS:
        actual = world.history.data[name]
        candidate = expected[name]
        if actual.dtype != candidate.dtype or actual.shape != candidate.shape or actual.tobytes() != candidate.tobytes():
            _fail(f'{name} does not match deterministic replay')
