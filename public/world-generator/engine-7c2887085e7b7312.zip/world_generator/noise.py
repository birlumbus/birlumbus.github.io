"""Small deterministic correlated fields on the unit sphere."""

import numpy as np


_KERNEL_COUNT = 32
_KERNEL_SCALES = np.array((0.18, 0.4, 0.8), dtype="<f8")


def spherical_noise(positions: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Return a standardized fixed-cost radial-kernel field on the sphere.

    The kernels are evaluated one at a time, so the working memory is linear in
    the number of samples rather than quadratic in the number of samples.
    """
    points = np.asarray(positions, dtype="<f8")
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("positions must have shape (N, 3)")
    centers = np.asarray(rng.normal(size=(_KERNEL_COUNT, 3)), dtype="<f8")
    centers /= np.linalg.norm(centers, axis=1)[:, None]
    coefficients = np.asarray(rng.normal(size=_KERNEL_COUNT), dtype="<f8")
    scales = np.resize(_KERNEL_SCALES, _KERNEL_COUNT)

    field = np.zeros(len(points), dtype="<f8")
    for center, coefficient, scale in zip(centers, coefficients, scales):
        # Keep the dot product explicit; this avoids platform BLAS warnings
        # observed for the tiny fixed-width kernel vectors on Apple builds.
        dot_products = np.einsum("ij,j->i", points, center, optimize=False)
        radial = np.exp((dot_products - 1.0) / (scale * scale))
        field += coefficient * radial

    field -= field.mean()
    spread = field.std()
    if spread == 0.0:
        return np.zeros(len(points), dtype="<f8")
    return np.ascontiguousarray(field / spread, dtype="<f8")
