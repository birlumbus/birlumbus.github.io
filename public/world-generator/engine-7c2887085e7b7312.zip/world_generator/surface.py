"""Final regional surface without the replay's archival History record.

This rendering result keeps the requested M3 configuration and initial plate
overlays, but has no history hash or history export. Its terrain contains the
final advected baseline/detail and final relief; margin distance still describes
the initial crust. Use generate_world for an authoritative archival world.
"""
from dataclasses import replace
import math
from time import perf_counter

import numpy as np

from .generate import generate_world
from .history import _schedule
from .history_contacts import contact_demands, polarity_table, resolve
from .history_model import PROFILE
from .history_regional import accommodation_field, add_compression_memory
from .history_relief import current_relief
from .history_transport import advect, coalesce, geometry, initial_material, summarize
from .model import World, WorldConfig
from .oceans import generate_water
from .randomness import validate_seed


def _compact_material(material, crust, plate_count):
    """Sum identical host/crust states, retaining footprint and all inventories.

    Transport and removal are linear within each host/crust group; the regional
    memory response is affine in its inventory-weighted memory. Origin and birth
    provenance therefore need not survive in a final rendering. Grouping changes
    floating-point summation order: three standard-world comparisons measured
    at most 1.64e-11 m elevation drift, with identical float32 elevation/gradients
    and categorical water fields. The archival path never uses this operation.
    """
    material.cohort = (2*material.host + crust[material.cohort]).astype('<i4')
    return coalesce(material, plate_count)


def generate_surface(seed: int, config: WorldConfig, *, timings: dict | None = None) -> World:
    """Replay regional-v2 conservatively and retain only its final visible fields.

    The same schedule, contact resolution, inventory checks and regional memory
    update as generate_history are used. Equivalent host/crust material states
    are combined after each resolution, bounding cohorts at two per plate.
    Intermediate relief is unnecessary for compression-based regional memory.
    """
    validate_seed(seed)
    if not isinstance(config, WorldConfig):
        raise ValueError('config must be a WorldConfig')
    if config.stage != 'm3' or config.history_terrain_version != 'regional-v2':
        raise ValueError('final surface generation requires regional-v2 stage m3')
    clock = timings if timings is not None else {}
    total_started = perf_counter()
    for name in ('transport', 'contacts', 'deformation', 'relief', 'water'):
        clock['surface_' + name + '_seconds'] = 0.

    upstream = replace(config, stage='m2', history_duration_myr=4., history_max_steps=32,
                       history_memory_half_life_myr=20., history_late_motion_scale=1.,
                       history_terrain_version='regional-v2')
    world = replace(generate_world(seed, upstream, timings=clock), config=config)
    mesh = world.mesh
    tectonics = world.tectonics
    n = len(mesh.positions)
    p = config.plate_count
    if p * (p-1) // 2 * n * 8 > PROFILE['max_contact_demand_bytes']:
        raise ValueError('M3 contact resource budget exceeded (128 MiB); reduce resolution or plate count')
    if config.history_duration_myr == 0:
        clock['surface_generation_seconds'] = perf_counter() - total_started
        return world

    started = perf_counter()
    g, neighbor, coeff, _, _, _, bound = geometry(mesh, tectonics.plate_omega_rad_per_myr, config.radius_km)
    schedule = _schedule(config, bound)
    clock['surface_transport_seconds'] += perf_counter() - started
    material = initial_material(world)
    crust = np.tile(np.array([0, 1], dtype='u1'), p)
    birth = np.full(2*p, -1.)
    birth_step = np.full(2*p, -1, dtype='<i4')
    origin = np.repeat(np.arange(p, dtype='<i4'), 2)
    polarity = polarity_table(world)
    accommodation = accommodation_field(world)
    initial_total = math.fsum(map(float, mesh.sample_areas_km2))
    created_total = removed_total = 0.

    for step, (time, dt, scale) in enumerate(schedule, 1):
        started = perf_counter()
        demands = contact_demands(material, neighbor, coeff, mesh.sample_areas_km2, dt*scale, p)
        material.values[:, 4] *= math.exp(-math.log(2)*dt/config.history_memory_half_life_myr)
        material = advect(material, neighbor, coeff, dt*scale, n, p)
        clock['surface_transport_seconds'] += perf_counter() - started

        started = perf_counter()
        material, crust, birth, birth_step, origin, created, removed, compressed, _ = resolve(
            world, material, crust, birth, birth_step, origin, time, step, polarity, None, demands)
        material = _compact_material(material, crust, p)
        crust = np.tile(np.array([0, 1], dtype='u1'), p)
        birth = np.full(2*p, -1.)
        birth_step = np.full(2*p, -1, dtype='<i4')
        origin = np.repeat(np.arange(p, dtype='<i4'), 2)
        clock['surface_contacts_seconds'] += perf_counter() - started

        started = perf_counter()
        add_compression_memory(world, material, crust, compressed, accommodation, g['boundary_lengths_km'])
        clock['surface_deformation_seconds'] += perf_counter() - started

        # Preserve the reference's checks without computing age, provenance,
        # dominant hosts or relief at every intermediate time.
        created_total += math.fsum(map(float, created))
        removed_total += math.fsum(map(float, removed))
        actual = math.fsum(map(float, material.sum(n, 1)))
        expected = initial_total + created_total - removed_total
        if abs(actual-expected) > initial_total*1e-12:
            raise ValueError('M3 retained inventory accounting failed')
        if np.max(abs(material.sum(n)/mesh.sample_areas_km2-1)) > 1e-12:
            raise ValueError('M3 incomplete surface coverage')

    started = perf_counter()
    _, _, fields, continental, _, _, hosts, _ = summarize(
        material, n, p, crust, birth, config.history_duration_myr, tectonics.plate_seed_samples)
    up, down, collision, _ = current_relief(
        world, g, hosts, continental,
        tectonics.plate_omega_rad_per_myr*config.history_late_motion_scale,
        polarity, regional_width=accommodation)
    raw_up = up + np.maximum(collision, fields[:, 2])
    final_up = 9000*np.tanh(raw_up/9000)
    final_down = 6000*np.tanh(down/6000)
    elevation = fields[:, 0] + final_up - final_down + fields[:, 1]
    terrain = replace(world.terrain, baseline_m=np.ascontiguousarray(fields[:, 0]),
                      detail_m=np.ascontiguousarray(fields[:, 1]), raw_uplift_m=raw_up,
                      raw_subsidence_m=down, uplift_m=final_up,
                      subsidence_m=final_down, elevation_m=elevation)
    clock['surface_relief_seconds'] += perf_counter() - started

    started = perf_counter()
    water = generate_water(mesh, elevation, sea_level_m=config.sea_level_m,
                           submerged_fraction=config.submerged_fraction)
    clock['surface_water_seconds'] += perf_counter() - started
    clock['surface_generation_seconds'] = perf_counter() - total_started
    return replace(world, terrain=terrain, water=water)
