"""Deterministic M1 tectonic diagnostic views.

The images in this module are observational views of the persisted M1 arrays.  They
never regenerate geometry or use map pixels as an area estimate.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .model import World


DIAGNOSTICS = (
    "plates.png",
    "crust.png",
    "motion.png",
    "boundaries.png",
    "opening.png",
    "sliding.png",
    "tectonic_poles.png",
    "plates.csv",
)

_CLASS_NAMES = {-1: "interior", 0: "inactive", 1: "convergent", 2: "divergent", 3: "transform", 4: "mixed"}
_CLASS_COLOURS = {0: (120, 135, 150), 1: (220, 70, 65), 2: (40, 130, 230), 3: (242, 180, 40), 4: (185, 80, 210)}
_BG = (17, 27, 43)


def _font(size: int):
    return ImageFont.load_default(size=max(10, int(size)))


def _unit(v: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(v, axis=-1, keepdims=True)
    return v / np.maximum(norm, 1e-15)


def _palette(count: int) -> np.ndarray:
    """A fixed, high-contrast RGB palette indexed by plate ID."""
    result = np.empty((count, 3), dtype=np.uint8)
    for i in range(count):
        hue = (i * 0.618033988749895 + 0.07) % 1.0
        # HSV with fixed saturation/value, converted without another dependency.
        h = hue * 6.0
        c, x = 0.78, 0.78 * (1.0 - abs(h % 2.0 - 1.0))
        if h < 1:
            rgb = (c, x, 0.0)
        elif h < 2:
            rgb = (x, c, 0.0)
        elif h < 3:
            rgb = (0.0, c, x)
        elif h < 4:
            rgb = (0.0, x, c)
        elif h < 5:
            rgb = (x, 0.0, c)
        else:
            rgb = (c, 0.0, x)
        result[i] = np.rint((np.asarray(rgb) + 0.12) * 255).clip(0, 255)
    return result


def _lon_lat(points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    points = _unit(np.asarray(points, dtype="<f8"))
    return np.arctan2(points[..., 1], points[..., 0]), np.arcsin(np.clip(points[..., 2], -1.0, 1.0))


def split_spherical_polyline(points: np.ndarray) -> list[np.ndarray]:
    """Split a short spherical polyline at the ±180° longitude seam.

    Returned pieces include seam endpoints on opposite sides, so projecting each
    piece cannot draw a long line across the map.  Great-circle interpolation also
    keeps the helper well-defined near the poles.
    """
    points = np.asarray(points, dtype="<f8")
    if points.ndim != 2 or points.shape[1] != 3 or len(points) < 2:
        return [points.copy()] if len(points) else []
    points = _unit(points)
    output: list[np.ndarray] = []
    current = [points[0]]
    for endpoint in points[1:]:
        start = current[-1]
        # A seam point represented as +0 and -0 (or tiny opposite signed y)
        # must remain on one projected branch; otherwise Pillow draws a full
        # width segment between x=0 and x=W even though the points coincide.
        if start[0] < 0.0 and endpoint[0] < 0.0 and abs(start[1]) < 1e-14 and abs(endpoint[1]) < 1e-14:
            endpoint = endpoint.copy()
            endpoint[1] = math.copysign(0.0, start[1])
            current.append(endpoint)
            continue
        lon_a = float(np.arctan2(start[1], start[0]))
        lon_b = float(np.arctan2(endpoint[1], endpoint[0]))
        raw_delta = lon_b - lon_a
        # +pi and -pi are the same point; avoid a 0/0 seam intersection for
        # exact signed-zero endpoint pairs.
        if np.linalg.norm(endpoint - start) < 1e-14 or abs(endpoint[1] - start[1]) < 1e-14 or abs(raw_delta) <= math.pi:
            current.append(endpoint)
            continue
        # The short great-circle arc crosses y=0 on the negative-x side.  A
        # normalized chord point lies exactly in the great-circle plane; setting
        # signed zero keeps atan2 at the intended +pi/-pi seam branch.
        fraction = float(np.clip(-start[1] / (endpoint[1] - start[1]), 0.0, 1.0))
        seam_point = _unit((1.0 - fraction) * start + fraction * endpoint)
        eastward = raw_delta < 0.0  # 170 -> -170 crosses +180 eastward.
        seam_y = math.copysign(0.0, 1.0 if eastward else -1.0)
        seam_point[1] = seam_y
        seam_point[0] = -abs(float(seam_point[0]))
        current.append(seam_point.copy())
        output.append(np.asarray(current, dtype="<f8"))
        opposite = seam_point.copy()
        opposite[1] = math.copysign(0.0, -1.0 if eastward else 1.0)
        current = [opposite, endpoint]
    output.append(np.asarray(current, dtype="<f8"))
    return output


def _with_longitude(point: np.ndarray, longitude: float) -> np.ndarray:
    point = np.asarray(point, dtype="<f8")
    latitude = math.asin(float(np.clip(point[2], -1.0, 1.0)))
    result = np.array([math.cos(latitude) * math.cos(longitude), math.cos(latitude) * math.sin(longitude), math.sin(latitude)])
    return _unit(result)


def _slerp(a: np.ndarray, b: np.ndarray, fraction: float) -> np.ndarray:
    a, b = _unit(np.asarray(a)), _unit(np.asarray(b))
    dot = float(np.clip(np.dot(a, b), -1.0, 1.0))
    angle = math.acos(dot)
    if angle < 1e-10:
        return _unit((1.0 - fraction) * a + fraction * b)
    return _unit(math.sin((1.0 - fraction) * angle) * a / math.sin(angle) + math.sin(fraction * angle) * b / math.sin(angle))


def _project_equirect(points: np.ndarray, width: int, height: int) -> np.ndarray:
    lon, lat = _lon_lat(points)
    return np.column_stack(((lon + math.pi) * width / (2.0 * math.pi), (math.pi / 2.0 - lat) * height / math.pi))


def _draw_spherical_line(draw: ImageDraw.ImageDraw, points: np.ndarray, origin: tuple[float, float], width: int, height: int, fill, line_width: int = 1):
    for part in split_spherical_polyline(points):
        xy = _project_equirect(part, width, height)
        xy[:, 0] += origin[0]
        xy[:, 1] += origin[1]
        draw.line([tuple(p) for p in xy], fill=fill, width=line_width, joint="curve")


def _map_canvas(base: np.ndarray, title: str, legend: list, gradient: bool = False) -> tuple[Image.Image, ImageDraw.ImageDraw, tuple[float, float]]:
    height, width = base.shape[:2]
    margin_x, top, bottom = 24, 52, 28
    legend_width = max(260, min(420, width // 2 + 180))
    canvas_width = max(width + margin_x * 2 + legend_width, 520)
    legend_font = _font(max(10, width // 128))
    legend_step = legend_font.size + 3
    # A 128px map can still have 16 plate rows.  Grow the canvas vertically so
    # every legend line remains readable instead of clipping the final IDs.
    legend_lines = 1
    for entry in legend:
        line = entry[1] if isinstance(entry, tuple) else entry
        legend_lines += max(1, int(math.ceil(len(line) * legend_font.size * 0.58 / max(1, legend_width - 26))))
    if gradient:
        legend_lines += 2
    canvas_height = max(height + top + bottom, top + 20 + legend_lines * legend_step + bottom)
    canvas = Image.new("RGB", (canvas_width, canvas_height), _BG)
    origin = (margin_x, top)
    canvas.paste(Image.fromarray(np.asarray(base, dtype=np.uint8), "RGB"), (int(origin[0]), int(origin[1])))
    draw = ImageDraw.Draw(canvas)
    draw.text((margin_x, 14), title, fill=(241, 245, 249), font=_font(max(12, width // 80)))
    y = top + 10
    x = margin_x + width + 18
    draw.text((x, top), "LEGEND", fill=(241, 245, 249), font=_font(12))
    if gradient:
        bar_width = max(120, legend_width - 28)
        for i in range(bar_width):
            value = -100.0 + 200.0 * i / max(1, bar_width - 1)
            draw.line((x + i, y, x + i, y + 11), fill=_scalar_colour(value), width=1)
        tick_font = _font(max(9, width // 180))
        draw.text((x, y + 13), "−100", fill=(200, 215, 227), font=tick_font, anchor="lt")
        draw.text((x + bar_width / 2, y + 13), "0", fill=(200, 215, 227), font=tick_font, anchor="mt")
        draw.text((x + bar_width, y + 13), "+100", fill=(200, 215, 227), font=tick_font, anchor="rt")
        y += 30
    for entry in legend:
        swatch = entry[0] if isinstance(entry, tuple) else None
        line = entry[1] if isinstance(entry, tuple) else entry
        if swatch is not None:
            draw.rectangle((x, y + 1, x + 11, y + 11), fill=tuple(int(v) for v in swatch), outline=(230, 235, 240))
            text_x = x + 17
        else:
            text_x = x
        words, current = line.split(), ""
        for word in words:
            trial = f"{current} {word}".strip()
            if draw.textlength(trial, font=legend_font) > legend_width - 26 and current:
                draw.text((text_x, y), current, fill=(200, 215, 227), font=legend_font)
                y += legend_step
                current = word
            else:
                current = trial
        if current:
            draw.text((text_x, y), current, fill=(200, 215, 227), font=legend_font)
            y += legend_step
    for longitude in (-180, -90, 0, 90, 180):
        px = origin[0] + (longitude + 180) * width / 360
        draw.line((px, origin[1], px, origin[1] + height - 1), fill=(95, 113, 130), width=1)
        draw.text((px, origin[1] + height + 3), str(longitude), fill=(205, 218, 228), font=_font(9), anchor="mt")
    for latitude in (-90, -45, 0, 45, 90):
        py = origin[1] + (90 - latitude) * height / 180
        draw.line((origin[0], py, origin[0] + width - 1, py), fill=(95, 113, 130), width=1)
        draw.text((origin[0] - 5, py), str(latitude), fill=(205, 218, 228), font=_font(9), anchor="rm")
    return canvas, draw, origin


def _equirect_rgb(ids: np.ndarray, colours: np.ndarray) -> np.ndarray:
    return colours[np.asarray(ids, dtype=np.int64)]


def select_motion_sites(positions: np.ndarray, plate_ids: np.ndarray, areas: np.ndarray, plate_id: int, max_sites: int = 8, area_totals: np.ndarray | None = None) -> np.ndarray:
    """Select deterministic, spread-out representative sites for one plate."""
    positions = np.asarray(positions, dtype="<f8")
    plate_ids = np.asarray(plate_ids)
    candidates = np.flatnonzero(plate_ids == plate_id)
    if not len(candidates):
        return np.empty(0, dtype="<i4")
    max_sites = max(1, int(max_sites))
    area_values = np.asarray(areas, dtype="<f8")
    area = float(area_values[candidates].sum())
    plate_totals = np.asarray(area_totals) if area_totals is not None else np.bincount(plate_ids.astype(np.int64), weights=area_values)
    largest = float(plate_totals.max()) if len(plate_totals) else area
    count = min(len(candidates), max_sites, max(1, int(math.ceil(max_sites * area / largest))))
    # Seed with the lowest sample ID for stable tie-breaking, then farthest-point sample.
    selected = [int(candidates[0])]
    distances = 1.0 - np.einsum("ij,j->i", positions[candidates], positions[selected[0]])
    while len(selected) < count:
        best = int(np.argmax(distances))
        selected.append(int(candidates[best]))
        distances = np.minimum(distances, 1.0 - np.einsum("ij,j->i", positions[candidates], positions[selected[-1]]))
        distances[np.isin(candidates, selected)] = -1.0
    return np.asarray(selected, dtype="<i4")


def _plate_area_totals(world: World) -> np.ndarray:
    return np.bincount(world.tectonics.plate_ids.astype(np.int64), weights=world.mesh.sample_areas_km2, minlength=world.config.plate_count)


def _display_plate_ids(world: World, max_plates: int = 64) -> np.ndarray:
    areas = np.asarray(world.tectonics.plate_areas_km2)
    order = np.lexsort((np.arange(len(areas)), -areas))
    return np.asarray(order[: min(max_plates, len(order))], dtype="<i4")


def _arrow_path(point: np.ndarray, omega: np.ndarray, radius_km: float, years: float = 20.0) -> np.ndarray:
    tangent = np.cross(omega, point)
    speed = float(np.linalg.norm(tangent) * radius_km)
    if speed < 1e-12:
        return np.asarray([point, point], dtype="<f8")
    direction = tangent / np.linalg.norm(tangent)
    angular_distance = min(math.radians(12.6), speed * years / radius_km)
    ts = np.linspace(0.0, angular_distance, 9)
    return _unit(np.cos(ts)[:, None] * point + np.sin(ts)[:, None] * direction)


def _draw_arrow(draw, path: np.ndarray, origin, width, height, colour, line_width=2):
    parts = split_spherical_polyline(path)
    if not parts or np.linalg.norm(path[-1] - path[0]) < 1e-12:
        return
    for part in parts:
        _draw_spherical_line(draw, part, origin, width, height, colour, line_width)
    last = parts[-1]
    endpoint = _project_equirect(last[-1:], width, height)[0] + np.asarray(origin)
    previous = _project_equirect(last[-2:-1], width, height)[0] + np.asarray(origin)
    direction = endpoint - previous
    norm = float(np.linalg.norm(direction))
    if norm > 1e-9:
        direction /= norm
        side = np.array([-direction[1], direction[0]])
        glyph_length = float(np.linalg.norm(endpoint - (_project_equirect(last[:1], width, height)[0] + np.asarray(origin))))
        head = min(8.0, glyph_length * 0.35)
        if head >= 1.0:
            triangle = [tuple(endpoint), tuple(endpoint - direction * head + side * head * 0.5), tuple(endpoint - direction * head - side * head * 0.5)]
            draw.polygon(triangle, fill=colour)


def _draw_plate_labels(draw, world: World, origin, width, height, colours, plate_ids=None):
    t = world.tectonics
    if plate_ids is None:
        plate_ids = range(len(t.plate_seed_samples))
    for plate in plate_ids:
        seed = t.plate_seed_samples[int(plate)]
        point = _project_equirect(world.mesh.positions[int(seed)][None], width, height)[0] + np.asarray(origin)
        draw.ellipse((point[0] - 7, point[1] - 7, point[0] + 7, point[1] + 7), fill=tuple(int(x) for x in colours[plate]), outline=(255, 255, 255))
        draw.text(tuple(point), str(plate), anchor="mm", fill=(10, 15, 25), font=_font(10))


def _base_maps(world: World, ids: np.ndarray):
    t, mesh = world.tectonics, world.mesh
    plate_count = world.config.plate_count
    plate_colours = _palette(plate_count)
    plates = _equirect_rgb(ids, plate_colours[t.plate_ids])
    crust_colours = np.asarray([(33, 99, 154), (205, 151, 72)], dtype=np.uint8)
    crust = _equirect_rgb(ids, crust_colours[t.crust_type])
    return plates, crust, plate_colours


def _boundary_path(a: np.ndarray, b: np.ndarray, count: int = 8) -> np.ndarray:
    return np.asarray([_slerp(a, b, x) for x in np.linspace(0.0, 1.0, count)], dtype="<f8")


def select_subduction_markers(world: World, max_markers: int = 240, min_spacing_rad: float = 0.08) -> np.ndarray:
    """Choose deterministic, spatially spaced subduction symbols for display."""
    t = world.tectonics
    eligible = [int(i) for i in np.flatnonzero(t.boundary_subducting_plate >= 0)]
    selected: list[int] = []
    cosine = math.cos(float(min_spacing_rad))
    for edge_id in eligible:
        midpoint = t.boundary_midpoints[edge_id]
        if all(float(np.dot(midpoint, t.boundary_midpoints[other])) < cosine for other in selected):
            selected.append(edge_id)
            if len(selected) >= int(max_markers):
                break
    return np.asarray(selected, dtype="<i4")


def _draw_boundary_lines(draw, world, origin, width, height, colour_fn, line_width=2, with_symbols=False):
    t = world.tectonics
    marker_ids = set(select_subduction_markers(world).tolist()) if with_symbols else set()
    for edge_id in np.flatnonzero(t.boundary_mask):
        cls = int(t.boundary_class[edge_id])
        colour = colour_fn(edge_id, cls)
        path = _boundary_path(*t.boundary_endpoints[edge_id])
        _draw_spherical_line(draw, path, origin, width, height, colour, line_width)
        if int(edge_id) in marker_ids:
            midpoint = t.boundary_midpoints[edge_id]
            side = t.boundary_normals[edge_id]
            if int(t.boundary_subducting_plate[edge_id]) == int(t.boundary_plate_ids[edge_id, 0]):
                side = -side
            tip = _unit(midpoint + side * 0.045)
            left = _unit(midpoint + side * 0.015 + t.boundary_tangents[edge_id] * 0.025)
            right = _unit(midpoint + side * 0.015 - t.boundary_tangents[edge_id] * 0.025)
            # Outline/tick paths are seam-safe; filled polygons can wrap across
            # the equirectangular seam and obscure unrelated boundaries.
            marker_colour = (248, 245, 210)
            _draw_spherical_line(draw, np.asarray([left, tip]), origin, width, height, marker_colour, 2)
            _draw_spherical_line(draw, np.asarray([tip, right]), origin, width, height, marker_colour, 2)
            _draw_spherical_line(draw, np.asarray([right, left]), origin, width, height, marker_colour, 2)


def _scalar_colour(value: float, limit: float = 100.0) -> tuple[int, int, int]:
    ratio = float(np.clip(value / limit, -1.0, 1.0))
    neutral = np.asarray((220.0, 220.0, 220.0))
    endpoint = np.asarray((50.0, 100.0, 230.0) if ratio >= 0 else (220.0, 55.0, 55.0))
    return tuple(np.rint(neutral * (1.0 - abs(ratio)) + endpoint * abs(ratio)).astype(int).tolist())


def _export_csv(world: World, path: Path):
    t, mesh = world.tectonics, world.mesh
    total = float(mesh.sample_areas_km2.sum())
    owners = t.plate_ids.astype(np.int64)
    sample_areas = np.asarray(mesh.sample_areas_km2, dtype="<f8")
    area_totals = np.bincount(owners, weights=sample_areas, minlength=world.config.plate_count)
    continental_totals = np.bincount(owners, weights=sample_areas * (t.crust_type == 1), minlength=world.config.plate_count)
    sample_speeds = np.linalg.norm(t.sample_velocity_km_per_myr, axis=1)
    min_speeds = np.full(world.config.plate_count, np.inf)
    max_speeds = np.full(world.config.plate_count, -np.inf)
    np.minimum.at(min_speeds, owners, sample_speeds)
    np.maximum.at(max_speeds, owners, sample_speeds)
    fields = ["ID", "seed_sample", "area_km2", "area_fraction", "continental_fraction", "axis_x", "axis_y", "axis_z", "speed_rad_per_myr", "omega_x_rad_per_myr", "omega_y_rad_per_myr", "omega_z_rad_per_myr", "min_velocity_km_per_myr", "max_velocity_km_per_myr"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for plate in range(world.config.plate_count):
            area = float(t.plate_areas_km2[plate])
            continental = float(continental_totals[plate] / area_totals[plate])
            axis = t.plate_axes[plate]
            omega = t.plate_omega_rad_per_myr[plate]
            writer.writerow({
                "ID": plate, "seed_sample": int(t.plate_seed_samples[plate]), "area_km2": f"{area:.12g}", "area_fraction": f"{area / total:.12g}", "continental_fraction": f"{continental:.12g}",
                "axis_x": f"{axis[0]:.12g}", "axis_y": f"{axis[1]:.12g}", "axis_z": f"{axis[2]:.12g}", "speed_rad_per_myr": f"{t.plate_angular_speeds_rad_per_myr[plate]:.12g}",
                "omega_x_rad_per_myr": f"{omega[0]:.12g}", "omega_y_rad_per_myr": f"{omega[1]:.12g}", "omega_z_rad_per_myr": f"{omega[2]:.12g}", "min_velocity_km_per_myr": f"{min_speeds[plate]:.12g}", "max_velocity_km_per_myr": f"{max_speeds[plate]:.12g}",
            })


def _pole_projection(point: np.ndarray, pole_sign: int, center: tuple[float, float], radius: float) -> tuple[float, float] | None:
    point = _unit(point)
    if float(point[2] * pole_sign) < 0:
        return None
    # Both cameras put east (+y) on screen right.  To preserve a right-handed
    # local frame, north uses screen up=-x and south uses screen up=+x.
    up = -1.0 if pole_sign > 0 else 1.0
    return (center[0] + radius * point[1], center[1] - radius * up * point[0])


def _draw_pole_line(draw, points, pole_sign, center, radius, colour, width=1):
    projected = [_pole_projection(point, pole_sign, center, radius) for point in points]
    for a, b in zip(projected, projected[1:]):
        if a is not None and b is not None:
            draw.line((*a, *b), fill=colour, width=width)


def _draw_projected_arrow(draw, points, pole_sign, center, radius, colour, width=2):
    projected = [_pole_projection(point, pole_sign, center, radius) for point in points]
    if any(item is None for item in projected):
        return
    if np.linalg.norm(np.asarray(points[-1]) - np.asarray(points[0])) < 1e-12:
        return
    draw.line(projected, fill=colour, width=width)
    direction = np.asarray(projected[-1]) - np.asarray(projected[-2])
    norm = float(np.linalg.norm(direction))
    if norm < 1e-9:
        return
    direction /= norm
    side = np.asarray([-direction[1], direction[0]])
    tip = np.asarray(projected[-1])
    glyph_length = float(np.linalg.norm(tip - np.asarray(projected[0])))
    head = min(8.0, glyph_length * 0.35)
    if head >= 1.0:
        draw.polygon([tuple(tip), tuple(tip - direction * head + side * head * 0.5), tuple(tip - direction * head - side * head * 0.5)], fill=colour)


def _pole_map(world: World, plate_colours: np.ndarray) -> Image.Image:
    t, mesh = world.tectonics, world.mesh
    size = max(220, min(560, world.config.image_width // 2 + 150))
    radius = size * 0.38
    centers = [(size * 0.48, size * 0.52), (size * 1.52, size * 0.52)]
    canvas = Image.new("RGB", (max(size * 2 + 30, 760), size + 112), _BG)
    draw = ImageDraw.Draw(canvas)
    draw.text((18, 14), "M1 / TECTONIC POLES", fill=(241, 245, 249), font=_font(15))
    area_totals = _plate_area_totals(world)
    motion_plates = _display_plate_ids(world, 64)
    for pole_sign, center, label in ((1, centers[0], "NORTH (+z)"), (-1, centers[1], "SOUTH (-z)")):
        draw.ellipse((center[0] - radius, center[1] - radius, center[0] + radius, center[1] + radius), fill=(28, 45, 63), outline=(220, 230, 235), width=2)
        # Filled projected mesh triangles provide a continuous ownership field;
        # triangles crossing the limb are omitted and remain hidden behind the rim.
        for face in mesh.faces:
            points = mesh.positions[face]
            projected = [_pole_projection(point, pole_sign, center, radius) for point in points]
            if all(item is not None for item in projected):
                face_owners = t.plate_ids[face]
                owner = int(np.bincount(face_owners.astype(np.int64)).argmax())
                draw.polygon(projected, fill=tuple(int(x) for x in plate_colours[owner]))
        for edge_id in np.flatnonzero(t.boundary_mask):
            path = _boundary_path(*t.boundary_endpoints[edge_id], count=10)
            colour = _CLASS_COLOURS.get(int(t.boundary_class[edge_id]), (115, 130, 145))
            _draw_pole_line(draw, path, pole_sign, center, radius, colour, 2)
        for plate in motion_plates:
            sites = select_motion_sites(mesh.positions, t.plate_ids, mesh.sample_areas_km2, int(plate), area_totals=area_totals)
            for sample_id in sites:
                path = _arrow_path(mesh.positions[sample_id], t.plate_omega_rad_per_myr[plate], world.config.radius_km)
                _draw_projected_arrow(draw, path, pole_sign, center, radius, (250, 245, 220), 2)
        draw.text((center[0], center[1] - radius - 18), label, fill=(238, 245, 250), font=_font(12), anchor="mb")
        draw.text((center[0] + radius + 5, center[1]), "E", fill=(240, 240, 240), font=_font(10), anchor="lm")
        zero_y = center[1] + radius - 5 if pole_sign > 0 else center[1] - radius + 5
        draw.text((center[0], zero_y), "0° lon", fill=(200, 215, 227), font=_font(9), anchor="mb" if pole_sign > 0 else "mt")
    legend_x = 18
    draw.text((legend_x, size + 50), "Filled triangles: face-majority plate ownership approximation. Boundary colours: same classes as boundaries.png.", fill=(200, 215, 227), font=_font(10))
    draw.text((legend_x, size + 68), "Screen axes: +y is right; NORTH screen-up is −x; SOUTH screen-up is +x.", fill=(200, 215, 227), font=_font(9))
    draw.text((legend_x, size + 82), "Arrows are instantaneous 20 Myr display displacements; no history is simulated.", fill=(200, 215, 227), font=_font(9))
    x = size * 1.05
    for code in (1, 2, 3, 4):
        draw.rectangle((x, size + 96, x + 10, size + 106), fill=_CLASS_COLOURS[code])
        draw.text((x + 14, size + 95), _CLASS_NAMES[code], fill=(200, 215, 227), font=_font(9))
        x += 90
    return canvas


def export_tectonic_diagnostics(world: World, directory: str | Path, ids: np.ndarray) -> Path:
    """Export all M1 views from one already-computed equirectangular ID map."""
    if world.tectonics is None:
        raise ValueError("M1 tectonic diagnostics require world.tectonics")
    ids = np.asarray(ids)
    if ids.ndim != 2 or ids.shape[0] < 1 or ids.shape[1] < 1:
        raise ValueError("ids must be a non-empty HxW sample-ID map")
    if np.any(ids < 0) or np.any(ids >= len(world.mesh.positions)):
        raise ValueError("ids contain an out-of-range sample ID")
    path = Path(directory)
    collisions = [path / name for name in DIAGNOSTICS if (path / name).exists()]
    if collisions:
        raise FileExistsError(f"diagnostic already exists: {collisions[0]}; choose a new directory")
    path.mkdir(parents=True, exist_ok=True)
    height, width = ids.shape
    t, mesh = world.tectonics, world.mesh
    plates, crust, plate_colours = _base_maps(world, ids)

    display_plates = _display_plate_ids(world, 32)
    plate_legend = [((tuple(int(x) for x in plate_colours[int(i)])), f"Plate {int(i)}: seed {int(t.plate_seed_samples[int(i)])}") for i in display_plates]
    if len(display_plates) < world.config.plate_count:
        plate_legend.append("Only the 32 largest plates are labelled; all ownership colours and CSV rows remain complete.")
    canvas, draw, origin = _map_canvas(plates, f"M1 / PLATES / seed {world.seed}", ["Fixed display colours identify plate IDs.", "Labels mark persisted plate seed samples."] + plate_legend)
    _draw_plate_labels(draw, world, origin, width, height, plate_colours, display_plates)
    canvas.save(path / "plates.png")

    area_total = float(mesh.sample_areas_km2.sum())
    continental_area = float(mesh.sample_areas_km2[t.crust_type == 1].sum())
    canvas, draw, origin = _map_canvas(crust, f"M1 / CRUST / seed {world.seed}", [((33, 99, 154), "Oceanic crust"), ((205, 151, 72), "Continental crust"), f"Continental area fraction = {continental_area / area_total:.4f} (area-weighted; this is not land fraction)."])
    canvas.save(path / "crust.png")

    zero_plates = [str(i) for i, speed in enumerate(t.plate_angular_speeds_rad_per_myr) if float(speed) == 0.0]
    zero_preview = ", ".join(zero_plates[:32])
    if len(zero_plates) > 32:
        zero_preview += ", …"
    zero_note = f"Zero-speed plates ({len(zero_plates)}): " + (zero_preview if zero_preview else "none") + "; no arrow is drawn."
    canvas, draw, origin = _map_canvas(plates.copy(), f"M1 / MOTION / seed {world.seed}", ["Arrows show instantaneous velocity as a display displacement over 20 Myr; no history is simulated.", "Common scale: 1 km/Myr = 0.1 cm/year; path clipping cap = 12.6°. "+zero_note])
    area_totals = _plate_area_totals(world)
    motion_plates = _display_plate_ids(world, 64)
    for plate in motion_plates:
        sites = select_motion_sites(mesh.positions, t.plate_ids, mesh.sample_areas_km2, int(plate), area_totals=area_totals)
        for sample_id in sites:
            _draw_arrow(draw, _arrow_path(mesh.positions[sample_id], t.plate_omega_rad_per_myr[plate], world.config.radius_km), origin, width, height, (250, 245, 220), 2)
    canvas.save(path / "motion.png")

    class_legend = [((tuple(_CLASS_COLOURS[code])), f"{code}: {_CLASS_NAMES[code]}") for code in (0, 1, 2, 3, 4)]
    class_legend.append(f"Inactive threshold: {world.config.motion_tolerance_km_per_myr:g} km/Myr; obliquity ratio: {world.config.obliquity_ratio:g}.")
    canvas, draw, origin = _map_canvas(np.full_like(plates, (30, 38, 50)), f"M1 / BOUNDARIES / seed {world.seed}", class_legend + ["Triangles/ticks point toward the saved subducting plate; all dual-edge geometry is drawn."])
    _draw_boundary_lines(draw, world, origin, width, height, lambda _e, cls: _CLASS_COLOURS.get(cls, (90, 105, 120)), 2, True)
    canvas.save(path / "boundaries.png")

    for field, filename, title, convention in (("boundary_opening_km_per_myr", "opening.png", "OPENING", "+ = separation; − = convergence"), ("boundary_sliding_km_per_myr", "sliding.png", "SLIDING", "+ = along saved tangent (midpoint × A→B normal); − = opposite")):
        canvas, draw, origin = _map_canvas(np.full_like(plates, (34, 42, 53)), f"M1 / {title} (km/Myr) / seed {world.seed}", [convention, "Fixed signed colour scale −100…+100 km/Myr; saturated values are clipped.", f"Boundary class uses tolerance {world.config.motion_tolerance_km_per_myr:g} km/Myr and obliquity ratio {world.config.obliquity_ratio:g}."], gradient=True)
        values = getattr(t, field)
        _draw_boundary_lines(draw, world, origin, width, height, lambda edge, _cls: _scalar_colour(float(values[edge])), 2)
        canvas.save(path / filename)

    _pole_map(world, plate_colours).save(path / "tectonic_poles.png")
    _export_csv(world, path / "plates.csv")
    return path
