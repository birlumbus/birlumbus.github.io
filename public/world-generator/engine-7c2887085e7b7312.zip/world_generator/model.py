"""Immutable world records. Array rows preserve M0 sample, edge and face IDs."""

from dataclasses import dataclass, fields
import math

import numpy as np
from .tectonic_model import Tectonics
from .terrain_model import Terrain
from .water_model import Water
from .history_model import History, PROFILE as HISTORY_PROFILE

GENERATOR_VERSION = '0.5.0'
SCHEMA_VERSION = 5
CONFIG_VERSION = 5
TOPOLOGY_VERSION = 'icosphere-v1'
RANDOMNESS_VERSION = 'sha256-pcg64-v1'


@dataclass(frozen=True)
class WorldConfig:
    subdivisions: int = 5
    radius_km: float = 6371.0
    image_width: int = 1024
    stage: str = 'm2'
    plate_count: int = 16
    continental_fraction: float = 0.40
    angular_speed_scale_rad_per_myr: float = 0.01
    motion_tolerance_km_per_myr: float = 1.0
    obliquity_ratio: float = 0.25
    relief_scale: float = 1.0
    detail_scale: float = 1.0
    terrain_width_scale: float = 1.0
    response_speed_km_per_myr: float = 50.0
    sea_level_m: float | None = None
    submerged_fraction: float | None = 0.70
    history_duration_myr: float = 4.0
    history_max_steps: int = 32
    history_memory_half_life_myr: float = 20.0
    history_late_motion_scale: float = 1.0
    history_terrain_version: str = 'regional-v2'

    def __post_init__(self):
        if type(self.subdivisions) is not int or not 0 <= self.subdivisions <= 6:
            raise ValueError('subdivisions must be an integer from 0 to 6')
        if type(self.radius_km) not in (int, float) or not 1e-6 <= self.radius_km <= 1e9 or not math.isfinite(self.radius_km):
            raise ValueError('radius_km must be finite and between 1e-6 and 1e9')
        object.__setattr__(self, 'radius_km', float(self.radius_km))
        if type(self.image_width) is not int or not 128 <= self.image_width <= 4096 or self.image_width % 2:
            raise ValueError('image_width must be an even integer from 128 to 4096')
        if type(self.stage) is not str or self.stage not in ('m0', 'm1', 'm2', 'm3'):
            raise ValueError('stage must be m0, m1, m2 or m3')
        maximum = 10 * 4**self.subdivisions + 2 if self.stage != 'm0' else 40962
        if type(self.plate_count) is not int or not 1 <= self.plate_count <= maximum:
            raise ValueError(f'plate_count must be an integer from 1 to sample count ({maximum}); choose fewer plates or stage m0')
        for name, upper in (('continental_fraction', 1.), ('angular_speed_scale_rad_per_myr', 1000.),
                            ('motion_tolerance_km_per_myr', 1e9), ('obliquity_ratio', 1.)):
            value = getattr(self, name)
            if type(value) not in (int, float) or not 0 <= value <= upper or not math.isfinite(value):
                raise ValueError(f'{name} must be finite and between 0 and {upper}')
            if name == 'obliquity_ratio' and value == 1:
                raise ValueError('obliquity_ratio must be less than 1')
            object.__setattr__(self, name, float(value))
        for name,lower,upper in (('relief_scale',0.,10.),('detail_scale',0.,5.),('terrain_width_scale',.1,5.),
                                 ('response_speed_km_per_myr',.01,1e6)):
            value = getattr(self,name)
            if type(value) not in (int,float) or not lower <= value <= upper or not math.isfinite(value):
                raise ValueError(f'{name} must be finite and between {lower} and {upper}')
            object.__setattr__(self,name,float(value))
        if (self.sea_level_m is None) == (self.submerged_fraction is None):
            raise ValueError('specify exactly one of sea_level_m or submerged_fraction (set the other to null)')
        for name,lower,upper in (('sea_level_m',-1e7,1e7),('submerged_fraction',0.,1.)):
            value = getattr(self,name)
            if value is not None:
                if type(value) not in (int,float) or not lower <= value <= upper or not math.isfinite(value):
                    raise ValueError(f'{name} must be finite and between {lower} and {upper}')
                object.__setattr__(self,name,float(value))
        if self.stage in ('m2', 'm3') and 1300*self.terrain_width_scale >= math.pi*self.radius_km/2:
            raise ValueError('M2 terrain support must be smaller than a hemisphere; increase radius_km or reduce terrain_width_scale')
        if self.stage not in ('m2', 'm3'):
            for name in ('relief_scale','detail_scale','terrain_width_scale','response_speed_km_per_myr','sea_level_m','submerged_fraction'):
                if getattr(self,name) != self.__dataclass_fields__[name].default:
                    raise ValueError(f'{name} is an M2 setting and cannot be set in stage {self.stage}')
        for name, lower, upper in (('history_duration_myr', 0., 20.),
                                   ('history_memory_half_life_myr', 1., 1000.),
                                   ('history_late_motion_scale', 0., 2.)):
            value = getattr(self, name)
            if type(value) not in (int, float) or not lower <= value <= upper or not math.isfinite(value):
                raise ValueError(f'{name} must be finite and between {lower} and {upper}')
            object.__setattr__(self, name, float(value))
        if type(self.history_max_steps) is not int or not 1 <= self.history_max_steps <= 32:
            raise ValueError('history_max_steps must be an integer from 1 to 32')
        if type(self.history_terrain_version) is not str or self.history_terrain_version not in ('legacy-v1', 'regional-v2'):
            raise ValueError('history_terrain_version must be legacy-v1 or regional-v2')
        if self.stage != 'm3':
            for name in ('history_duration_myr', 'history_max_steps', 'history_memory_half_life_myr', 'history_late_motion_scale',
                         'history_terrain_version'):
                if getattr(self, name) != self.__dataclass_fields__[name].default:
                    raise ValueError(f'{name} is an M3 setting and cannot be set in stage {self.stage}')
        if self.stage == 'm3' and self.plate_count > HISTORY_PROFILE['max_plate_count']:
            raise ValueError(f"M3 history supports at most {HISTORY_PROFILE['max_plate_count']} plates")
        if self.stage == 'm0':
            for name in ('plate_count', 'continental_fraction', 'angular_speed_scale_rad_per_myr',
                         'motion_tolerance_km_per_myr', 'obliquity_ratio'):
                if getattr(self, name) != self.__dataclass_fields__[name].default:
                    raise ValueError(f'{name} is an M1 setting and cannot be set in stage m0')

    def resolved(self) -> dict:
        """Legacy M0 serialization is exactly its original three fields."""
        names = ('subdivisions', 'radius_km', 'image_width')
        if self.stage != 'm0':
            names += ('stage','plate_count','continental_fraction','angular_speed_scale_rad_per_myr','motion_tolerance_km_per_myr','obliquity_ratio')
        if self.stage in ('m2', 'm3'):
            names += ('relief_scale','detail_scale','terrain_width_scale','response_speed_km_per_myr','sea_level_m','submerged_fraction')
        if self.stage == 'm3':
            names += ('history_duration_myr', 'history_max_steps', 'history_memory_half_life_myr', 'history_late_motion_scale')
            if self.history_terrain_version != 'legacy-v1':
                names += ('history_terrain_version',)
        return {name: getattr(self, name) for name in names}

    @classmethod
    def preset(cls, name: str):
        if name == 'preview':
            return cls()
        if name == 'standard':
            return cls(subdivisions=6, image_width=2048)
        raise ValueError(f'unknown preset: {name!r}; choose preview or standard')


@dataclass(frozen=True)
class Mesh:
    positions: np.ndarray
    faces: np.ndarray
    edges: np.ndarray
    neighbor_offsets: np.ndarray
    neighbors: np.ndarray
    edge_lengths_km: np.ndarray
    sample_areas_km2: np.ndarray

    def __post_init__(self):
        for array in self.arrays().values():
            array.setflags(write=False)

    def arrays(self) -> dict[str, np.ndarray]:
        return {field.name: getattr(self, field.name) for field in fields(self)}

    def neighbors_of(self, sample_id: int) -> np.ndarray:
        if not isinstance(sample_id, (int, np.integer)) or not 0 <= sample_id < len(self.positions):
            raise IndexError('sample_id is outside the mesh')
        return self.neighbors[self.neighbor_offsets[sample_id]:self.neighbor_offsets[sample_id + 1]]


@dataclass(frozen=True)
class World:
    seed: int
    config: WorldConfig
    mesh: Mesh
    tectonics: Tectonics | None = None
    terrain: Terrain | None = None
    water: Water | None = None
    history: History | None = None

    def arrays(self) -> dict[str, np.ndarray]:
        return (self.mesh.arrays() | (self.tectonics.arrays() if self.tectonics is not None else {})
                | (self.terrain.arrays() if self.terrain is not None else {})
                | (self.water.arrays() if self.water is not None else {})
                | (self.history.arrays() if self.history is not None else {}))
