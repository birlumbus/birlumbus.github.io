"""M2 fixed-reference terrain: all per-sample fields are authoritative."""
from dataclasses import dataclass, fields
import numpy as np

TERRAIN_VERSION = 'spherical-snapshot-terrain-v1'
ALGORITHMS = {'influence': 'length-integrated-compact-c2-v1', 'margins': 'spherical-arc-distance-shelf-v1',
              'detail': 'area-normalized-graph-noise-v1', 'saturation': 'separate-tanh-v1'}
PROFILE = {
    'continental_baseline_m': 700., 'oceanic_baseline_m': -4500.,
    'continental_variation_m': 700., 'oceanic_variation_m': 400.,
    'margin_knots_km': [-500., 0., 200., 600.], 'margin_elevations_m': [-4500., -200., -150., 700.],
    'along_support_km': 400., 'collision_core_m': 4000., 'collision_core_support_km': 350.,
    'plateau_m': 2000., 'plateau_support_km': 900., 'trench_m': 3500.,
    'trench_offset_km': 200., 'trench_support_km': 200.,
    'continental_arc_m': 4000., 'continental_arc_offset_km': 300., 'continental_arc_support_km': 300.,
    'oceanic_arc_m': 7000., 'oceanic_arc_offset_km': 250., 'oceanic_arc_support_km': 250.,
    'ridge_m': 2200., 'ridge_support_km': 450., 'rift_m': 1800., 'rift_support_km': 350.,
    'shear_m': 150., 'shear_support_km': 250., 'uplift_cap_m': 9000., 'subsidence_cap_m': 6000.,
    'detail_bound_m': 300., 'detail_correlation_km': 450.,
    'quadrature_order': 4, 'quadrature_step_fraction': .25,
}
SPECS = {name: ('sample', (), '<f8', 'km' if name == 'margin_distance_km' else 'm') for name in (
    'margin_distance_km', 'baseline_m', 'raw_uplift_m', 'raw_subsidence_m', 'uplift_m',
    'subsidence_m', 'detail_m', 'elevation_m')}


@dataclass(frozen=True)
class Terrain:
    margin_distance_km: np.ndarray
    baseline_m: np.ndarray
    raw_uplift_m: np.ndarray
    raw_subsidence_m: np.ndarray
    uplift_m: np.ndarray
    subsidence_m: np.ndarray
    detail_m: np.ndarray
    elevation_m: np.ndarray

    def __post_init__(self):
        for array in self.arrays().values():
            array.setflags(write=False)

    def arrays(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}
