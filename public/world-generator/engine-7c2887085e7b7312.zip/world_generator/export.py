"""Pillow diagnostics built from saved numerical geometry, without extra graphics dependencies."""

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .model import Mesh, World
from .sphere import face_hierarchy
from .tectonic_export import DIAGNOSTICS as TECTONIC_DIAGNOSTICS, export_tectonic_diagnostics
from .terrain_export import DIAGNOSTICS as TERRAIN_DIAGNOSTICS, export_terrain_diagnostics
from .history_export import DIAGNOSTICS as HISTORY_DIAGNOSTICS, export_history_diagnostics

DIAGNOSTICS = ('latlon.png', 'sample_map.png', 'sample_ids.png', 'globe_wireframe.png')


def equirectangular_directions(width: int, height: int) -> np.ndarray:
    """Pixel centres: west to east [-pi, pi], north to south [+pi/2, -pi/2]."""
    lon = (np.arange(width) + 0.5) * (2 * np.pi / width) - np.pi
    lat = np.pi / 2 - (np.arange(height) + 0.5) * (np.pi / height)
    x = np.cos(lat)[:, None] * np.cos(lon)[None, :]
    y = np.cos(lat)[:, None] * np.sin(lon)[None, :]
    z = np.broadcast_to(np.sin(lat)[:, None], (height, width))
    return np.stack((x, y, z), axis=-1)


def locate_samples(mesh: Mesh, directions: np.ndarray) -> np.ndarray:
    """Hierarchical spherical triangle lookup, then nearest corner (lowest ID for ties).

    This diagnostic ownership rule is not a persisted polygonal dual and its image
    footprint is not the area weight. Runtime is O(pixels * subdivision depth).
    """
    levels = face_hierarchy(mesh)
    normals = []
    for faces in levels:
        triangles = mesh.positions[faces]
        inward = np.cross(triangles, np.roll(triangles, -1, axis=1))
        inward /= np.linalg.norm(inward, axis=2)[..., None]
        normals.append(inward)
    output = np.empty(len(directions), dtype='<i4')
    for start in range(0, len(directions), 8192):
        points = directions[start:start + 8192]
        # A point is inside when it is on the inward side of all three great circles.
        scores = np.einsum('pj,fcj->pfc', points, normals[0]).min(axis=2)
        selected = scores.argmax(axis=1)
        for level_normals in normals[1:]:
            children = selected[:, None] * 4 + np.arange(4)
            scores = np.einsum('pj,pfcj->pfc', points, level_normals[children]).min(axis=2)
            selected = children[np.arange(len(points)), scores.argmax(axis=1)]
        corners = np.sort(mesh.faces[selected], axis=1)
        proximity = np.einsum('pj,pcj->pc', points, mesh.positions[corners])
        # Explicit tolerance gives stable lowest-ID ties at edges and poles.
        tied = proximity >= proximity.max(axis=1)[:, None] - 1e-14
        output[start:start + len(points)] = corners[np.arange(len(points)), tied.argmax(axis=1)]
    return output


def _annotated_map(pixels: np.ndarray, title: str, subtitle: str) -> Image.Image:
    height, width = pixels.shape[:2]
    font_size = max(12, width // 100)
    font = ImageFont.load_default(size=font_size)
    small = ImageFont.load_default(size=max(10, font_size - 2))
    left, top = 52, 64
    canvas = Image.new('RGB', (width + 104, height + 138), '#101b2b')
    canvas.paste(Image.fromarray(pixels), (left, top))
    draw = ImageDraw.Draw(canvas)
    draw.text((left, 12), title, font=font, fill='#f1f5f9')
    # Compact exports still have complete captions, wrapped by measured text width.
    words, lines, line = subtitle.split(), [], ''
    for word in words:
        trial = f'{line} {word}'.strip()
        if draw.textlength(trial, font=small) > width and line:
            lines.append(line)
            line = word
        else:
            line = trial
    lines.append(line)
    for i, line in enumerate(lines[:3]):
        draw.text((left, top + height + 30 + i * (font_size + 2)), line, font=small, fill='#b6c5d6')
    for longitude in (-180, -90, 0, 90, 180):
        x = left + (longitude + 180) * width / 360
        draw.line((x, top, x, top + height - 1), fill='#aebfc6', width=1)
        draw.text((x, top + height + 8), str(longitude), font=small, fill='#dbe5ee', anchor='mt')
    for latitude in (-90, -45, 0, 45, 90):
        y = top + (90 - latitude) * height / 180
        draw.line((left, y, left + width - 1, y), fill='#aebfc6', width=1)
        draw.text((left - 8, y), str(latitude), font=small, fill='#dbe5ee', anchor='rm')
    return canvas


def _latlon_colours(positions: np.ndarray) -> np.ndarray:
    longitude = np.arctan2(positions[:, 1], positions[:, 0])
    latitude = np.arcsin(np.clip(positions[:, 2], -1, 1))
    hue = (longitude + np.pi) / (2 * np.pi)
    brightness = 0.45 + 0.5 * (latitude / np.pi + 0.5)
    # Vectorized HSV conversion, using a cyclic colour wheel at the longitude seam.
    channels = np.abs((hue[:, None] * 6 + np.array([0, 4, 2])) % 6 - 3)
    rgb = np.clip(channels - 1, 0, 1)
    rgb = brightness[:, None] * (0.25 + 0.75 * rgb)
    return np.rint(rgb * 255).astype(np.uint8)


def _sample_colours(count: int) -> np.ndarray:
    # Fixed integer colour mixer. Colours are display-only; sample_ids.png is lossless.
    value = np.arange(count, dtype=np.uint32) + np.uint32(1)
    value = ((value ^ (value >> 16)) * np.uint32(0x45D9F3B))
    value = ((value ^ (value >> 16)) * np.uint32(0x45D9F3B))
    value ^= value >> 16
    channels = np.stack((value & 255, (value >> 8) & 255, (value >> 16) & 255), axis=1)
    return (48 + channels * 175 // 255).astype(np.uint8)


def _globe(world: World) -> Image.Image:
    size = max(512, min(world.config.image_width, 1400))
    image = Image.new('RGB', (size, size + 100), '#101b2b')
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default(size=max(14, size // 70))
    radius, cx, cy = size * 0.42, size / 2, size / 2 + 26
    draw.ellipse((cx - radius, cy - radius, cx + radius, cy + radius), fill='#1c3245', outline='#dce8ed', width=2)
    # Camera looks along -x. Screen right = +y (east); screen up = +z (north).
    positions = world.mesh.positions
    segments = positions[world.mesh.edges].copy()
    segments = segments[np.any(segments[:, :, 0] >= 0, axis=1)]
    # Clip edges that cross the limb to x=0, then normalize onto the sphere.
    for endpoint in (0, 1):
        crossing = segments[:, endpoint, 0] < 0
        a, b = segments[crossing, endpoint], segments[crossing, 1 - endpoint]
        fraction = -a[:, 0] / (b[:, 0] - a[:, 0])
        clipped = a + fraction[:, None] * (b - a)
        clipped /= np.linalg.norm(clipped, axis=1)[:, None]
        segments[crossing, endpoint] = clipped
    # Normalized chord samples approximate curved great-circle edges in the view.
    steps = max(2, 16 // (2**world.config.subdivisions))
    for t in np.linspace(0, 1, steps + 1)[:-1]:
        p = segments[:, 0] * (1 - t) + segments[:, 1] * t
        q = segments[:, 0] * (1 - t - 1 / steps) + segments[:, 1] * (t + 1 / steps)
        p /= np.linalg.norm(p, axis=1)[:, None]
        q /= np.linalg.norm(q, axis=1)[:, None]
        coords = np.column_stack((cx + radius * p[:, 1], cy - radius * p[:, 2], cx + radius * q[:, 1], cy - radius * q[:, 2]))
        for segment in coords:
            draw.line(tuple(segment), fill='#77b7bf', width=1)
    draw.text((24, 14), f'M0 / GLOBE WIREFRAME / seed {world.seed}', font=font, fill='#f1f5f9')
    draw.text((cx, cy - radius - 10), 'N / +z', font=font, fill='#f1f5f9', anchor='mb')
    draw.text((cx, cy + radius + 14), 'S / -z', font=font, fill='#f1f5f9', anchor='mt')
    draw.text((24, size + 24), f'{len(positions):,} samples | {len(world.mesh.faces):,} triangles | front: +x', font=font, fill='#c3d1df')
    draw.text((24, size + 54), 'Centre: 0 longitude, 0 latitude. East is right. All front edges shown.', font=font, fill='#c3d1df')
    return image


def export_diagnostics(world: World, directory: str | Path) -> Path:
    path = Path(directory)
    names = (DIAGNOSTICS + (TECTONIC_DIAGNOSTICS if world.tectonics is not None else ())
             + (TERRAIN_DIAGNOSTICS if world.terrain is not None else ())
             + (HISTORY_DIAGNOSTICS if getattr(world, 'history', None) is not None else ()))
    for name in names:
        if (path / name).exists():
            raise FileExistsError(f'diagnostic already exists: {path / name}; choose a new directory')
    path.mkdir(parents=True, exist_ok=True)
    width, height = world.config.image_width, world.config.image_width // 2
    directions = equirectangular_directions(width, height)
    ids = locate_samples(world.mesh, directions.reshape(-1, 3)).reshape(height, width)
    raw = np.stack((ids & 255, (ids >> 8) & 255, (ids >> 16) & 255), axis=-1).astype(np.uint8)
    Image.fromarray(raw).save(path / 'sample_ids.png')
    latlon = _latlon_colours(world.mesh.positions)[ids]
    _annotated_map(latlon, f'M0 / LATITUDE + LONGITUDE / seed {world.seed}',
                   'Sample hue = longitude (cyclic). North is brighter; south is darker. Grid labels are degrees.').save(path / 'latlon.png')
    colours = _sample_colours(len(world.mesh.positions))[ids]
    _annotated_map(colours, f'M0 / SAMPLE IDS / {len(world.mesh.positions):,} samples',
                   'Each colour marks a sample footprint. Exact ID: R + 256*G + 65536*B in unlabelled sample_ids.png.').save(path / 'sample_map.png')
    _globe(world).save(path / 'globe_wireframe.png')
    if world.tectonics is not None:
        export_tectonic_diagnostics(world, path, ids)
    if world.terrain is not None:
        export_terrain_diagnostics(world,path,ids)
    if getattr(world, 'history', None) is not None:
        export_history_diagnostics(world,path,ids)
    return path
