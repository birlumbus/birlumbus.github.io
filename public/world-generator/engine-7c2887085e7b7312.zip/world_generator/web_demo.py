"""Small browser API; generation uses the unchanged numerical engine."""
from dataclasses import replace
import re
from time import perf_counter

from .generate import generate_world
from .model import WorldConfig
from .randomness import validate_seed
from .storage import canonical_hash
from .viewer_export import _html
from .water_model import Water, SPECS as WATER_SPECS


def render_world(world):
    if world.config.stage not in ('m2', 'm3'):
        raise ValueError('demo mode must be m2 or m3')
    display = world
    if world.config.stage == 'm3':
        d = world.history.data
        display = replace(
            world,
            terrain=replace(world.terrain, elevation_m=d['history_elevation_m'][-1]),
            water=Water(sea_level_m=float(d['history_final_sea_level_m'][0]),
                        **{name: d['history_final_' + name] for name in WATER_SPECS}),
        )
    html = _html(world, display_world=display, seed_as_text=True)
    label = 'Evolved terrain · experimental' if world.config.stage == 'm3' else 'Snapshot terrain'
    html = (html.replace('M2 World Globe Viewer', 'World Generator · ' + label)
            .replace('M2 / INTERACTIVE TERRAIN GLOBE', label)
            .replace('Interactive M2 triangular terrain globe', 'Interactive terrain globe')
            .replace('M1 plate ownership', 'Initial plate ownership')
            .replace('M1 crust type', 'Initial crust type')
            .replace('M1 boundary overlay', 'Initial plate boundaries')
            .replace('saved M1 classes', 'initial boundary classes')
            .replace('id="wireframe" type="checkbox" checked', 'id="wireframe" type="checkbox"')
            .replace('id="boundaries" type="checkbox" checked', 'id="boundaries" type="checkbox"'))
    html = html.replace('</style>', '''
        #identity { display: none; }
        #badge h1 { letter-spacing: 0; }
        @media (max-width: 820px) { #stage { height: 380px; } }
        </style>''', 1)
    # The full identity remains available in the downloaded viewer and page details.
    return {'seed': str(world.seed), 'mode': world.config.stage,
            'canonicalSha256': canonical_hash(world), 'html': html}


def generate_demo(seed: str, mode: str = 'm3'):
    if not isinstance(seed, str) or not re.fullmatch(r'[0-9]{1,20}', seed):
        raise ValueError('seed must be a decimal integer from 0 to 18446744073709551615')
    value = int(seed)
    validate_seed(value)
    if mode not in ('m2', 'm3'):
        raise ValueError('demo mode must be m2 or m3')
    started = perf_counter()
    world = generate_world(value, replace(WorldConfig.preset('preview'), stage=mode))
    result = render_world(world)
    result['seconds'] = perf_counter() - started
    return result
