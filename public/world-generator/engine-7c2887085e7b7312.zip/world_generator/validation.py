"""Semantic M1 validation, separate from archive integrity and M0 geometry."""

import numpy as np
from .boundaries import generate_boundaries
from .plates import velocities
from .tectonic_model import SPECS


def validate_tectonics(world):
    t, config, mesh = world.tectonics, world.config, world.mesh
    if config.stage == 'm0':
        if t is not None:
            raise ValueError('M0 world must not contain tectonic arrays')
        return
    if t is None:
        raise ValueError('M1 world requires complete tectonic arrays')
    counts = {'sample': len(mesh.positions), 'plate': config.plate_count, 'edge': len(mesh.edges)}
    for name, (association, tail, dtype, _) in SPECS.items():
        array = getattr(t, name)
        shape = (counts[association],) + tail
        if array.shape != shape or array.dtype.str != dtype or not array.flags.c_contiguous or not np.isfinite(array).all():
            raise ValueError(f'invalid tectonic array: {name}; expected {shape} {dtype} finite C-order data')
    n, k = counts['sample'], counts['plate']
    if np.any(t.plate_ids < 0) or np.any(t.plate_ids >= k):
        raise ValueError('plate_ids must cover samples with valid plate IDs')
    if np.any(t.plate_seed_samples < 0) or np.any(t.plate_seed_samples >= n) or len(np.unique(t.plate_seed_samples)) != k:
        raise ValueError('plate seed samples must be unique valid sample IDs')
    if not np.array_equal(t.plate_ids[t.plate_seed_samples], np.arange(k)):
        raise ValueError('each plate must own its seed sample')
    seen = np.zeros(n, dtype=bool)
    for plate, seed_sample in enumerate(t.plate_seed_samples):
        pending = [int(seed_sample)]
        seen[seed_sample] = True
        while pending:
            for neighbor in mesh.neighbors_of(pending.pop()):
                if not seen[neighbor] and t.plate_ids[neighbor] == plate:
                    seen[neighbor] = True
                    pending.append(int(neighbor))
    if not seen.all():
        raise ValueError('each plate must be connected to its seed')
    expected_areas = np.bincount(t.plate_ids, weights=mesh.sample_areas_km2, minlength=k)
    if np.any(t.plate_areas_km2 <= 0) or not np.allclose(t.plate_areas_km2, expected_areas, rtol=1e-12, atol=0):
        raise ValueError('plate areas must match numerical sample area weights')
    if np.any(t.plate_growth_rates < np.exp(-.7)) or np.any(t.plate_growth_rates > np.exp(.7)):
        raise ValueError('plate growth rates are outside the algorithm range')
    if np.any(t.crust_type > 1):
        raise ValueError('crust_type must be 0 oceanic or 1 continental')
    order = np.lexsort((np.arange(n), -t.crust_score))
    cumulative = np.concatenate(([0.], np.cumsum(mesh.sample_areas_km2[order])))
    chosen = int(np.argmin(np.abs(cumulative - config.continental_fraction * mesh.sample_areas_km2.sum())))
    expected_crust = np.zeros(n, dtype='u1')
    expected_crust[order[:chosen]] = 1
    if not np.array_equal(t.crust_type, expected_crust):
        raise ValueError('crust_type must match the area-ranked crust score and requested fraction')
    if not np.allclose(np.linalg.norm(t.plate_axes, axis=1), 1., rtol=0, atol=1e-12):
        raise ValueError('plate axes must be unit vectors')
    speed, scale = t.plate_angular_speeds_rad_per_myr, config.angular_speed_scale_rad_per_myr
    if np.any(speed < .25 * scale) or np.any(speed > scale):
        raise ValueError('plate angular speeds are outside the configured range')
    if not np.allclose(t.plate_omega_rad_per_myr, t.plate_axes * speed[:, None], rtol=1e-12, atol=0):
        raise ValueError('plate omega must equal axis times angular speed')
    velocity = velocities(t.plate_omega_rad_per_myr[t.plate_ids], mesh.positions, config.radius_km)
    if not np.allclose(t.sample_velocity_km_per_myr, velocity, rtol=1e-12, atol=0):
        raise ValueError('sample velocity must match the spherical Euler field')
    expected = generate_boundaries(world.seed, mesh, config, t.plate_ids, t.crust_type,
                                   t.plate_omega_rad_per_myr, t.plate_seed_samples)
    for name, array in expected.items():
        actual = getattr(t, name)
        equal = np.allclose(actual, array, rtol=1e-12, atol=0) if array.dtype.kind == 'f' else np.array_equal(actual, array)
        if not equal:
            raise ValueError(f'{name} is inconsistent with boundary geometry, motion or polarity rules')


def tectonic_statistics(world):
    t = world.tectonics
    if t is None:
        return {}
    from .tectonic_model import CLASS_NAMES
    total = world.mesh.sample_areas_km2.sum()
    return {
        'plate_count': world.config.plate_count,
        'continental_fraction_requested': world.config.continental_fraction,
        'continental_fraction_achieved': float(np.sum(world.mesh.sample_areas_km2 * t.crust_type) / total),
        'plate_area_min_km2': float(t.plate_areas_km2.min()),
        'plate_area_max_km2': float(t.plate_areas_km2.max()),
        'boundary_segment_count': int(t.boundary_mask.sum()),
        'boundary_length_km': float(t.boundary_lengths_km.sum()),
        'boundary_counts': {name: int(np.count_nonzero(t.boundary_class == code)) for code, name in CLASS_NAMES.items() if code >= 0},
        'collision_segments': int(t.boundary_collision.sum()),
        'subduction_segments': int(np.count_nonzero(t.boundary_subducting_plate >= 0)),
    }
