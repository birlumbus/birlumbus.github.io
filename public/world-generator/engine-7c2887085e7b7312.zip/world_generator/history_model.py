"""M3 immutable authoritative arrays; no observational timings enter this record."""
from dataclasses import dataclass
from types import MappingProxyType
import numpy as np

HISTORY_VERSION='bounded-fractional-euler-history-v1'
PROFILE={'displacement_fraction':.25,'outflow_fraction':.5,'memory_cap_m':6000.,
         'shortening_response_km':100.,'collision_core_support_km':350.,'collision_plateau_support_km':900.,
         'max_events':8000000,'max_contact_demand_bytes':134217728,
         'max_entries_per_sample':64,'max_entries':2621440,'max_plate_count':64,
         'roundoff_relative_tolerance':1e-12}
# (dimension names, dtype, units); H includes the initial snapshot, E is event count.
SPECS={}
def _spec(names,dims,dtype,units):
    for name in names.split(): SPECS['history_'+name]=(dims,dtype,units)
_spec('cell_ids cohort_ids host_plate_ids',('M',),'<i4','ID')
_spec('footprint_km2 material_inventory_km2',('M',),'<f8','km^2')
_spec('material_baseline_m material_detail_m material_memory_m',('M',),'<f8','m')
_spec('cohort_origin_plate',('C',),'<i4','original plate ID')
_spec('cohort_crust',('C',),'|u1','0 oceanic; 1 continental')
_spec('cohort_birth_myr',('C',),'<f8','calibration Myr; -1 pre-existing, age unknown')
_spec('cohort_birth_step',('C',),'<i4','step index; -1 pre-existing')
_spec('times_myr',('H',),'<f8','elapsed calibration Myr')
_spec('motion_scale step_displacement_fraction step_outflow_fraction',('H',),'<f8','dimensionless')
_spec('omega_rad_per_myr',('H','P',3),'<f8','rad/calibration Myr')
_spec('coverage_km2 inventory_km2 created_km2 removed_km2 compressed_km2 correction_km2',('H','N'),'<f8','km^2')
_spec('memory_m elevation_m current_collision_m',('H','N'),'<f8','m')
_spec('event_step_ids event_cell_ids event_cohort_ids event_host_plate_ids event_other_plate_ids event_edge_ids',('E',),'<i4','ID; other plate / edge -1 if absent')
_spec('event_created_km2 event_removed_km2',('E',),'<f8','km^2 material inventory')
_spec('polarity',('P','P'),'<i4','physically subducting plate ID; -1 diagonal')
_spec('final_baseline_m final_detail_m final_uplift_m final_subsidence_m final_height_above_sea_m',('N',),'<f8','m')
_spec('final_continental_fraction final_created_fraction',('N',),'<f8','footprint fraction')
_spec('final_known_age_myr',('N',),'<f8','mean age of created footprint in calibration Myr; -1 none')
_spec('final_origin_plate final_host_plate final_water_component_ids',('N',),'<i4','ID; water -1 dry')
_spec('final_submerged_mask final_land_mask final_ocean_mask final_basin_candidate_mask',('N',),'|u1','Boolean category')
_spec('final_sea_level_m', (1,),'<f8','m')

@dataclass(frozen=True)
class History:
    data: object
    def __post_init__(self):
        data=dict(self.data)
        for value in data.values(): value.setflags(write=False)
        object.__setattr__(self,'data',MappingProxyType(data))
    def arrays(self): return dict(self.data)


def history_metadata(world):
    result={'version':HISTORY_VERSION,'profile':PROFILE,
        'assumptions':'Experimental forward replay of an arbitrary M1 snapshot. Myr is a calibration unit, not planetary age. Initial material age is unknown. Finite-volume fractions diffuse numerically; no physical density, thickness, erosion or force balance.',
        'material':'Saved lumped sample areas are capacities; closed dual-edge Euler fluxes transport fractional footprint and reference inventory. Collision compression retains inventory.',
        'provenance':'Original plate/crust and creation cohort; not original-sample genealogy. Birth times are accepted step ends. Events retain each contributing plate pair and resolution cell; edge -1 denotes a diffuse cell contact, not a reconstructed polygon arc.',
        'contacts':'Pairwise differences of incoming Euler flux times cross-host fractions determine signed demands before transport. Collision hosts are selected within connected positive continental contact components, by continental footprint then immutable seed ID.',
        'memory':'Collision shortening; exponential 100 km response, 6000 m cap, configured time half-life; current collision and memory combine by maximum before uplift saturation.',
        'random_streams':['history.polarity.<lower_seed_sample>.<higher_seed_sample>'],
        'config_units':{'history_duration_myr':'calibration Myr','history_max_steps':'count',
            'history_memory_half_life_myr':'calibration Myr','history_late_motion_scale':'dimensionless'},
        'age_unknown_value':-1.,'initial_snapshot_index':0,
        'final_sea_level_m':float(world.history.data['history_final_sea_level_m'][0])}
    if getattr(world.config,'history_terrain_version','legacy-v1')=='regional-v2':
        from .history_regional import REGIONAL_VERSION,REGIONAL_PROFILE
        result.update(version=REGIONAL_VERSION,profile=PROFILE|{'regional':REGIONAL_PROFILE},
            memory='Resolved continental compression only; area-conservative bounded graph spreading of exposure, exponential strain response, 6000 m cap and configured time decay. No instantaneous continental collision strip; initial M2 checkpoint is retained unchanged.',
            regional_response='One static coherent spherical accommodation field controls spreading and continental arc width. It is a procedural response coefficient, not material lithology. Continental footprint restricts spatial support. Spreading does not modify material or its compression ledger.',
            random_streams=result['random_streams']+[REGIONAL_PROFILE['accommodation_stream']])
    return result


def history_statistics(world):
    if getattr(world,'history',None) is None: return {}
    d=world.history.data
    area=world.mesh.sample_areas_km2
    clipping={}
    for name,values,low,high,units in (
        ('final_sea_relative_elevation',d['history_final_height_above_sea_m'],-9000.,9000.,'m'),
        ('difference',d['history_elevation_m'][-1]-world.terrain.elevation_m,-6000.,6000.,'m'),
        ('known_age',d['history_final_known_age_myr'], -1.,20.,'calibration Myr; -1 unknown'),
        ('created_fraction',d['history_final_created_fraction'],0.,1.,'footprint fraction'),
        ('removed_inventory',d['history_removed_km2'].sum(axis=0)/area,0.,1.,'sample-area equivalent'),
        ('phase_elevation',d['history_elevation_m'],-9000.,9000.,'m'),
        ('phase_memory',d['history_memory_m'],0.,6000.,'m'),
        ('phase_current_collision',d['history_current_collision_m'],0.,6000.,'m')):
        mask=np.atleast_2d((values<low)|(values>high))
        clipping[name]={'range':[low,high],'units':units,
            'maximum_samples_in_one_snapshot':int(mask.sum(axis=1).max()),
            'maximum_area_km2_in_one_snapshot':float((mask*area).sum(axis=1).max())}
    inventory=d['history_inventory_km2'].sum(axis=1)
    expected=area.sum()+np.cumsum(d['history_created_km2'].sum(axis=1)-d['history_removed_km2'].sum(axis=1))
    return {'history_steps':len(d['history_times_myr'])-1,
        'history_events':len(d['history_event_step_ids']),
        'history_array_bytes':sum(v.nbytes for v in d.values()),
        'history_final_retained_inventory_km2':float(inventory[-1]),
        'history_max_inventory_relative_error':float(np.max(abs(inventory-expected))/area.sum()),
        'history_max_roundoff_correction_relative':float(np.max(abs(d['history_correction_km2']/area))),
        'history_max_outflow_fraction':float(d['history_step_outflow_fraction'].max()),
        'history_diagnostic_clipping':clipping,
        'history_duration_myr':float(d['history_times_myr'][-1]),
        'history_material_entries':len(d['history_cell_ids']),
        'history_cohorts':len(d['history_cohort_birth_myr']),
        'history_created_km2':float(d['history_created_km2'].sum()),
        'history_removed_km2':float(d['history_removed_km2'].sum()),
        'history_compressed_km2':float(d['history_compressed_km2'].sum()),
        'history_max_coverage_relative_error':float(np.max(abs(d['history_coverage_km2']/world.mesh.sample_areas_km2-1))),
        'history_max_displacement_fraction':float(d['history_step_displacement_fraction'].max()),
        'history_max_memory_m':float(d['history_memory_m'][-1].max()),
        'history_final_sea_level_m':float(d['history_final_sea_level_m'][0]),
        'history_experimental':True}
