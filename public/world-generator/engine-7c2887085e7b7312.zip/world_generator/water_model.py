"""Immutable water-state record and its per-sample serialization contract."""

from dataclasses import dataclass, fields

import numpy as np


# name: association, trailing shape, dtype, units.  Sea level is scalar metadata.
SPECS = {
    'height_above_sea_m': ('sample', (), '<f8', 'm; elevation minus sea level'),
    'submerged_mask': ('sample', (), '|u1', '1 elevation below sea level; 0 otherwise'),
    'land_mask': ('sample', (), '|u1', '1 elevation at or above sea level; 0 otherwise'),
    'ocean_mask': ('sample', (), '|u1', '1 largest-area submerged component; 0 otherwise'),
    'basin_candidate_mask': ('sample', (), '|u1', '1 non-ocean submerged component; 0 otherwise'),
    'water_component_ids': ('sample', (), '<i4', 'minimum sample ID in submerged component; -1 dry'),
}

# Kept as a descriptive alias for consumers that namespace all water metadata.
WATER_SPECS = SPECS


@dataclass(frozen=True)
class Water:
    """Sea-relative per-sample classifications for one immutable mesh."""

    sea_level_m: float
    height_above_sea_m: np.ndarray
    submerged_mask: np.ndarray
    land_mask: np.ndarray
    ocean_mask: np.ndarray
    basin_candidate_mask: np.ndarray
    water_component_ids: np.ndarray

    def __post_init__(self):
        for array in self.arrays().values():
            array.setflags(write=False)

    def arrays(self) -> dict[str, np.ndarray]:
        return {field.name: getattr(self, field.name) for field in fields(self) if field.name != 'sea_level_m'}
