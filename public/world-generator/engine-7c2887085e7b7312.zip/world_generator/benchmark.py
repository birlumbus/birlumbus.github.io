"""Measured full exports, with cold subprocess and warm in-process observations."""

from dataclasses import asdict
import json
from pathlib import Path
import platform
import statistics
import subprocess
import sys
from time import perf_counter

import numpy as np
import PIL

from .export import export_diagnostics
from .generate import generate_world
from .model import GENERATOR_VERSION, WorldConfig
from .storage import canonical_hash, save_world
from .validation import tectonic_statistics
from .terrain_validation import terrain_statistics
from .history_model import history_statistics


def environment() -> dict:
    return {
        'python': platform.python_version(), 'numpy': np.__version__, 'pillow': PIL.__version__,
        'generator': GENERATOR_VERSION, 'platform': platform.platform(), 'machine': platform.machine(),
    }


def peak_rss_mib() -> float | None:
    try:
        import resource
    except ImportError:
        return None
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return peak / (1024 * 1024 if sys.platform == 'darwin' else 1024)


def generate_and_export(seed: int, config: WorldConfig, directory: str | Path) -> dict:
    path = Path(directory)
    if path.exists():
        raise FileExistsError(f'output already exists: {path}; choose a new directory')
    started = perf_counter()
    stages = {}
    world = generate_world(seed, config, timings=stages)
    generated = perf_counter()
    save_world(world, path)
    saved = perf_counter()
    export_diagnostics(world, path)
    exported = perf_counter()
    report = {
        'seed': seed, 'config': config.resolved(), 'stage': config.stage, 'output': str(path.resolve()),
        'canonical_sha256': canonical_hash(world),
        'sample_count': len(world.mesh.positions), 'edge_count': len(world.mesh.edges), 'face_count': len(world.mesh.faces),
        'timings': {
            **stages,
            'total_generation_seconds': generated - started,
            'data_export_seconds': saved - generated,
            'diagnostic_export_seconds': exported - saved,
            'full_export_seconds': exported - started,
        },
        'peak_rss_mib': peak_rss_mib(), 'environment': environment(),
        'measurement_notes': 'full_export includes generation, validation, NPZ/manifest and all PNGs; excludes imports and writing this report. RSS is process lifetime high-water mark.',
    }
    report.update(tectonic_statistics(world))
    report.update(terrain_statistics(world))
    report.update(history_statistics(world))
    (path / 'run.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    return report


def benchmark(seed: int, config: WorldConfig, directory: str | Path, runs: int = 3) -> dict:
    if type(runs) is not int or not 1 <= runs <= 20:
        raise ValueError('runs must be an integer from 1 to 20')
    path = Path(directory)
    if path.exists():
        raise FileExistsError(f'output already exists: {path}; choose a new directory')
    path.mkdir(parents=True, exist_ok=False)
    config_path = path / 'config.json'
    config_path.write_text(json.dumps(asdict(config), sort_keys=True) + '\n')
    started = perf_counter()
    cold = subprocess.run([
        sys.executable, '-m', 'world_generator', 'generate', '--seed', str(seed),
        '--config', str(config_path), '--out', str(path / 'cold'),
    ], check=True, capture_output=True, text=True)
    cold_wall = perf_counter() - started
    cold_run = json.loads(cold.stdout)
    warm_runs = [generate_and_export(seed, config, path / f'warm-{i + 1}') for i in range(runs)]
    hashes = {run['canonical_sha256'] for run in [cold_run, *warm_runs]}
    if len(hashes) != 1:
        raise ValueError('benchmark runs produced different canonical hashes')
    report = {
        'seed': seed, 'config': asdict(config), 'environment': environment(),
        'cold_wall_seconds': cold_wall, 'cold_run': cold_run, 'warm_runs': warm_runs,
        'warm_median_mesh_generation_seconds': statistics.median(run['timings']['mesh_generation_seconds'] for run in warm_runs),
        'warm_median_full_export_seconds': statistics.median(run['timings']['full_export_seconds'] for run in warm_runs),
        'warm_median_stage_seconds': {key: statistics.median(run['timings'][key] for run in warm_runs)
                                      for key in warm_runs[0]['timings']},
        'measurement_notes': 'Cold means a fresh interpreter (includes imports and report writing), not a flushed OS disk cache. Warm runs regenerate and export all data without a mesh/projection cache. RSS includes earlier work in that process.',
    }
    (path / 'benchmark.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    return report
