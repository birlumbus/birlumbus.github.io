"""Connected spherical plate regions and their instantaneous motions."""

import heapq

import numpy as np

from .noise import spherical_noise
from .randomness import stage_rng


def _smooth_positive_costs(mesh, rng: np.random.Generator) -> np.ndarray:
    field = spherical_noise(mesh.positions, rng)
    return np.ascontiguousarray(np.exp(0.6 * np.clip(field, -2.0, 2.0)), dtype="<f8")


def _adjacency_angular_weights(mesh, radius_km: float) -> np.ndarray:
    """Align each stored CSR neighbour with its edge's angular length."""
    if not np.isfinite(radius_km) or radius_km <= 0.0:
        raise ValueError("radius_km must be positive and finite")
    a, b = np.moveaxis(mesh.positions[mesh.edges], 1, 0)
    edge_angles = np.arctan2(np.linalg.norm(np.cross(a, b), axis=1), np.sum(a * b, axis=1))
    directed = np.concatenate((mesh.edges, mesh.edges[:, ::-1]))
    order = np.lexsort((directed[:, 1], directed[:, 0]))
    return np.ascontiguousarray(np.tile(edge_angles, 2)[order], dtype="<f8")


def generate_plates(seed: int, mesh, config) -> dict[str, np.ndarray]:
    """Partition mesh samples by deterministic competitive graph growth.

    Every seed is claimed before growth starts. Later claims are first-claim
    wins, so a plate cannot be disconnected by reassignment.
    """
    sample_count = len(mesh.positions)
    plate_count = int(config.plate_count)
    if not 1 <= plate_count <= sample_count:
        raise ValueError("plate_count must be between 1 and the sample count")

    seed_rng = stage_rng(seed, "plates.seeds")
    probabilities = np.asarray(mesh.sample_areas_km2, dtype="<f8")
    probabilities = probabilities / probabilities.sum()
    seed_samples = seed_rng.choice(sample_count, size=plate_count, replace=False, p=probabilities)
    seed_samples = np.ascontiguousarray(seed_samples, dtype="<i4")
    growth_rng = stage_rng(seed, "plates.growth")
    growth_rates = np.exp(growth_rng.uniform(-0.7, 0.7, size=plate_count)).astype("<f8")
    costs = _smooth_positive_costs(mesh, stage_rng(seed, "plates.cost"))
    adjacency_weights = _adjacency_angular_weights(mesh, float(config.radius_km))

    plate_ids = np.full(sample_count, -1, dtype="<i4")
    heap: list[tuple[float, int, int]] = []
    for plate_id, sample_id in enumerate(seed_samples):
        sample_id = int(sample_id)
        plate_ids[sample_id] = plate_id
    for plate_id, sample_id in enumerate(seed_samples):
        sample_id = int(sample_id)
        start, end = int(mesh.neighbor_offsets[sample_id]), int(mesh.neighbor_offsets[sample_id + 1])
        for offset in range(start, end):
            neighbor = int(mesh.neighbors[offset])
            if plate_ids[neighbor] < 0:
                step = adjacency_weights[offset] * 0.5 * (costs[sample_id] + costs[neighbor])
                heapq.heappush(heap, (float(step / growth_rates[plate_id]), neighbor, plate_id))

    while heap:
        distance, sample_id, plate_id = heapq.heappop(heap)
        if plate_ids[sample_id] >= 0:
            continue
        plate_ids[sample_id] = plate_id
        start, end = int(mesh.neighbor_offsets[sample_id]), int(mesh.neighbor_offsets[sample_id + 1])
        for offset in range(start, end):
            neighbor = int(mesh.neighbors[offset])
            if plate_ids[neighbor] < 0:
                step = adjacency_weights[offset] * 0.5 * (costs[sample_id] + costs[neighbor])
                priority = distance + float(step / growth_rates[plate_id])
                heapq.heappush(heap, (priority, neighbor, plate_id))

    if np.any(plate_ids < 0):
        raise RuntimeError("plate growth did not cover the mesh")
    plate_areas = np.bincount(
        plate_ids,
        weights=np.asarray(mesh.sample_areas_km2, dtype="<f8"),
        minlength=plate_count,
    ).astype("<f8")
    return {
        "plate_ids": np.ascontiguousarray(plate_ids, dtype="<i4"),
        "plate_seed_samples": seed_samples,
        "plate_growth_rates": np.ascontiguousarray(growth_rates, dtype="<f8"),
        "plate_areas_km2": np.ascontiguousarray(plate_areas, dtype="<f8"),
    }


def velocities(omega: np.ndarray, positions: np.ndarray, radius_km: float) -> np.ndarray:
    """Evaluate ``R * (omega cross position)`` for one or many positions."""
    angular_velocity = np.asarray(omega, dtype="<f8")
    points = np.asarray(positions, dtype="<f8")
    return np.ascontiguousarray(float(radius_km) * np.cross(angular_velocity, points), dtype="<f8")


def generate_motions(seed: int, mesh, config, plate_ids: np.ndarray, plate_seed_samples: np.ndarray) -> dict[str, np.ndarray]:
    """Generate one isotropic Euler rotation for each seeded plate."""
    plate_ids = np.asarray(plate_ids, dtype="<i4")
    plate_seed_samples = np.asarray(plate_seed_samples, dtype="<i4")
    plate_count = len(plate_seed_samples)
    axes = np.empty((plate_count, 3), dtype="<f8")
    speeds = np.empty(plate_count, dtype="<f8")
    scale = float(config.angular_speed_scale_rad_per_myr)
    for plate_id, sample_id in enumerate(plate_seed_samples):
        rng = stage_rng(seed, f"motion.{int(sample_id)}")
        axis = np.asarray(rng.normal(size=3), dtype="<f8")
        axis /= np.linalg.norm(axis)
        axes[plate_id] = axis
        speeds[plate_id] = rng.uniform(0.25, 1.0) * scale
    omega = axes * speeds[:, None]
    sample_velocity = velocities(omega[plate_ids], mesh.positions, config.radius_km)
    return {
        "plate_axes": np.ascontiguousarray(axes, dtype="<f8"),
        "plate_angular_speeds_rad_per_myr": np.ascontiguousarray(speeds, dtype="<f8"),
        "plate_omega_rad_per_myr": np.ascontiguousarray(omega, dtype="<f8"),
        "sample_velocity_km_per_myr": sample_velocity,
    }
