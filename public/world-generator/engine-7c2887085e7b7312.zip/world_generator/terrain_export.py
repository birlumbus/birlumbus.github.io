"""Deterministic M2 terrain and water diagnostic views.

The exporter is deliberately observational: every map is made from the persisted
terrain and water arrays, and the caller supplies the already computed equirectangular
sample-ID map.  Display colours are fixed and carry their units and clipping ranges in
the captions so that images remain useful after a world is reloaded.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from .tectonic_export import (
    _CLASS_COLOURS,
    _CLASS_NAMES,
    _boundary_path,
    _draw_spherical_line,
    _map_canvas,
)


DIAGNOSTICS = (
    "elevation.png",
    "water.png",
    "baseline.png",
    "uplift.png",
    "subsidence.png",
    "detail.png",
    "terrain_context.png",
    "terrain_poles.png",
)

_BG = (17, 27, 43)
_OCEAN = (28, 105, 190)
_LAND = (53, 147, 74)
_BASIN = (144, 65, 177)


def _font(size: int):
    from PIL import ImageFont

    return ImageFont.load_default(size=max(9, int(size)))


def _stops_colour(values: np.ndarray, stops: tuple[tuple[float, tuple[int, int, int]], ...]) -> np.ndarray:
    values = np.asarray(values, dtype="<f8")
    clipped = np.clip(values, stops[0][0], stops[-1][0])
    output = np.empty(values.shape + (3,), dtype="<f8")
    for index in range(len(stops) - 1):
        left, right = stops[index], stops[index + 1]
        mask = clipped <= right[0]
        if index:
            mask &= clipped > left[0]
        fraction = (clipped - left[0]) / max(1e-15, right[0] - left[0])
        output[mask] = (1.0 - fraction[mask, None]) * np.asarray(left[1]) + fraction[mask, None] * np.asarray(right[1])
    output[clipped <= stops[0][0]] = stops[0][1]
    output[clipped >= stops[-1][0]] = stops[-1][1]
    return np.rint(output).clip(0, 255).astype(np.uint8)


def _field(world, name: str) -> np.ndarray:
    value = np.asarray(getattr(world.terrain, name), dtype="<f8")
    if value.ndim != 1 or len(value) != len(world.mesh.positions) or not np.all(np.isfinite(value)):
        raise ValueError(f"terrain.{name} must be a finite one-dimensional sample array")
    return value


def _water_field(world, name: str, dtype=None) -> np.ndarray:
    value = np.asarray(getattr(world.water, name), dtype=dtype)
    if value.ndim != 1 or len(value) != len(world.mesh.positions):
        raise ValueError(f"water.{name} must be a one-dimensional sample array")
    return value


def _validate_inputs(world, ids: np.ndarray) -> np.ndarray:
    ids = np.asarray(ids)
    if ids.ndim != 2 or ids.shape[0] < 1 or ids.shape[1] < 1:
        raise ValueError("ids must be a non-empty HxW sample-ID map")
    if not np.issubdtype(ids.dtype, np.integer):
        raise ValueError("ids must contain integer sample IDs")
    ids = ids.astype(np.int64, copy=False)
    if np.any(ids < 0) or np.any(ids >= len(world.mesh.positions)):
        raise ValueError("ids contain an out-of-range sample ID")
    for name in ("margin_distance_km", "baseline_m", "raw_uplift_m", "raw_subsidence_m", "uplift_m", "subsidence_m", "detail_m", "elevation_m"):
        _field(world, name)
    for name in ("height_above_sea_m", "submerged_mask", "land_mask", "ocean_mask", "basin_candidate_mask", "water_component_ids"):
        _water_field(world, name)
    sea = float(world.water.sea_level_m)
    if not math.isfinite(sea):
        raise ValueError("water.sea_level_m must be finite")
    return ids


def _terrain_rgb(world, ids: np.ndarray) -> np.ndarray:
    """Colour terrain relative to sea level, with unresolved basins in purple."""
    return _terrain_sample_colours(world)[np.asarray(ids, dtype=np.int64)]


def _terrain_sample_colours(world) -> np.ndarray:
    """Build one RGB triplet per sample before expanding it to a map."""
    height = _water_field(world, "height_above_sea_m", "<f8")
    submerged = _water_field(world, "submerged_mask", bool)
    basin = _water_field(world, "basin_candidate_mask", bool)
    output = np.empty((len(height), 3), dtype=np.uint8)
    ocean = _stops_colour(
        np.clip(-height, 0.0, 9000.0),
        ((0.0, (124, 202, 236)), (1500.0, (35, 130, 211)), (9000.0, (7, 26, 100))),
    )
    land = _stops_colour(
        np.clip(height, 0.0, 9000.0),
        ((0.0, (55, 151, 77)), (1000.0, (153, 183, 65)), (3500.0, (177, 126, 64)), (9000.0, (104, 55, 36))),
    )
    output[...] = land
    output[submerged] = ocean[submerged]
    output[basin] = _BASIN
    return output


def _reference_rgb(world, ids: np.ndarray) -> np.ndarray:
    """Colour the persisted radial elevation against the fixed sphere datum."""
    elevation = _field(world, "elevation_m")
    colours = _stops_colour(
        np.clip(elevation, -9000.0, 9000.0),
        ((-9000.0, (8, 29, 105)), (-4500.0, (29, 111, 195)), (0.0, (52, 147, 74)), (1800.0, (177, 126, 64)), (9000.0, (104, 55, 36))),
    )
    return colours[np.asarray(ids, dtype=np.int64)]


def _hatch_basins(rgb: np.ndarray, basin: np.ndarray) -> np.ndarray:
    """Add a deterministic diagonal hatch to basin-candidate pixels."""
    rows = np.arange(basin.shape[0], dtype=np.uint32)[:, None]
    columns = np.arange(basin.shape[1], dtype=np.uint32)[None, :]
    hatch = basin & (((rows + columns) % np.uint32(9)) < np.uint32(2))
    rgb = np.asarray(rgb).copy()
    rgb[hatch] = (77, 31, 105)
    return rgb


def _scalar_map(values: np.ndarray, scale: tuple[float, float], colours, ids: np.ndarray) -> np.ndarray:
    # Colour the authoritative sample stream once; map expansion is integer RGB only.
    return _stops_colour(values, colours)[np.asarray(ids, dtype=np.int64)]


def _numeric_legend(stops, prefix: str) -> list:
    return [(tuple(int(channel) for channel in colour), f"{prefix}: {value:g} m") for value, colour in stops]


def _compact_title(title: str, width: int) -> str:
    """Wrap long titles at word boundaries so compact maps keep the legend clear."""
    limit = max(32, int((width + 380) / 8))
    words, lines, current = title.split(), [], ""
    for word in words:
        trial = f"{current} {word}".strip()
        if len(trial) > limit and current:
            lines.append(current)
            current = word
        else:
            current = trial
    if current:
        lines.append(current)
    return "\n".join(lines)


def _save_map(base: np.ndarray, title: str, legend: list, path: Path, draw_fn=None) -> None:
    canvas, draw, origin = _map_canvas(base, _compact_title(title, base.shape[1]), legend)
    if draw_fn is not None:
        draw_fn(canvas, draw, origin)
    canvas.save(path)


def _project_pole(point: np.ndarray, pole_sign: int, center: tuple[float, float], radius: float) -> tuple[float, float] | None:
    point = np.asarray(point, dtype="<f8")
    norm = float(np.linalg.norm(point))
    if norm <= 0.0:
        return None
    point = point / norm
    if float(point[2] * pole_sign) < 0.0:
        return None
    # M1 camera convention: +y is screen-right; north uses -x up and south +x up.
    up = -1.0 if pole_sign > 0 else 1.0
    return (center[0] + radius * float(point[1]), center[1] - radius * up * float(point[0]))


def _pole_directions(size: int, pole_sign: int) -> tuple[np.ndarray, np.ndarray]:
    """Return finite orthographic pixel directions and a visible-pixel mask."""
    if size < 3 or pole_sign not in (-1, 1):
        raise ValueError("size must be at least 3 and pole_sign must be ±1")
    axis = (size - 1) / 2.0
    yy, xx = np.indices((size, size), dtype="<f8")
    screen_x = (xx - axis) / axis
    screen_y = (yy - axis) / axis
    visible = screen_x * screen_x + screen_y * screen_y <= 1.0
    directions = np.zeros((size, size, 3), dtype="<f8")
    directions[..., 1] = screen_x
    # Inverse of _project_pole: north screen-up is -x, south screen-up is +x.
    directions[..., 0] = (screen_y if pole_sign > 0 else -screen_y)
    directions[..., 2] = pole_sign * np.sqrt(np.maximum(0.0, 1.0 - screen_x * screen_x - screen_y * screen_y))
    directions = directions.reshape(-1, 3)
    visible = visible.reshape(-1)
    return directions, visible


def _pole_map(world) -> Image.Image:
    # Keep the two hemispheres close to 512px at all configured map sizes.
    size = max(512, min(560, int(getattr(world.config, "image_width", 1024) // 2)))
    radius = (size - 1) / 2.0
    canvas = Image.new("RGB", (size * 2 + 40, size + 112), _BG)
    draw = ImageDraw.Draw(canvas)
    draw.text((18, 14), "M2 / TERRAIN POLES", fill=(241, 245, 249), font=_font(15))
    for pole_sign, left, label in ((1, 20, "NORTH (+z)"), (-1, size + 20, "SOUTH (-z)")):
        directions, visible = _pole_directions(size, pole_sign)
        # Import locally to avoid export.py importing this module during startup.
        from .export import locate_samples

        sampled = locate_samples(world.mesh, directions[visible])
        rgb = np.zeros((size * size, 3), dtype=np.uint8)
        rgb[visible] = _terrain_rgb(world, sampled)
        image = Image.fromarray(rgb.reshape(size, size, 3))
        canvas.paste(image, (left, 52))
        centre = (left + radius, 52 + radius)
        draw.ellipse((centre[0] - radius, centre[1] - radius, centre[0] + radius, centre[1] + radius), outline=(220, 230, 235), width=2)
        draw.text((centre[0], centre[1] - radius - 16), label, fill=(238, 245, 250), font=_font(12), anchor="mb")
        draw.text((centre[0] + radius + 5, centre[1]), "E", fill=(240, 240, 240), font=_font(10), anchor="lm")
        draw.text((centre[0], centre[1] + radius - 3), "0° lon" if pole_sign > 0 else "180° lon", fill=(200, 215, 227), font=_font(9), anchor="mb")
    draw.text((18, size + 70), "Orthographic terrain/water colours are sampled with the spherical triangle lookup; no face-majority ownership is used.", fill=(200, 215, 227), font=_font(10))
    draw.text((18, size + 87), "Screen axes: +y is right; NORTH screen-up is -x; SOUTH screen-up is +x. Elevation datum is the reference sphere.", fill=(200, 215, 227), font=_font(9))
    x = size + 45
    for colour, label in ((_OCEAN, "ocean depth"), (_LAND, "land relief"), (_BASIN, "basin candidate")):
        draw.rectangle((x, size + 98, x + 10, size + 108), fill=colour)
        draw.text((x + 14, size + 97), label, fill=(200, 215, 227), font=_font(9))
        x += 105
    return canvas


def _context_draw(world, draw, origin, width: int, height: int) -> None:
    tectonics = getattr(world, "tectonics", None)
    if tectonics is None or not hasattr(tectonics, "boundary_mask"):
        return
    from .tectonic_export import _draw_spherical_line

    for edge_id in np.flatnonzero(np.asarray(tectonics.boundary_mask, dtype=bool)):
        endpoints = np.asarray(tectonics.boundary_endpoints[int(edge_id)], dtype="<f8")
        if endpoints.shape != (2, 3) or not np.all(np.isfinite(endpoints)):
            continue
        cls = int(tectonics.boundary_class[int(edge_id)])
        colour = _CLASS_COLOURS.get(cls, (110, 125, 140))
        _draw_spherical_line(draw, _boundary_path(*endpoints, count=12), origin, width, height, colour, 2)


def export_terrain_diagnostics(world, directory: str | Path, ids: np.ndarray) -> Path:
    """Write the complete deterministic M2 diagnostic package.

    ``ids`` is the shared equirectangular lookup generated by the caller.  This keeps
    M0/M1 projection identities and M2 maps exactly aligned at every resolution.
    """
    ids = _validate_inputs(world, ids)
    path = Path(directory)
    collisions = [path / name for name in DIAGNOSTICS if (path / name).exists()]
    if collisions:
        raise FileExistsError(f"diagnostic already exists: {collisions[0]}; choose a new directory")
    path.mkdir(parents=True, exist_ok=True)
    height, width = ids.shape
    terrain = world.terrain
    sea = float(world.water.sea_level_m)

    elevation = _hatch_basins(_terrain_rgb(world, ids), _water_field(world, "basin_candidate_mask", bool)[ids])
    _save_map(
        elevation,
        f"M2 / ELEVATION RELATIVE TO SEA / seed {getattr(world, 'seed', '?')}",
        ["Colours show height relative to sea level; ocean depth and land relief use fixed 0…9000 m clipped scales."] + _numeric_legend(((0.0, (124, 202, 236)), (1500.0, (35, 130, 211)), (9000.0, (7, 26, 100))), "Ocean depth") + _numeric_legend(((0.0, (55, 151, 77)), (1000.0, (153, 183, 65)), (3500.0, (177, 126, 64)), (9000.0, (104, 55, 36))), "Land relief") + [f"Fixed reference datum: radial offset from the reference sphere; sea level = {sea:g} m.", "Purple with diagonal hatch = submerged basin candidate; it is not labelled as a lake."],
        path / "elevation.png",
    )

    water_mask = _water_field(world, "submerged_mask", bool)[ids]
    land_mask = _water_field(world, "land_mask", bool)[ids]
    basin_mask = _water_field(world, "basin_candidate_mask", bool)[ids]
    water_rgb = np.empty(elevation.shape, dtype=np.uint8)
    water_rgb[...] = (105, 105, 112)
    water_rgb[land_mask] = _LAND
    water_rgb[water_mask] = _OCEAN
    water_rgb[basin_mask] = _BASIN
    water_rgb = _hatch_basins(water_rgb, basin_mask)
    _save_map(water_rgb, f"M2 / WATER CATEGORIES / sea level {sea:g} m", [((_OCEAN), "Ocean: connected component selected as numerical ocean"), ((_LAND), "Land: elevation at or above sea level (equality remains land)"), ((_BASIN), "Basin candidate: submerged component other than ocean; unresolved lake interpretation"), "Masks and component IDs are sampled from persisted water arrays; colours are categorical."], path / "water.png")

    maps = (
        ("baseline_m", "baseline.png", "BASELINE (m)", (-6000.0, 2000.0), ((-6000.0, (25, 63, 133)), (-200.0, (52, 145, 195)), (0.0, (186, 192, 180)), (700.0, (197, 153, 86)), (2000.0, (107, 54, 39))), "Crust-dependent reference baseline; fixed display scale -6000…+2000 m; values clip at the endpoints."),
        ("uplift_m", "uplift.png", "UPLIFT (m)", (0.0, 9000.0), ((0.0, (42, 46, 63)), (2200.0, (216, 168, 61)), (9000.0, (191, 44, 27))), "Final nonnegative uplift after smooth saturation; fixed display scale 0…9000 m."),
        ("subsidence_m", "subsidence.png", "SUBSIDENCE (m)", (0.0, 6000.0), ((0.0, (222, 224, 211)), (1800.0, (115, 133, 202)), (6000.0, (47, 26, 105))), "Final nonnegative subsidence after smooth saturation; fixed display scale 0…6000 m."),
        ("detail_m", "detail.png", "DETAIL (m)", (-300.0, 300.0), ((-300.0, (45, 93, 183)), (0.0, (218, 218, 207)), (300.0, (184, 52, 49))), "Bounded detail contribution; fixed signed display scale -300…+300 m; values clip at the endpoints."),
    )
    for field, filename, title, scale, stops, caption in maps:
        values = _field(world, field)
        _save_map(_scalar_map(values, scale, stops, ids), f"M2 / {title} / seed {getattr(world, 'seed', '?')}", [caption] + _numeric_legend(stops, title.title()) + ["Units are metres of radial elevation from the fixed reference sphere; colour scales are comparable across worlds."], path / filename)

    context = _reference_rgb(world, ids)
    _save_map(context, f"M2 / TERRAIN CONTEXT / fixed-reference elevation (m) / seed {getattr(world, 'seed', '?')}", ["Base colours show persisted radial elevation from the reference sphere (fixed scale -9000…+9000 m); boundary arcs are classified by saved M1 contact class."] + [(_CLASS_COLOURS.get(code, (110, 125, 140)), f"{code}: {_CLASS_NAMES.get(code, 'unknown')}") for code in (0, 1, 2, 3, 4)] + ["Arc overlays share the spherical reference frame; all terrain values and scale labels are metres."], path / "terrain_context.png", lambda _canvas, draw, origin: _context_draw(world, draw, origin, width, height))

    _pole_map(world).save(path / "terrain_poles.png")
    return path
