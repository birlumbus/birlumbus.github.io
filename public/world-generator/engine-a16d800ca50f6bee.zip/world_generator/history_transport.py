"""Positive, conservative material transport on the unchanged lumped-area graph.

The integrated Euler flux on an oriented dual arc is R^2 omega dot (end1-end0).
Dual arcs form closed cell boundaries, so a common Euler field has zero discrete
flux divergence even though the saved lumped capacities differ from dual areas.
"""
from dataclasses import dataclass
import numpy as np
from .boundaries import boundary_geometry
from .history_model import PROFILE

@dataclass
class Material:
    cell: np.ndarray
    cohort: np.ndarray
    host: np.ndarray
    values: np.ndarray  # footprint, inventory, inventory*baseline/detail/memory

    def sum(self,n,column=0):
        return np.bincount(self.cell,weights=self.values[:,column],minlength=n)


def geometry(mesh,omega,radius):
    n=len(mesh.positions)
    g=boundary_geometry(mesh,np.ones(len(mesh.edges),dtype=bool),radius)
    delta=g['boundary_endpoints'][:,1]-g['boundary_endpoints'][:,0]
    q=radius**2*np.einsum('pj,ej->pe',omega,delta,optimize=False)
    degree=np.diff(mesh.neighbor_offsets)
    neighbor=np.broadcast_to(np.arange(n,dtype='<i4')[:,None],(n,6)).copy()
    edge_ids=np.zeros((n,6),dtype='<i4')
    sign=np.zeros((n,6))
    slot=np.zeros(n,dtype=int)
    for e,(a,b) in enumerate(mesh.edges):
        ia,ib=slot[a],slot[b]
        neighbor[a,ia]=b;neighbor[b,ib]=a
        edge_ids[a,ia]=e;edge_ids[b,ib]=e
        sign[a,ia]=1;sign[b,ib]=-1
        slot[a]+=1;slot[b]+=1
    coeff=np.maximum(q[:,edge_ids]*sign,0)/mesh.sample_areas_km2[None,:,None]
    spacing=np.sqrt(mesh.sample_areas_km2).copy()
    np.minimum.at(spacing,mesh.edges[:,0],mesh.edge_lengths_km)
    np.minimum.at(spacing,mesh.edges[:,1],mesh.edge_lengths_km)
    # Sum-of-norms is a conservative relative-speed bound for any future pair,
    # including pairs that first meet during this step.
    speed_bound=2*radius*float(np.linalg.norm(omega,axis=1).max())
    rate=float(coeff.sum(axis=2).max())
    bound=min(.25*float(spacing.min())/speed_bound if speed_bound else np.inf,
              .5/rate if rate else np.inf)
    return g,neighbor,coeff,spacing,speed_bound,rate,bound


def check_resource(count,n):
    limit=min(PROFILE['max_entries'],PROFILE['max_entries_per_sample']*n)
    if count>limit:
        raise ValueError(f'M3 material resource budget exceeded: {count} entries > {limit}; reduce history duration or plate count')


def coalesce(material,plate_count):
    """Merge only identical cell/cohort/host tuples; retain all provenance cohorts."""
    if not len(material.cell): return material
    order=np.lexsort((material.cell,material.host,material.cohort))
    cell,cohort,host=(a[order] for a in (material.cell,material.cohort,material.host))
    values=material.values[order]
    first=np.r_[True,(cell[1:]!=cell[:-1])|(cohort[1:]!=cohort[:-1])|(host[1:]!=host[:-1])]
    starts=np.flatnonzero(first)
    summed=np.add.reduceat(values,starts,axis=0)
    keep=summed[:,0]>0
    return Material(cell[starts][keep],cohort[starts][keep],host[starts][keep],summed[keep])


def advect(material,neighbor,coeff,dt,n,plate_count):
    if dt==0 or not coeff.any():
        return Material(material.cell.copy(),material.cohort.copy(),material.host.copy(),material.values.copy())
    order=np.lexsort((material.cell,material.host,material.cohort))
    groups=material.cohort[order].astype(np.int64)*plate_count+material.host[order]
    starts=np.r_[0,np.flatnonzero(groups[1:]!=groups[:-1])+1,len(groups)]
    cells=[];cohorts=[];hosts=[];payload=[];count=0
    for start,end in zip(starts[:-1],starts[1:]):
        idx=order[start:end]; c=material.cell[idx];host=int(material.host[idx[0]])
        weights=dt*coeff[host,c]
        stay=1-weights.sum(axis=1)
        if (stay<0).any(): raise ValueError('M3 outflow bound violated')
        target=np.concatenate((c,neighbor[c].ravel()))
        factors=np.concatenate((stay,weights.ravel()))
        source=np.concatenate((np.arange(len(c)),np.repeat(np.arange(len(c)),6)))
        positive=factors>0
        target,factors,source=target[positive],factors[positive],source[positive]
        out=np.column_stack([np.bincount(target,weights=material.values[idx[source],j]*factors,minlength=n)
                             for j in range(5)])
        present=np.flatnonzero(out[:,0]>0)
        count+=len(present);check_resource(count,n)
        cells.append(present.astype('<i4'));cohorts.append(np.full(len(present),material.cohort[idx[0]],dtype='<i4'))
        hosts.append(np.full(len(present),host,dtype='<i4'));payload.append(out[present])
    return Material(np.concatenate(cells),np.concatenate(cohorts),np.concatenate(hosts),np.concatenate(payload))


def initial_material(world):
    t=world.tectonics;a=world.mesh.sample_areas_km2;n=len(a)
    cohort=2*t.plate_ids+t.crust_type
    return Material(np.arange(n,dtype='<i4'),cohort.astype('<i4'),t.plate_ids.copy(),
                    np.column_stack((a,a,a*world.terrain.baseline_m,a*world.terrain.detail_m,np.zeros(n))))


def summarize(material,n,plate_count,crust,birth,time,seeds):
    area=material.sum(n);inventory=material.sum(n,1)
    values=np.column_stack([material.sum(n,j) for j in range(2,5)])/inventory[:,None]
    continental=np.bincount(material.cell,weights=material.values[:,0]*crust[material.cohort],minlength=n)/area
    known=birth[material.cohort]>=0
    created=np.bincount(material.cell[known],weights=material.values[known,0],minlength=n)
    age_total=np.bincount(material.cell[known],weights=material.values[known,0]*(time-birth[material.cohort[known]]),minlength=n)
    age=np.full(n,-1.);np.divide(age_total,created,out=age,where=created>0)
    host_area=np.zeros((plate_count,n))
    np.add.at(host_area,(material.host,material.cell),material.values[:,0])
    # Sorting physical seed IDs makes ties invariant to plate relabeling.
    order=np.argsort(seeds,kind='stable')
    host=order[host_area[order].argmax(axis=0)].astype('<i4')
    return area,inventory,values,continental,created/area,age,host,host_area
