"""Compact final-M3 display data for the globe and map; no synthetic detail."""
from dataclasses import replace
import re
from time import perf_counter

import numpy as np

from .generate import generate_world
from .model import WorldConfig
from .randomness import validate_seed
from .storage import canonical_hash
from .viewer_export import _encoded, _viewer_arrays
from .water_model import Water, SPECS as WATER_SPECS


def terrain_gradients(positions, faces, elevation):
    """Area-weighted tangent gradients, in metres per radian on a unit sphere."""
    p = np.asarray(positions, dtype=np.float64)
    triangles = p[faces]
    e1 = triangles[:, 1] - triangles[:, 0]
    e2 = triangles[:, 2] - triangles[:, 0]
    normal = np.cross(e1, e2)
    area2 = np.linalg.norm(normal, axis=1)
    dh1 = elevation[faces[:, 1]] - elevation[faces[:, 0]]
    dh2 = elevation[faces[:, 2]] - elevation[faces[:, 0]]
    # Multiplying the face gradient by its area avoids giving tiny faces more weight.
    weighted = (dh1[:, None] * np.cross(e2, normal)
                + dh2[:, None] * np.cross(normal, e1)) / area2[:, None]
    gradient = np.zeros_like(p)
    weights = np.zeros(len(p))
    for corner in range(3):
        np.add.at(gradient, faces[:, corner], weighted)
        np.add.at(weights, faces[:, corner], area2)
    gradient /= weights[:, None]
    gradient -= np.sum(gradient * p, axis=1)[:, None] * p
    return gradient


def scene_payload(world):
    if world.config.stage != 'm3' or world.history is None:
        raise ValueError('the visual demo requires regional M3 terrain')
    d = world.history.data
    elevation = d['history_elevation_m'][-1]
    display = replace(
        world,
        terrain=replace(world.terrain, elevation_m=elevation),
        water=Water(sea_level_m=float(d['history_final_sea_level_m'][0]),
                    **{name: d['history_final_' + name] for name in WATER_SPECS}),
    )
    arrays = _viewer_arrays(display)
    arrays['gradient'] = _encoded(terrain_gradients(world.mesh.positions, world.mesh.faces, elevation), '<f4')
    return {
        'metadata': {'seed': str(world.seed), 'canonicalSha256': canonical_hash(world),
                     'sampleCount': len(world.mesh.positions), 'radiusM': world.config.radius_km * 1000,
                     'seaLevelM': display.water.sea_level_m,
                     'elevationMinM': float(np.min(elevation)), 'elevationMaxM': float(np.max(elevation)),
                     'terrainVersion': world.config.history_terrain_version},
        'arrays': arrays,
    }


def generate_scene(seed):
    if not isinstance(seed, str) or not re.fullmatch(r'[0-9]{1,20}', seed):
        raise ValueError('seed must be a decimal integer from 0 to 18446744073709551615')
    value = int(seed)
    validate_seed(value)
    started = perf_counter()
    world = generate_world(value, replace(WorldConfig.preset('standard'), stage='m3'))
    result = scene_payload(world)
    result['seconds'] = perf_counter() - started
    return result
